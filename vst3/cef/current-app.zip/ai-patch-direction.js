(function (root) {
    'use strict';
    if (root.__mygrainSongRenderDeck) return;
    let schema, kept = false, request = null, serial = 0, locked = false, phase = 'idle', rendered = null, lastPrompt = '', savedPrompts = [], libraryRequest = null, lastSection = null;
    const byId = id => document.getElementById(id);
    const adapter = () => root.mygrainAiPatchAdapter;
    const canUndo = () => /^AI (generated patch|regenerated patch|refined patch|song section)$/.test(root.mygrainCardHistory?.undoLabel || '');
    let activity = null, usage = null, sessionTokens = 0, usageReplies = 0, historyFingerprint = null;
    function usageText(value) {
        if (!value?.available || !['inputTokens', 'outputTokens', 'cachedInputTokens'].every(key => Number.isSafeInteger(value[key]) && value[key] >= 0) || value.cachedInputTokens > value.inputTokens || !Number.isSafeInteger(value.inputTokens + value.outputTokens)) return 'Token usage not reported for this task.';
        const number = n => n.toLocaleString();
        return `This AI task: ${number(value.inputTokens + value.outputTokens)} tokens · ${number(value.inputTokens)} input (${number(value.cachedInputTokens)} cached) · ${number(value.outputTokens)} output · ${number(value.inputTokens - value.cachedInputTokens)} uncached input. Input includes instructions, musical state and catalogue—not just your prompt.`;
    }
    function drawUsage(text) {
        byId('aiPatchUsage').textContent = text;
        if (activity) byId('aiActivityUsage').textContent = text.split(' Input includes')[0];
    }
    function receiveUsage(value) {
        const text = usageText(value); usage = text.startsWith('This AI task:') ? value : null;
        if (usage) { sessionTokens += value.inputTokens + value.outputTokens; usageReplies++; }
        drawUsage(text + (usageReplies ? ` This page: ${sessionTokens.toLocaleString()} reported tokens across ${usageReplies} replies.` : ''));
    }
    function beginActivity(mode) {
        activity?.panel.remove(); if (activity) root.clearInterval(activity.timer);
        const panel = document.createElement('aside'); panel.id = 'aiPatchActivity'; panel.setAttribute('aria-label', 'AI generation activity');
        panel.innerHTML = '<div class="ai-activity-head"><strong id="aiActivityPhase"></strong><span id="aiActivityElapsed"></span><button id="aiActivityToggle" type="button" aria-expanded="true" aria-controls="aiActivityBody">Minimise</button><button id="aiActivityCancel" type="button">Cancel</button><button id="aiActivityClose" type="button" hidden>Close</button></div><div id="aiActivityBody"><p id="aiActivityStatus" role="status"></p><p id="aiActivityUsage"></p><ol id="aiActivityLog" aria-label="Recent generation activity"></ol></div>';
        document.body.append(panel);
        activity = { panel, started: performance.now(), busy: true, phase: 'generating', timer: null };
        byId('aiActivityPhase').textContent = mode === 'section' ? 'Progression · requesting AI' : mode === 'refine' ? 'Refinement · requesting AI' : 'Generation · requesting AI';
        byId('aiActivityToggle').addEventListener('click', () => {
            const body = byId('aiActivityBody'); body.hidden = !body.hidden;
            byId('aiActivityToggle').textContent = body.hidden ? 'Expand' : 'Minimise'; byId('aiActivityToggle').setAttribute('aria-expanded', String(!body.hidden));
        });
        byId('aiActivityClose').addEventListener('click', () => { if (!activity.busy) panel.hidden = true; });
        byId('aiActivityCancel').addEventListener('click', cancel);
        const tick = () => { byId('aiActivityElapsed').textContent = `${Math.floor((performance.now() - activity.started) / 1000)}s`; };
        tick(); activity.timer = root.setInterval(tick, 1000);
        usage = null; drawUsage('Awaiting token usage for this AI task. Counts arrive with the model reply.');
    }
    function finishActivity() {
        if (!activity?.busy) return;
        root.clearInterval(activity.timer); activity.busy = false;
        byId('aiActivityPhase').textContent = 'AI task finished';
        byId('aiActivityCancel').hidden = true; byId('aiActivityClose').hidden = false;
        if (!usage) drawUsage('Token usage not reported for this task. Cancelled or timed-out requests may still consume tokens; no zero usage is assumed.');
    }
    const status = message => { byId('aiPatchStatus').textContent = message; if (activity?.busy) byId('aiActivityStatus').textContent = message; };
    function report(message) {
        const list = byId('aiPatchChanges'), item = document.createElement('li');
        item.textContent = `${new Date().toLocaleTimeString([], { hour12: false })} · ${message}`;
        list.append(item);
        list.scrollTop = list.scrollHeight;
        byId('aiPatchProposal').hidden = false;
        if (activity?.busy) {
            const recent = byId('aiActivityLog'); recent.append(item.cloneNode(true));
            while (recent.children.length > 5) recent.firstChild.remove();
            recent.scrollTop = recent.scrollHeight;
        }
    }
    function inventory() {
        const list = byId('aiPatchSamples'); list.replaceChildren();
        for (const [key, lane] of Object.entries(adapter().inventory())) {
            const item = document.createElement('li');
            item.textContent = `Loop ${key} · ${lane.enabled ? 'ON' : 'OFF'} · ${lane.loaded ? lane.samples.join(', ') || 'Existing audio (no filename metadata)' : 'No sample loaded'}`;
            list.append(item);
        }
        for (const [kind, lane] of Object.entries(adapter().drumInventory())) {
            const item = document.createElement('li'); item.textContent = `Drum ${kind} · ${lane.sample} · ${lane.hits} hits`; list.append(item);
        }
    }
    function update() {
        const busy = Boolean(request) || Boolean(root.mygrainCardHistory?.busy);
        byId('aiPatchGenerate').disabled = locked || !schema || busy;
        for (const box of document.querySelectorAll('[data-ai-eq-protect]')) box.disabled = locked || busy;
        byId('aiPatchCancel').hidden = !request || phase === 'undo';
        byId('aiPatchUndo').hidden = kept || !canUndo();
        byId('aiPatchKeep').hidden = kept || !canUndo();
        byId('aiPatchUndo').disabled = busy || locked;
        byId('aiPatchKeep').disabled = busy || locked;
        byId('aiPatchHear').hidden = false;
        byId('aiPatchRender').disabled = busy || locked || !schema;
        byId('aiPatchReplay').hidden = !rendered;
        byId('aiPatchReplay').disabled = busy || locked;
        byId('aiPatchHear').disabled = busy || locked;
        byId('aiPatchPrompt').disabled = busy || locked;
        byId('aiPatchFollowup').hidden = locked;
        byId('aiPatchRegenerateGroup').hidden = !lastPrompt;
        byId('aiPatchLastPrompt').textContent = lastPrompt;
        byId('aiPatchRegenerate').disabled = busy || locked || !lastPrompt;
        for (const id of ['aiPatchRefine', 'aiPatchRefinement']) byId(id).disabled = busy || locked || !schema;
        for (const id of ['aiPatchSavePrompt', 'aiPatchPromptName', 'aiPatchSavedPrompts', 'aiPatchRefreshPrompts']) byId(id).disabled = busy || locked || Boolean(libraryRequest);
        for (const id of ['aiPatchRecallPrompt', 'aiPatchRemovePrompt']) byId(id).disabled = busy || locked || Boolean(libraryRequest) || !byId('aiPatchSavedPrompts').value;
        byId('aiPatchCard').setAttribute('aria-busy', String(busy));
        root.dispatchEvent(new Event('mygrain-ai-update'));
    }
    function drawPrompts(selected = byId('aiPatchSavedPrompts').value) {
        const list = byId('aiPatchSavedPrompts'); list.replaceChildren();
        const placeholder = document.createElement('option'); placeholder.value = ''; placeholder.textContent = savedPrompts.length ? 'Choose a saved prompt…' : 'No saved prompts yet'; list.append(placeholder);
        for (const prompt of savedPrompts) { const option = document.createElement('option'); option.value = prompt.id; option.textContent = prompt.name; list.append(option); }
        list.value = savedPrompts.some(prompt => prompt.id === selected) ? selected : '';
    }
    async function promptLibrary(action = 'list') {
        if (locked || libraryRequest) return;
        const selected = savedPrompts.find(prompt => prompt.id === byId('aiPatchSavedPrompts').value);
        let body;
        if (action === 'save') {
            const prompt = byId('aiPatchPrompt').value.trim(), name = byId('aiPatchPromptName').value.trim() || prompt.split('\n')[0].slice(0, 80);
            if (prompt.length < 3 || prompt.length > 1500) { byId('aiPatchLibraryStatus').textContent = 'Write a prompt using 3–1,500 characters first.'; return; }
            body = {action: 'save', name, prompt};
        } else if (action === 'remove') {
            if (!selected) return;
            body = {action: 'remove', id: selected.id};
        }
        const controller = new AbortController(); libraryRequest = controller;
        const timeout = root.setTimeout(() => controller.abort(), 15000);
        byId('aiPatchLibraryStatus').textContent = action === 'list' ? 'Loading your saved prompts…' : action === 'save' ? 'Saving prompt to your account…' : 'Removing saved prompt…'; update();
        try {
            const response = await root.fetch(new URL('api/ai-prompts', document.baseURI), {method: body ? 'POST' : 'GET', credentials: 'same-origin', cache: 'no-store', signal: controller.signal, ...(body ? {headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)} : {})});
            const payload = await response.json();
            if (locked || controller.signal.aborted) return;
            if (!response.ok || !payload.ok) throw Error(payload.error || 'Saved prompts unavailable. Your patch is unchanged.');
            if (!Array.isArray(payload.prompts) || payload.prompts.length > 200 || payload.prompts.some(p => !p || !/^[a-f0-9]{32}$/.test(p.id) || typeof p.name !== 'string' || p.name.length > 80 || typeof p.prompt !== 'string' || p.prompt.length < 3 || p.prompt.length > 1500)) throw Error('Saved prompt list could not be read. Your patch is unchanged.');
            savedPrompts = payload.prompts; drawPrompts(payload.savedId || (action === 'remove' ? '' : selected?.id));
            byId('aiPatchLibraryStatus').textContent = action === 'save' ? 'Saved to your account. Recall on another device; generated results will vary.' : action === 'remove' ? 'Removed from your saved list. The current text and sound are unchanged.' : `${savedPrompts.length} saved prompt${savedPrompts.length === 1 ? '' : 's'} · your account, across devices.`;
        } catch (error) {
            if (!locked) byId('aiPatchLibraryStatus').textContent = error.name === 'AbortError' ? 'Prompt library timed out. Retry; no save was confirmed.' : error.message;
        } finally { root.clearTimeout(timeout); if (libraryRequest === controller) libraryRequest = null; update(); }
    }
    function recallPrompt() {
        if (request || locked || libraryRequest) return;
        const saved = savedPrompts.find(prompt => prompt.id === byId('aiPatchSavedPrompts').value); if (!saved) return;
        byId('aiPatchPrompt').value = saved.prompt; byId('aiPatchPromptName').value = saved.name;
        byId('aiPatchLibraryStatus').textContent = `Recalled “${saved.name}”. Sound unchanged; Generate to try this direction.`;
    }
    async function refreshSchema(signal) {
        const response = await root.fetch(new URL('ai-patch-controls.json?v=20261112-ai-effects-1', document.baseURI), { credentials: 'same-origin', cache: 'no-store', ...(signal ? { signal } : {}) });
        if (!response.ok) throw Error('AI controls could not refresh. Nothing was changed; retry.');
        const data = await response.json();
        if (data.version !== 4 || !data.controls || Object.keys(data.loops || {}).length !== 14) throw Error('AI controls changed. Reload MYGRAIN. Nothing was changed.');
        schema = data;
    }
    function waitForWorker(ms, signal) {
        return new Promise((resolve, reject) => {
            let timer;
            const cancel = () => { root.clearTimeout(timer); signal.removeEventListener('abort', cancel); reject(new DOMException('Cancelled.', 'AbortError')); };
            if (signal.aborted) return cancel();
            signal.addEventListener('abort', cancel, { once: true });
            timer = root.setTimeout(() => { signal.removeEventListener('abort', cancel); resolve(); }, ms);
        });
    }
    async function requestRecipe(body, signal, check) {
        const started = performance.now();
        let waiting = false;
        for (;;) {
            check();
            const response = await root.fetch(new URL('api/ai-patch-direction', document.baseURI), { method: 'POST', credentials: 'same-origin', signal, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
            const payload = await response.json();
            const busy = response.status === 429 && (['ai_busy', 'ai_cooldown'].includes(payload.code) || ['AI is finishing another proposal. Try again shortly.', 'Please wait 15 seconds between AI requests.'].includes(payload.error));
            if (!busy) return { response, payload };
            const remaining = 90000 - (performance.now() - started);
            if (remaining <= 0) throw Error('AI is still busy after waiting. Your patch is unchanged; try again shortly.');
            if (!waiting) { report('AI worker occupied. Waiting for availability; no new model request has started.'); waiting = true; }
            status('Waiting for the AI worker… Cancel remains available. Your patch is unchanged.');
            const seconds = Number(response.headers.get('Retry-After'));
            await waitForWorker(Math.min(remaining, Number.isFinite(seconds) && seconds > 0 ? Math.max(1000, Math.min(15000, seconds * 1000)) : 2000), signal);
        }
    }
    // Bounded data-only effect contract, shared with the model/server schema.
    function validateEffectChanges(value) {
        if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).some(k => !['effects','cardEffects'].includes(k))) throw Error('Invalid AI effect changes.');
        for (const group of ['effects','cardEffects']) {
            const changes=Object.hasOwn(value,group)?value[group]:{}, contract=group==='effects'?schema.effects:Object.fromEntries(schema.cardEffects.channels.map(k=>[k,schema.cardEffects.fields]));
            if (!changes||typeof changes!=='object'||Array.isArray(changes)) throw Error('Invalid AI effects.');
            for(const [key,fields] of Object.entries(changes)) {
                if(!Object.hasOwn(contract,key)||!fields||typeof fields!=='object'||Array.isArray(fields)||!Object.keys(fields).length) throw Error('Unsupported AI effect/card: '+key);
                for(const [name,item] of Object.entries(fields)) {
                    if(group==='cardEffects'&&key==='N'&&(/^(filter|lfo)/.test(name)||['cutoff','resonance'].includes(name))) throw Error('N has its own filter; cardEffects N supports space only.');
                    const spec=Object.hasOwn(contract[key],name)?contract[key][name]:null;
                    if(!spec || !(spec.type==='boolean'?typeof item==='boolean':spec.type==='number'?typeof item==='number'&&Number.isFinite(item)&&item>=spec.min&&item<=spec.max:spec.enum.includes(item))) throw Error('Invalid AI effect field: '+key+'.'+name);
                }
            }
        }
        return value;
    }
    function effectSettings(key) {
        if(key==='mutilator') return {input:'D',...root.mygrainD.settings().mutilator};
        if(key==='bassFace') return root.mygrainBassFace.settings();
        if(key==='turntable') {const s=root.mygrainTurntable.settings();return {...s,input:s.input||(s.route==='drums'?'drums':'all')};}
        if(key==='resonator') {const s=root.mygrainResonator.settings();return {...s.slots[0],enabled:s.enabled,input:s.slots[0].source};}
        if(['wireWorld','sonicCrystal'].includes(key)) {const s=root.mygrainAcousticFx.settings(key);return {...s,input:s.source};}
        const s=root.mygrainWasp.settings();
        if(key==='playground') {const v=s.playground,m=v.modulation.cutoff;return {...v,input:v.input||'all',lfoBeats:m.beats,lfoDepth:m.source==='drawn'?Math.max(0,m.amount):0};}
        return {...s,...s.routes[0],enabled:s.enabled,input:s.routes[0].source};
    }
    function readEffectState() {
        const effects={},cardEffects={};
        for(const [key,fields] of Object.entries(schema.effects)) {const s=effectSettings(key);effects[key]={};for(const name of Object.keys(fields)) {try {validateEffectChanges({effects:{[key]:{[name]:s[name]}}});effects[key][name]=s[name];}catch{}}}
        for(const key of schema.cardEffects.channels) {const s=root.mygrainLoopFx.channel(key);cardEffects[key]={};for(const name of Object.keys(schema.cardEffects.fields)){try{validateEffectChanges({cardEffects:{[key]:{[name]:s[name]}}});cardEffects[key][name]=s[name];}catch{}}}
        return {effects,cardEffects};
    }
    async function applyEffectChanges(recipe, report, guard, done) {
        validateEffectChanges(Object.fromEntries(['effects','cardEffects'].filter(k=>Object.hasOwn(recipe,k)).map(k=>[k,recipe[k]])));
        for(const [key,v] of Object.entries(recipe.cardEffects||{})) {
            guard();const s=root.mygrainLoopFx.settings();s.channels[key]={...s.channels[key],...v};root.mygrainLoopFx.restore(s);done();guard();report('Card '+key+' effects: '+JSON.stringify(v)+' · applied');
        }
        for(const [key,v] of Object.entries(recipe.effects||{})) {
            guard();
            if(key==='mutilator') root.mygrainD.setMutilator({...root.mygrainD.settings().mutilator,...v},{skipSave:true});
            else if(key==='bassFace') root.mygrainBassFace.restore({...root.mygrainBassFace.settings(),...v});
            else if(key==='turntable') {const s=root.mygrainTurntable.settings();await root.mygrainTurntable.restore({...s,...v,...(v.input?{route:v.input==='drums'?'drums':'mix'}:{})});}
            else if(['wireWorld','sonicCrystal'].includes(key)) {const {input,...fields}=v;await root.mygrainAcousticFx.set(key,{...root.mygrainAcousticFx.settings(key),...fields,...(input?{source:input}:{})});}
            else if(key==='resonator') {const s=root.mygrainResonator.settings(),{input,enabled,...fields}=v,configure=input!==undefined||Object.keys(fields).length>0;await root.mygrainResonator.restore({...s,...(enabled!==undefined?{enabled}:{}),...(configure?{slots:[{...s.slots[0],...fields,enabled:true,...(input?{source:input}:{})},{...s.slots[1],enabled:false}]}:{})});}
            else {
                const s=root.mygrainWasp.settings();
                if(key==='wasp') {const {input,destination,method,depth,cutoff,release,...fields}=v;Object.assign(s,fields);if([input,destination,method,depth,cutoff,release].some(x=>x!==undefined)){s.routes[0]={...s.routes[0],enabled:true,...(input?{source:input}:{}),...Object.fromEntries(Object.entries({destination,method,depth,cutoff,release}).filter(([,x])=>x!==undefined))};for(let i=1;i<s.routes.length;i++)s.routes[i].enabled=false;}}
                else {const {lfoBeats,lfoDepth,...fields}=v;Object.assign(s.playground,fields);if(lfoBeats!==undefined||lfoDepth!==undefined){const m=s.playground.modulation.cutoff;Object.assign(m,{clock:'sync',source:'drawn',multiplier:1,timing:'straight',curve:Array.from({length:64},(_,i)=>2*i/63-1)},lfoBeats!==undefined?{beats:lfoBeats}:{},lfoDepth!==undefined?{amount:lfoDepth}:{});}}
                await root.mygrainWasp.restore(s);
            }
            done();guard();report(key+' effect: '+JSON.stringify(v)+' · applied');
        }
        await root.mygrainCookingPot?.whenReady();done();guard();
        return Object.keys(recipe.effects||{}).length+Object.keys(recipe.cardEffects||{}).length;
    }

    function validateRecipe(recipe) {
        if (!recipe || typeof recipe !== 'object' || Array.isArray(recipe) || !['title', 'description', 'parameters', 'loops'].every(key => Object.hasOwn(recipe, key)) || Object.keys(recipe).some(key => !['title', 'description', 'parameters', 'loops', 'drums', 'patternSteps', 'effects', 'cardEffects'].includes(key))) throw Error('Invalid AI recipe. Nothing was changed.');
        if (Object.hasOwn(recipe, 'patternSteps') && recipe.patternSteps !== 64) throw Error('Progressions use a four-bar, 64-step pattern.');
        for (const [key, limit] of [['title', 80], ['description', 600]]) if (typeof recipe[key] !== 'string' || !recipe[key].trim() || recipe[key].length > limit) throw Error('Invalid AI description.');
        if (!recipe.parameters || typeof recipe.parameters !== 'object' || Array.isArray(recipe.parameters) || !recipe.loops || typeof recipe.loops !== 'object' || Array.isArray(recipe.loops)) throw Error('Missing patch controls or loop operations.');
        validateEffectChanges(Object.fromEntries(['effects','cardEffects'].filter(k=>Object.hasOwn(recipe,k)).map(k=>[k,recipe[k]])));
        const entries = Object.entries(recipe.parameters), lanes = Object.entries(recipe.loops);
        if ((!entries.length && !lanes.length && !recipe.drums && !Object.keys(recipe.effects||{}).length && !Object.keys(recipe.cardEffects||{}).length) || entries.length > Object.keys(schema.controls).length) throw Error('Invalid control count.');
        for (const [key, value] of entries) {
            const spec = schema.controls[key];
            if (!Object.hasOwn(schema.controls, key) || spec.readOnly || typeof value !== 'number' || !Number.isFinite(value) || value < spec.min || value > spec.max || (value - spec.min) % spec.step !== 0) throw Error(`Unsupported or out-of-range AI control: ${key}. Nothing was changed; reload MYGRAIN and retry.`);
        }
        let loads = 0;
        for (const [key, lane] of lanes) {
            const spec = schema.loops[key];
            if (!Object.hasOwn(schema.loops, key) || !lane || typeof lane !== 'object' || Array.isArray(lane)) throw Error('Unsupported loop.');
            const allowed = ['enabled', ...(spec.reload ? ['reload'] : []), ...(spec.divisions ? ['divisions'] : []), ...(spec.notes ? ['notes'] : []), ...(['X','L'].includes(key) ? ['repository'] : []), ...(key === 'Q' ? ['instrument', 'chords', 'chordSteps', 'style'] : []), ...(['X', 'L', 'V', 'P', 'O'].includes(key) ? ['sampleId', 'selection'] : [])];
            if (!Object.keys(lane).length || Object.keys(lane).some(field => !allowed.includes(field))) throw Error('Unsupported loop operation.');
            for (const field of ['enabled', 'reload']) if (Object.hasOwn(lane, field) && typeof lane[field] !== 'boolean') throw Error('Invalid loop switch.');
            if (Object.hasOwn(lane, 'repository') && (!['X','L'].includes(key) || !(key === 'X' ? ['samples_bass','samples_altbass'] : ['samples_leads','samples_terra']).includes(lane.repository) || !lane.reload)) throw Error('Invalid loop repository operation.');
            if (lane.divisions && (!Array.isArray(lane.divisions) || !lane.divisions.length || lane.divisions.length > 3 || lane.divisions.some(d => !schema.divisions.includes(d)) || new Set(lane.divisions).size !== lane.divisions.length || (lane.divisions.includes('uncut') && lane.divisions.length !== 1))) throw Error('Invalid loop divisions.');
            if (Object.hasOwn(lane, 'divisions') && !lane.divisions) throw Error('Invalid loop divisions.');
            if (Object.hasOwn(lane, 'notes') && (!Array.isArray(lane.notes) || !lane.notes.length || lane.notes.length > 64 || !lane.notes.some(n => n !== null) || lane.notes.some(n => n !== null && (!Number.isInteger(n) || n < 24 || n > 84)))) throw Error('Invalid lead/bass notes.');
            if (Object.hasOwn(lane, 'instrument') && !['piano', 'strings'].includes(lane.instrument)) throw Error('Invalid Q instrument.');
            if (Object.hasOwn(lane, 'chords') && (!Array.isArray(lane.chords) || !lane.chords.length || lane.chords.length > 8 || lane.chords.some(chord => !Array.isArray(chord) || !chord.length || chord.length > 4 || chord.some(n => !Number.isInteger(n) || n < 36 || n > 84)))) throw Error('Invalid Q chords.');
            if (Object.hasOwn(lane, 'style') && !['dry', 'warm', 'spacious'].includes(lane.style)) throw Error('Invalid Q style.');
            if (Object.hasOwn(lane, 'chordSteps') && ![4, 8, 16].includes(lane.chordSteps)) throw Error('Invalid Q chord spacing.');
            if (Object.hasOwn(lane, 'sampleId') || Object.hasOwn(lane, 'selection')) {
                const selection = lane.selection, sources = {X: lane.repository || adapter().inventory({ forModel: true }).X.repository || 'samples_bass', L: lane.repository || adapter().inventory({ forModel: true }).L.repository || 'samples_leads', V: 'samples_vocal', P: 'samples_piano', O: 'samples_orch'};
                if (!lane.reload || typeof lane.sampleId !== 'string' || !/^[a-f0-9]{64}$/.test(lane.sampleId) || !selection || Array.isArray(selection) || selection.sampleId !== lane.sampleId || selection.source !== sources[key] || !/^[a-f0-9]{64}$/.test(selection.sha256) || typeof selection.relativePath !== 'string' || selection.relativePath.length > 1024 || selection.relativePath.includes('\\') || selection.relativePath.split('/').some(part => !part || part === '.' || part === '..') || /[\x00-\x1f]/.test(selection.relativePath) || typeof selection.name !== 'string' || selection.name !== selection.relativePath.split('/').pop()) throw Error('Invalid catalogue sample identity. Nothing was changed.');
                if (selection.playbackRoot !== null && (!selection.playbackRoot || typeof selection.playbackRoot.note !== 'string' || !/^[A-G][#b]?[0-8]$/.test(selection.playbackRoot.note) || typeof selection.playbackRoot.source !== 'string')) throw Error('Invalid catalogue playback root.');
                if (!selection.filename || !selection.audioTentative || !selection.measured || !Array.isArray(selection.warnings) || selection.warnings.some(w => typeof w !== 'string')) throw Error('Invalid catalogue metadata.');
            }
            if (lane.reload) loads++;
        }
        if (loads > schema.maxReloads) throw Error('At most three fresh loop sources per direction.');
        if (Object.hasOwn(recipe, 'drums')) {
            const drums = recipe.drums;
            if (!drums || typeof drums !== 'object' || Array.isArray(drums) || !Object.keys(drums).length || Object.keys(drums).some(key => !['enabled', 'tracks'].includes(key)) || (Object.hasOwn(drums, 'enabled') && typeof drums.enabled !== 'boolean')) throw Error('Invalid drums.');
            if (Object.hasOwn(drums, 'tracks') && (!drums.tracks || typeof drums.tracks !== 'object' || Array.isArray(drums.tracks))) throw Error('Invalid drum tracks.');
            for (const [key, lane] of Object.entries(drums.tracks || {})) {
                if (!['kick', 'snare', 'hat'].includes(key) || !lane || typeof lane !== 'object' || Array.isArray(lane) || !Object.keys(lane).length || Object.keys(lane).some(field => !['reload', 'steps', 'ratchets'].includes(field))) throw Error('Unsupported drum operation.');
                if (Object.hasOwn(lane, 'reload') && typeof lane.reload !== 'boolean') throw Error('Invalid drum reload.');
                if (Object.hasOwn(lane, 'steps') && (!Array.isArray(lane.steps) || !lane.steps.length || lane.steps.length > 64 || lane.steps.some(hit => !Number.isInteger(hit) || ![0, 1].includes(hit)))) throw Error('Invalid drum pattern.');
                if (Object.hasOwn(lane, 'ratchets') && (!Array.isArray(lane.ratchets) || !lane.ratchets.length || lane.ratchets.length > 64 || lane.ratchets.some(v => !Number.isInteger(v) || ![0, 2, 4, 8].includes(v)) || lane.ratchets.filter(Boolean).length > 8)) throw Error('Invalid drum rolls.');
            }
        }
        return recipe;
    }
    function cancel() {
        request?.abort();
        if (phase === 'applying') status('Cancelling… restoring the previous patch and samples.');
        else status('Cancelled. Your patch is unchanged.');
    }
    async function generate(mode = 'generate', section = null, external = null) {
        if (request || locked || !schema) return;
        const repeatedSection = mode === 'regenerate' && lastSection;
        if (repeatedSection) section = { ...lastSection };
        const editorPrompt = external?.prompt || byId('aiPatchPrompt').value.trim();
        const prompt = mode === 'regenerate' ? lastPrompt : mode === 'refine' && !editorPrompt ? 'Refine the current patch while preserving its musical identity.' : editorPrompt;
        const refinement = mode === 'refine' ? byId('aiPatchRefinement').value.trim() : mode === 'section' ? byId('aiPartInstruction').value.trim() : '';
        if (!['generate', 'refine', 'regenerate', 'section'].includes(mode) || (['regenerate', 'section'].includes(mode) && !lastPrompt)) return;
        if (mode === 'refine' && !refinement) { status('Describe what should change in the refinement box.'); return; }
        const usedPrompt = mode === 'refine' ? `${prompt}\n\nRefinement: ${refinement}` : mode === 'section' ? `${prompt}\n\nSection: ${section.type} (${section.bars} bars).${refinement ? ' ' + refinement : ''}` : prompt;
        const requestMode = repeatedSection ? 'section' : mode;
        if (usedPrompt.length > 1500) { status('Prompt plus refinement exceeds 1,500 characters. Shorten the direction first.'); return; }
        if (prompt.length < 3 || prompt.length > 1500) { status('Describe your direction in 3–1500 characters.'); return; }
        let timeout;
        const token = ++serial;
        try {
            adapter().assertReady();
            request = new AbortController(); const signal = request.signal;
            timeout = root.setTimeout(() => request?.abort(), 180000);
            rendered = null;
            byId('aiPatchPreviewStatus').textContent = 'Render a fresh one-bar preview after this direction finishes. Capture is audible and stays on this device.';
            phase = 'generating';
            beginActivity(requestMode);
            byId('aiPatchChanges').replaceChildren();
            byId('aiPatchTitle').textContent = 'Live changes'; byId('aiPatchDescription').textContent = '';
            inventory();
            report(requestMode === 'section' ? 'Developing a related song section with GPT-6.1 Sol; current tempo, kit and library sources stay loaded. No patch changes yet.' : mode === 'refine' ? 'Refining the current patch with GPT-6.1 Sol; library samples stay loaded. No patch changes yet.' : mode === 'regenerate' ? 'Regenerating the last applied prompt with GPT-6.1 Sol. A fresh variation, not an identical patch.' : 'Requesting a musical recipe from GPT-6.1 Sol. No patch changes yet.');
            status(requestMode === 'section' ? 'GPT-6.1 Sol is developing chords, bass and groove for this section…' : 'GPT-6.1 Sol is choosing tempo, layers and sound parameters…'); update();
            await refreshSchema(signal);
            if (token !== serial || locked || signal.aborted) return;
            const fingerprint = adapter().fingerprint(), current = adapter().read(Object.keys(schema.controls)), loops = adapter().inventory({ forModel: true });
            const { response, payload } = await requestRecipe({ prompt, current, loops, effectState: readEffectState(), mode: requestMode, ...(external ? { genre: external.genre, genreBpm: external.bpm } : {}), ...(['refine', 'section'].includes(requestMode) ? { refinement, musicalState: adapter().musicalState() } : {}), ...(requestMode === 'section' ? { section } : {}) }, signal, () => {
                if (token !== serial || locked || signal.aborted) throw new DOMException('Cancelled.', 'AbortError');
                adapter().assertReady();
                if (adapter().fingerprint() !== fingerprint) throw Error('Your patch or Song changed while waiting. Generate a fresh direction.');
            });
            if (token !== serial || locked || signal.aborted) return;
            receiveUsage(payload.usage);
            if (!response.ok || !payload.ok) throw Error(payload.error || 'AI unavailable. Your patch is unchanged.');
            if (payload.model !== 'openai/gpt-6.1-sol') throw Error('Unexpected AI model. Nothing was changed.');
            adapter().assertReady();
            if (adapter().fingerprint() !== fingerprint) throw Error('Your patch or Song changed while AI was working. Generate a fresh direction.');
            const recipe = validateRecipe(payload.recipe), combined = { ...current, ...recipe.parameters };
            if (['refine', 'section'].includes(requestMode) && (Object.entries(recipe.loops).some(([key, lane]) => lane.reload && !(requestMode === 'refine' && key === 'X' && lane.repository)) || Object.values(recipe.drums?.tracks || {}).some(lane => lane.reload))) throw Error('Refine keeps current library samples. Nothing changed; try again or use Regenerate.');
            if (requestMode === 'section') {
                if (recipe.patternSteps !== 64 || !recipe.loops.Q?.chords) throw Error('The progression needs a four-bar Q chord pattern.');
                const currentMusic = adapter().musicalState();
                if (recipe.loops.Q.instrument && recipe.loops.Q.instrument !== currentMusic.Q.instrument) throw Error('Progressions keep the current Q instrument.');
                for (const [key, value] of Object.entries(recipe.parameters)) if ((key === 'globalBpmSlider' || (key.startsWith('drumMachine') && !key.endsWith('Level'))) && value !== current[key]) throw Error('Progressions keep tempo and drum sound settings.');
                if (!section.rolls && Object.values(recipe.drums?.tracks || {}).some(track => track.ratchets?.some(Boolean))) throw Error('Rolls were not enabled. Nothing changed.');
            } else if (Object.hasOwn(recipe, 'patternSteps')) throw Error('Only progression generation changes the pattern length.');
            if (combined.hpfCutoff >= combined.lpfCutoff / 2) throw Error('The proposed filters would remove too much sound. Try again.');
            if (['refine', 'section'].includes(requestMode)) report('Refine/progression: existing library samples retained; editing current settings and musical patterns.');
            else if (payload.catalogue?.status === 'ready') {
                report(`Catalogue: ${payload.catalogue.catalogueCount} analysed files · ${payload.catalogue.eligibleCount} eligible in this library · ${payload.catalogue.shortlistCount} shortlisted. Filename claims and audio estimates are not guarantees.`);
                for (const key of payload.catalogue.fallbackLanes || []) report(`Loop ${key}: no eligible catalogue source; using existing random library selection.`);
            } else report(`Catalogue fallback: ${payload.catalogue?.reason || 'This server returned a legacy recipe; using existing library selection.'}`);
            byId('aiPatchTitle').textContent = recipe.title; byId('aiPatchDescription').textContent = recipe.description;
            root.clearTimeout(timeout); timeout = root.setTimeout(() => request?.abort(), 240000);
            phase = 'applying'; status('Applying the recipe. Follow the live changes and sample loads below…');
            byId('aiActivityPhase').textContent = 'Applying recipe · loading sounds'; activity.phase = 'applying'; update();
            const result = await adapter().execute(recipe, fingerprint, { signal, mode: requestMode, report: text => { if (!locked && token === serial) { report(text); inventory(); } }, onApplied: () => {
                // Direction belongs to the same persistent step as the sounds.
                kept = false; lastPrompt = usedPrompt;
                if (requestMode === 'section') lastSection = { ...section };
                else if (mode !== 'refine') lastSection = null;
                byId('aiPatchPrompt').value = usedPrompt;
                if (mode === 'refine') byId('aiPatchRefinement').value = '';
            } });
            if (locked || token !== serial) return;
            inventory();
            report(`Complete: ${result.changes} actual changes. ${result.saved ? 'Settings autosaved. Save/export a named patch with audio for a portable copy.' : 'Autosave unavailable: export the patch to retain it.'}`);
            status(`Applied ${result.changes} changes. Added to Undo/Redo on this device. Undo restores the previous patch; Redo restores this exact result without generating again.`);
            return { applied: true, prompt: lastPrompt, section: lastSection };
        } catch (error) {
            if (!locked && token === serial) {
                const text = error.name === 'AbortError' ? (phase === 'applying' ? 'Cancelled. Previous patch and samples restored.' : 'Cancelled or timed out. Your patch is unchanged.') : error.message || 'AI unavailable.';
                status(text); report(text); inventory();
            }
        } finally {
            root.clearTimeout(timeout);
            if (token === serial) { finishActivity(); request = null; phase = 'idle'; update(); }
        }
    }
    async function undo() {
        if (!canUndo() || request || locked || root.mygrainCardHistory.busy) return;
        if (historyFingerprint && adapter().fingerprint() !== historyFingerprint) {
            status('Your patch changed. Undo direction has not overwritten your newer edits. Use the main Undo/Redo list to travel history, or Keep current.');
            return;
        }
        const count = root.mygrainCardHistory.counts.undo;
        request = new AbortController(); phase = 'undo'; update();
        try {
            await root.mygrainCardHistory.undoAI();
            if (root.mygrainCardHistory.counts.undo < count) {
                inventory(); report('Undo complete. Previous patch and samples restored; Redo is available in the main Undo/Redo list.');
                status('Undone. Previous patch and samples restored. Use Redo to restore the exact AI patch.');
            }
        } finally { request = null; phase = 'idle'; update(); }
    }
    async function initialize() {
        if (!byId('aiPatchCard')) return;
        byId('aiPatchGenerate').addEventListener('click', () => generate());
        byId('aiPatchRegenerate').addEventListener('click', () => generate('regenerate'));
        byId('aiPatchRefine').addEventListener('click', () => generate('refine'));
        byId('aiPatchSavePrompt').addEventListener('click', () => promptLibrary('save'));
        byId('aiPatchRefreshPrompts').addEventListener('click', () => promptLibrary());
        byId('aiPatchRemovePrompt').addEventListener('click', () => promptLibrary('remove'));
        byId('aiPatchRecallPrompt').addEventListener('click', recallPrompt);
        byId('aiPatchSavedPrompts').addEventListener('change', update);
        byId('aiPatchCancel').addEventListener('click', cancel);
        byId('aiPatchUndo').addEventListener('click', undo);
        byId('aiPatchHear').addEventListener('click', async () => {
            if (request || locked) return;
            request = new AbortController(); phase = 'audition'; update();
            try { if (!await adapter().play(request.signal)) throw Error('No audible loop is ready. Check levels and patterns.'); inventory(); report('Q/X/drums and enabled loops playing through the shared transport.'); status('Playing. Stop, edit or generate another direction whenever ready.'); }
            catch (error) { status(error.message); }
            finally { request = null; phase = 'idle'; update(); }
        });
        byId('aiPatchStop').addEventListener('click', () => { request?.abort(); adapter().stop(); status('Stopped. You can edit, play or generate again.'); });
        byId('aiPatchRender').addEventListener('click', async () => {
            if (request || locked) return;
            request = new AbortController(); phase = 'preview'; rendered = null; update();
            try {
                rendered = await adapter().preview(request.signal, report);
                byId('aiPatchPreviewStatus').textContent = `One bar rendered · ${rendered.buffer.duration.toFixed(2)}s · peak ${rendered.peak.toFixed(3)} · RMS ${rendered.rms.toFixed(4)}. Play rendered preview to hear this capture. New edits make the capture stale.`;
                status('Preview captured. Original transport restored; all controls are ready.');
            } catch (error) { status(error.name === 'AbortError' ? 'Preview cancelled. Controls are ready.' : error.message); }
            finally { request = null; phase = 'idle'; update(); }
        });
        byId('aiPatchReplay').addEventListener('click', () => {
            try {
                if (adapter().fingerprint() !== rendered?.fingerprint) { rendered = null; update(); throw Error('Patch changed. Render a fresh preview.'); }
                adapter().playPreview(rendered.buffer); status('Playing the rendered one-bar capture. Stop remains available.');
            } catch (error) { status(error.message); }
        });
        byId('aiPatchKeep').addEventListener('click', () => { kept = true; status('Kept. This patch remains in the main Undo/Redo list. Save/export a named patch as usual.'); update(); });
        document.querySelectorAll('[data-ai-patch-example]').forEach(button => button.addEventListener('click', () => { if (!request && !locked) { byId('aiPatchPrompt').value = button.dataset.aiPatchExample; byId('aiPatchPrompt').focus(); } }));
        root.addEventListener('mygrain-account-lock', () => { locked = true; kept = false; rendered = null; lastPrompt = ''; lastSection = null; savedPrompts = []; drawPrompts(''); libraryRequest?.abort(); for (const id of ['aiPatchPrompt', 'aiPatchPromptName', 'aiPatchRefinement']) byId(id).value = ''; byId('aiPatchLibraryStatus').textContent = 'Sign in to recall your prompts.'; request?.abort(); adapter()?.stopPreview(); status('Sign in again. AI work stopped.'); update(); });
        root.addEventListener('mygrain-history-update', () => {
            if (!root.mygrainCardHistory?.busy) historyFingerprint = canUndo() ? adapter().fingerprint() : null;
            update();
        });
        root.addEventListener('mygrain-account-lock', () => {
            if (activity) { root.clearInterval(activity.timer); activity.panel.remove(); activity = null; }
            usage = null; sessionTokens = 0; usageReplies = 0; drawUsage('Sign in to see AI task usage.');
        });
        root.addEventListener('pagehide', () => { cancel(); libraryRequest?.abort(); });
        // Trusted edits outside this card must not race asynchronous patch writes.
        for (const event of ['click', 'input', 'change', 'keydown']) document.addEventListener(event, e => {
            if (!['applying', 'undo', 'preview', 'audition', 'take'].includes(phase) || !e.isTrusted || e.target.closest('#aiPatchCard, #aiPatchActivity, #genreatorCard, #sectionJumpDrawer') || !e.target.closest('button, input, select, textarea')) return;
            e.preventDefault(); e.stopImmediatePropagation();
        }, true);
        update(); void promptLibrary();
        try {
            await refreshSchema(); inventory(); update();
        } catch { status('AI beta could not load. Reload to try again. Your other controls still work.'); }
    }
    async function withPartAction(action) {
        if (request || locked) throw Error('Wait for the current AI operation to finish.');
        adapter().assertReady();
        request = new AbortController(); phase = 'take'; update();
        const controller = request, account = root.mygrainAccounts.user.username;
        const check = () => {
            if (controller.signal.aborted) throw new DOMException('Cancelled.', 'AbortError');
            if (locked || !root.mygrainAccounts?.authenticated || root.mygrainAccounts.user.username !== account) throw Error('Account changed. Take operation stopped.');
        };
        const timeout = root.setTimeout(() => controller.abort(), 180000);
        try { return await action(controller.signal, check); }
        finally { root.clearTimeout(timeout); request = null; phase = 'idle'; update(); }
    }
    function setDirection(context) {
        lastPrompt = context.prompt || ''; lastSection = context.section ? { ...context.section } : null;
        kept = true; rendered = null;
        byId('aiPatchPrompt').value = lastPrompt; byId('aiPatchRefinement').value = '';
        adapter().stopPreview(); byId('aiPatchChanges').replaceChildren();
        byId('aiPatchTitle').textContent = context.name || 'Recalled part'; byId('aiPatchDescription').textContent = 'Complete editable pattern, sounds and prompt restored from your account.';
        byId('aiPatchPreviewStatus').textContent = 'Stored part recalled. Render a fresh preview to capture this version.';
        report('Stored part recalled: ' + (context.name || 'unnamed take') + '. Hear, refine or generate a related section.');
        status('Stored part recalled. Ready to play, refine or generate a related section.'); inventory(); update();
    }
    function historyState() {
        return { prompt: lastPrompt, section: lastSection ? { ...lastSection } : null, editorPrompt: byId('aiPatchPrompt').value };
    }
    function restoreHistoryState(saved) {
        if (!saved) return;
        lastPrompt = saved.prompt || ''; lastSection = saved.section ? { ...saved.section } : null;
        byId('aiPatchPrompt').value = saved.editorPrompt ?? lastPrompt;
        kept = false; rendered = null; adapter().stopPreview();
        byId('aiPatchPreviewStatus').textContent = 'History restored. Render a fresh preview to capture this version.';
        inventory(); update();
    }
    function acceptCapture(before, stableBefore) {
        if (phase !== 'take' || adapter().fingerprint({ ignoreQBank: true }) !== stableBefore) throw Error('The patch changed while capturing. Store again.');
        // Q capture records the already-loaded bank manifest. This bookkeeping does not change the sound.
        const after = adapter().fingerprint();
        if (historyFingerprint === before) historyFingerprint = after;
        if (rendered?.fingerprint === before) rendered.fingerprint = after;
    }
    root.mygrainAiPatch = Object.freeze({ validateEffectChanges, readEffectState, applyEffectChanges, generateGenre: (genre, bpm, prompt) => generate('generate', null, { genre, bpm, prompt }), generate, historyState, restoreHistoryState, section: options => generate('section', options), withPartAction, setDirection, acceptCapture, direction: () => ({ prompt: lastPrompt, section: lastSection ? { ...lastSection } : null }), refine: () => generate('refine'), regenerate: () => generate('regenerate'), undo, cancel, diagnostics: () => ({ phase, busy: Boolean(request), libraryBusy: Boolean(libraryRequest), savedPromptCount: savedPrompts.length, lastPromptAvailable: Boolean(lastPrompt), undoAvailable: canUndo() && !kept, renderedPreview: Boolean(rendered), previewPlaying: Boolean(adapter()?.previewPlaying), status: byId('aiPatchStatus')?.textContent }), get ready() { return Boolean(schema); }, get busy() { return Boolean(request); } });
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize, { once: true }); else void initialize();
})(window);
