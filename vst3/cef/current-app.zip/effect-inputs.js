/* One ordered input inventory for every specialised effect. No saved UI state. */
(function(root){
'use strict';
const SOURCES=Object.freeze(['all','A','B','C','D','V','W','P','O','L','X','Q','M','M+','generated','sample','K','K1','K2','K3','K4','K5','drums','drumKick','drumSnare','drumHat','drumPerc','drumClap','drumCymbals','drumEtc','drumRoll','N','DAW']);
const labels={all:'Whole mix · all tracks',A:'A · Loop',B:'B · Loop',C:'C · Loop',D:'D · Loop',V:'V · Vocal',W:'W · Wave',P:'P · Paulstretch',O:'O · Orbit',L:'L · Lead',X:'X · Bass',Q:'Q · Instrument',M:'M · Synth','M+':'M+ · Synth',generated:'Generated loop',sample:'Dropbox sample',K:'K · All five tracks',drums:'Drums · All lanes',N:'N · Noise',DAW:'VST3 FX · Host input'};
for(let i=1;i<=5;i++)labels['K'+i]='K'+i+' · Recorder track '+i;
for(const key of SOURCES.filter(k=>k.startsWith('drum')&&k!=='drums'))labels[key]='Drums · '+key.slice(4).replace(/^[a-z]/,c=>c.toUpperCase());
const label=key=>labels[key]||key;
const matches=(selection,key)=>selection==='all'||selection===key||selection==='K'&&/^K[1-5]$/.test(key)||selection==='drums'&&key.startsWith('drum');
const api=Object.freeze({SOURCES,label,matches,options:()=>SOURCES.map(key=>[key,label(key)])});root.MygrainEffectInputs=api;
if(typeof module==='object'&&module.exports)module.exports=api;
})(globalThis);
