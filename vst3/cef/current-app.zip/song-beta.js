(function (root) {
    'use strict';

    function partDurationSeconds(part) {
        const bpm = Number(part.bpm);
        const steps = Number(part.patternSteps);
        const repeats = Number(part.repeats);
        const cycle = part.patternCycleMultiplier ?? 1;
        const playbackSteps = part.playbackSteps ?? steps * cycle;
        if (!Number.isFinite(bpm) || bpm < 40 || bpm > 300 || !Number.isInteger(steps) || steps < 8 || steps > 64 || !Number.isInteger(repeats) || repeats < 1 || repeats > 64 || (!Number.isInteger(cycle) || cycle < 1 || cycle > 8192) || !Number.isInteger(playbackSteps) || playbackSteps < 1 || playbackSteps > steps * cycle) {
            throw new Error('Invalid saved part timing.');
        }
        return (60 / bpm) * (playbackSteps / 4) * repeats;
    }

    function sourcePartDurationSeconds(part) {
        return partDurationSeconds({ ...part, playbackSteps: undefined, repeats: 1 });
    }

    function libraryKey(storage, crypto) {
        let key = storage.getItem('mygrain-song-library-key-v1');
        if (!/^[a-f0-9]{64}$/.test(key || '')) {
            key = Array.from(crypto.getRandomValues(new Uint8Array(32)), value => value.toString(16).padStart(2, '0')).join('');
            storage.setItem('mygrain-song-library-key-v1', key);
        }
        return key;
    }

    function libraryStorage(storage) {
        const values = new Map();
        return {
            persistent: Boolean(storage),
            getItem(key) {
                if (values.has(key)) return values.get(key);
                try { return storage?.getItem(key) ?? null; }
                catch { this.persistent = false; return null; }
            },
            setItem(key, value) {
                values.set(key, String(value));
                try { storage?.setItem(key, String(value)); }
                catch { this.persistent = false; }
            }
        };
    }

    function parseLibraryAccess(value) {
        if (typeof value !== 'string' || value.length > 4096) throw new Error('Choose a MYGRAIN Song Access JSON file (up to 4 KB).');
        let access;
        try { access = JSON.parse(value); }
        catch { throw new Error('This is not a valid MYGRAIN Song Access file.'); }
        if (!access || access.format !== 'mygrain-song-library-access' || access.version !== 1 || typeof access.key !== 'string' || !/^[a-f0-9]{64}$/.test(access.key)) throw new Error('This is not a supported MYGRAIN Song Access file.');
        if (access.songId != null && (typeof access.songId !== 'string' || !/^[A-Za-z0-9_-]{1,100}-[a-f0-9]{8}$/.test(access.songId))) throw new Error('The Song Access file contains an invalid song selection.');
        return { key: access.key, songId: access.songId || '' };
    }

    function armConcurrency(value) {
        const count = Number(value);
        return Number.isInteger(count) && count >= 1 && count <= 10 ? count : 2;
    }

    function playgroundRenderVersion(decoded) {
        const pg=decoded?.snapshot?.state?.modes?.wasp?.playground;
        if(pg?.enabled!==true)return 0;
        if(pg.input&&pg.input!=='all'&&(pg.mix??1)>0)return 3;
        const dynamic=Object.values(pg.modulation||{}).some(l=>l.source!=='off'&&l.amount!==0)&&(pg.motion??1)>0;
        return dynamic||(pg.mix??1)!==1?2:!['comb','combNegative'].includes(pg.mode)?1:0;
    }

    function contentKey(part) {
        return part.contentSha256 || part.sha256;
    }

    function sourceId(part) {
        return part.sourcePartId || part.id;
    }

    const loopLayers = ['A', 'B', 'C', 'D', 'V', 'W', 'P', 'O', 'L', 'X', 'Q', 'M', 'M+'];
    const kCopyTracks = ['K1', 'K2', 'K3', 'K4', 'K5'];
    const drumCopyLanes = [
        ['drumKick', 'Kick'], ['drumSnare', 'Snare'], ['drumHat', 'Hat'], ['drumPerc', 'Perc'],
        ['drumClap', 'Clap'], ['drumCymbals', 'Cymbals'], ['drumEtc', 'ETC'], ['drumRoll', 'Snare Roll']
    ];
    const eqCopyChannels = [...loopLayers, 'generated', 'sample', ...kCopyTracks, ...drumCopyLanes.map(([id]) => id)];
    const eqChannelLabel = key => key === 'generated' ? 'Generated Loop' : key === 'sample' ? 'Sample Layer' : kCopyTracks.includes(key) ? `K track ${key.slice(1)}` : drumCopyLanes.find(([id]) => id === key)?.[1] || `Loop ${key}`;
    const copyLabels = new Map([...loopLayers.map(layer => [layer, `Bastardloop ${layer}`]), ...kCopyTracks.map((id, index) => [id, `K track ${index + 1}`]), ['drums', 'Drum machine (all)'], ...drumCopyLanes.map(([id, label]) => [id, `${label} drum lane`]), ...eqCopyChannels.map(key => ['eq:' + key, `${eqChannelLabel(key)} EQ only`])]);

    function copySelection(value) {
        const values = Array.isArray(value) ? value : [value];
        if (!values.length || values.length > copyLabels.size || values.some(item => !copyLabels.has(item))) return [];
        return [...copyLabels.keys()].filter(item => values.includes(item) && !(values.includes('drums') && drumCopyLanes.some(([id]) => id === item)));
    }

    function copiedLabel(copied) {
        return copySelection(copied.layers || copied.layer).map(item => copyLabels.get(item)).join(', ');
    }

    function pasteLabel(copied, chosen) {
        const sounds = chosen.layers.filter(item => !item.startsWith('eq:')).map(item => copyLabels.get(item));
        const eqs = chosen.eqMap ? Object.entries(chosen.eqMap).map(([target, source]) => `${eqChannelLabel(source)} EQ → ${eqChannelLabel(target)}`) : chosen.layers.filter(item => item.startsWith('eq:')).map(item => copyLabels.get(item));
        return [...sounds, ...eqs].join(', ');
    }

    function pasteSelection(copied, selection) {
        const original = copySelection(copied.layers || copied.layer);
        const layers = selection ? copySelection(selection.layers) : original;
        const allowed = new Set(original.flatMap(item => item === 'drums' ? ['drums', ...drumCopyLanes.map(([id]) => id)] : [item]));
        if (!layers.length || layers.some(item => !allowed.has(item))) throw new Error('Choose destinations from the copied items.');
        let eqMap;
        if (selection) {
            eqMap = selection.eqMap;
            if (!eqMap || typeof eqMap !== 'object' || Array.isArray(eqMap) || Object.keys(eqMap).length > eqCopyChannels.length || Object.entries(eqMap).some(([target, source]) => !eqCopyChannels.includes(target) || !layers.includes('eq:' + source))) throw new Error('Choose valid EQ destination channels.');
            if (layers.some(item => item.startsWith('eq:')) && !Object.keys(eqMap).length) throw new Error('Choose at least one EQ destination.');
        }
        return { layers, ...(selection ? { eqMap: { ...eqMap } } : {}) };
    }

    function needsPortableFreeze(decoded) {
        return decoded?.snapshot?.extra?.freezeStateVersion === 1 || Boolean(decoded?.snapshot?.state?.sliders?.performanceDrumMachineLevel);
    }

    function needsQRender(decoded) {
        const state = decoded?.snapshot?.state?.q;
        return state?.enabled === true && state.sequence?.some(step => step?.notes?.length && !step.rest);
    }

    function needsDrumAccentRender(decoded) {
        const m = decoded?.snapshot?.state?.modes;
        if (m?.drumMachineEnabled !== true) return false;
        return Boolean(['kick', 'snare', 'perc'].some(kind => m.drumMachineBaseAccents?.[kind]?.some((on, i) => on && m[`drumMachine${kind[0].toUpperCase()}${kind.slice(1)}Pattern`]?.[i]))
            || m.drumMachineRoll?.accents?.some((on, i) => on && m.drumMachineRoll.pattern?.[i]));
    }

    function needsDrumRollRender(decoded) {
        const modes = decoded?.snapshot?.state?.modes;
        return modes?.drumMachineEnabled === true && modes.drumMachineRoll?.pattern?.some(Boolean);
    }

    function needsMutilatorControlsRender(decoded) {
        const snapshot=decoded?.snapshot,d=snapshot?.state?.modes?.loopD,m=d?.mutilator;
        if(!m?.enabled||m.input==='DAW')return false;
        if((!m.input||m.input==='D')&&(!d.enabled||!snapshot.assets?.some(a=>a.key==='bastardD')))return false;
        const dsp=root.MygrainMutilator||(typeof module==='object'&&module.exports?require('./mutilator-dsp.js'):null);
        if(!dsp)return false;const controls=dsp.normalize(m);return controls.amount>0&&controls.mix>0&&Object.keys(dsp.audibleControls(controls)).length>0;
    }

    function unifiedInputsVersion(decoded) {
        const m=decoded?.snapshot?.state?.modes||{},bass=m.bassFace||{},mut=m.loopD?.mutilator||{},tt=m.turntable||{},w=m.wasp||{},r=m.resonatorR||{};
        const active=v=>v?.enabled&&(v.mix??.5)>0&&(v.amount??.5)>0;
        const equalized=Object.entries(m.channelEq?.channels||{}).filter(([,v])=>v?.manualBypass!==true&&(v?.enabled||v?.automation?.read&&v.automation.points?.some(p=>p.enabled)));
        const localFx=v=>v&&(v.filterEnabled||v.reverbEnabled&&v.room>0||v.delayEnabled&&v.delay>0);
        if(equalized.length&&([bass,mut].some(active)||[tt,w,w.playground,r,m.wireWorld,m.sonicCrystal,m.bubbleChamber].some(v=>v?.enabled)||equalized.some(([key])=>localFx(m.loopFx?.channels?.[key]))))return 3;
        const characters=[{...bass,input:bass.input||'X'},{...mut,input:mut.input||'D'}].filter(active);
        const channels=m.loopFx?.channels,changed=characters.some(v=>v.input!=='DAW'&&(!channels||Object.entries(channels).some(([key,s])=>(v.input==='all'||v.input===key||v.input==='K'&&/^K[1-5]$/.test(key))&&(s.filterEnabled||s.reverbEnabled&&s.room>0||s.delayEnabled&&s.delay>0))));
        if(changed||!m.cookingPot?.enabled&&m.loopD?.enabled&&active(mut)&&(!mut.input||mut.input==='D'))return 2;
        return [bass,mut].some(v=>v.enabled&&v.input==='all'&&(v.mix??.5)>0&&(v.amount??.5)>0)||tt.enabled&&tt.input&&!['all','drums'].includes(tt.input)||w.enabled&&w.routes?.slice(0,2).some(r=>r.enabled&&(['D','DAW'].includes(r.source)||r.source==='all'&&m.loopD?.enabled)&&r.depth!==0)||r.enabled&&r.slots?.some(s=>s.enabled&&s.source==='DAW')?1:0;
    }

    function cookingPotRenderVersion(decoded,part={}) {return Math.max(Number(part.cookingPotVersion)||0,root.MygrainCookingPot?.renderVersion(decoded?.snapshot?.state?.modes)||0);}
    function needsCookingPotRender(decoded) {return decoded?.snapshot?.state?.modes?.cookingPot?.enabled===true && needsEffectOutputRender(decoded);}

    function effectOutputRenderVersion(decoded,part={}) {
        const snapshot=decoded?.snapshot,m=snapshot?.state?.modes||{},selected=v=>(Array.isArray(v)?v:String(v||'').split(',')).some(k=>!['','none'].includes(String(k).trim().toLowerCase()));
        return Math.max(Number(part.effectOutputVersion)||0,m.effectOutput?.mainMuted===true?3:0,m.generatedSampleSolo===true||['loopLayerSolo','grainLayerSolo','sourceWaveformSolo','drumMachineLaneSolos'].some(k=>selected(m[k]))||selected(snapshot?.extra?.performanceSourceLayerSolo)?2:needsEffectOutputRender(decoded)?1:0);
    }

    function needsEffectOutputRender(decoded) {
        const m=decoded?.snapshot?.state?.modes||{},w=m.wasp||{};
        return !!(w.enabled||w.playground?.enabled||m.turntable?.enabled||m.resonatorR?.enabled||m.wireWorld?.enabled||m.sonicCrystal?.enabled||m.bubbleChamber?.enabled||m.bassFace?.enabled||m.loopD?.mutilator?.enabled);
    }

    function needsKickRoutingRender(decoded) {
        const state=decoded?.snapshot?.state || {}, modes=state.modes || {}, sliders=state.sliders || {};
        const control=(key, fallback)=>{const n=Number(sliders[key] ?? fallback);return Number.isFinite(n)?n:fallback;};
        if(modes.drumMachineEnabled===false || modes.finalCompressorSidechainSource!=='kick'
            || !decoded?.snapshot?.assets?.some(a=>a.key==='drumKick') || !modes.drumMachineKickPattern?.some(Boolean)
            || control('drumMachineKickLevel',100)<=0 || control('performanceDrumMachineLevel',65)<=0
            || (modes.drumMachineLaneSolos?.length && !modes.drumMachineLaneSolos.includes('kick'))) return false;
        const muted=Boolean(state.fxMuted ?? modes.fxMuted), amount=control('finalSidechainAmount',0), comp=control('finalCompressorAmount',30);
        if(!muted && amount>.1 && comp>0)return false;
        const pg=modes.wasp?.playground;
        return (modes.drumMachineDirectOutput!==true && modes.drumMachineDirectOutput!==undefined && !(pg?.enabled&&pg.routeKick))
            || control('finalSidechainKickLevel',100)!==100 || (!muted&&amount>.1&&comp<=0);
    }

    function needsDrumSampleRender(decoded) {
        const modes = decoded?.snapshot?.state?.modes;
        return modes?.drumMachineEnabled === true && (
            needsDrumRollRender(decoded) || ['Kick', 'Snare', 'Hat', 'Perc'].some(kind => modes[`drumMachine${kind}Pattern`]?.some(Boolean))
            || Object.values(modes.drumMachineExtraTracks || {}).some(track => track?.pattern?.some(Boolean)));
    }

    function needsKReverbRender(decoded) {
        const modes = decoded?.snapshot?.state?.modes;
        return modes?.bastardLoopKEnabled === true && Number(modes.bastardLoopKLevel ?? .5) > 0
            && modes.kMultitrack?.tracks?.some(track => track.enabled !== false && track.mute !== true
                && Number(track.level ?? 1) > 0 && Number(track.processing?.reverbMix) > 0);
    }

    function qRenderVersion(decoded) {
        if (!needsQRender(decoded)) return 0;
        const state = decoded.snapshot.state.q;
        if (['osc','grain','sample'].includes(state.soundSource)) return 9;
        if (state.chordHold === true && state.arpEnabled !== true) return 8;
        if (Number(state.sampleLength ?? 1) < 1 || Number(state.sampleDecay ?? 1) < 1) return 7;
        if (state.performanceVersion === 6 || state.arpPattern === 'custom' || state.sequence?.some(step => step?.accent === true)) return 6;
        return state.instrument === 'strings' ? 5 : Number(state.room) > 0 ? 4 : state.arpEnabled === true ? 3 : 1;
    }

    class Controller {
        constructor(adapter, options = {}) {
            this.adapter = adapter;
            this.document = options.document || root.document;
            let storage = options.storage;
            if (storage === undefined) {
                try { storage = root.localStorage; } catch { storage = null; }
            }
            this.storage = libraryStorage(storage);
            this.crypto = options.crypto || root.crypto;
            this.fetch = options.fetch || root.fetch.bind(root);
            this.api = options.api || `${root.location.origin}/mygrain/api/songs`;
            this.key = libraryKey(this.storage, this.crypto);
            this.song = null;
            this.songs = [];
            this.cache = new Map();
            this.snapshots = new Map();
            this.partManifests = false;
            this.serverPreparation = false;
            this.partAudioAssets = false;
            this.renders = new Map();
            this.renderSources = new Map();
            this.renderLoads = new Map();
            this.renderBytes = 0;
            this.phonePreparation = /iPhone|iPad|iPod|Android/i.test(root.navigator?.userAgent || '')
                || (root.navigator?.platform === 'MacIntel' && root.navigator?.maxTouchPoints > 1);
            this.renderLimitBytes = options.renderLimitBytes ?? (this.phonePreparation ? 24 : 96) * 1024 * 1024;
            this.renderStore = options.renderStore || new root.MygrainSongStorage.RenderStore();
            this.sourceStore = options.sourceStore || new root.MygrainSongStorage.SourceStore();
            this.memoryBudget = new root.MygrainSongStorage.MemoryBudget(options.preparationLimitBytes ?? (this.phonePreparation ? 96 : 192) * 1024 * 1024, true);
            this.downloadBudget = new root.MygrainSongStorage.MemoryBudget(64 * 1024 * 1024);
            this.armConcurrency = this.phonePreparation ? 1 : armConcurrency(this.storage.getItem('mygrain-song-arm-concurrency-v1'));
            this.playback = null;
            this.editing = null;
            this.amendLoading = null;
            this.loopClipboard = null;
            this.expandedParts = new Set();
            this.audioCache = { buffers: new Map(), bytes: 0 };
            this.armed = false;
            this.playing = false;
            this.loopSong = false;
            this.loopPartId = null;
            this.active = null;
            this.prepared = null;
            this.busy = false;
            this.generation = 0;
            this.timer = null;
            this.abort = null;
            this.card = this.document.getElementById('songBetaCard');
            this.revisionConflict = false;
            this.lockCanWrite = false;
            this.lease = new root.MygrainSongLocks.EditingLease({
                storage: this.storage, crypto: this.crypto, agent: root.navigator?.userAgent || '',
                request: (path, options) => this.request(path, options),
                onChange: () => {
                    const writable = this.canEditSong();
                    if (writable !== this.lockCanWrite) { this.lockCanWrite = writable; this.render(); }
                    else this.renderLockUi();
                }
            });
            const deviceName = this.element('songBetaDeviceName');
            if (deviceName) deviceName.value = this.lease.device.label;
            this.bind();
        }

        element(id) {
            return this.document.getElementById(id);
        }

        preparationConcurrency() {
            return this.phonePreparation ? 1 : armConcurrency(this.armConcurrency);
        }

        status(message, error = false) {
            const status = this.element('songBetaStatus');
            status.textContent = message;
            status.classList.toggle('song-beta-error', error);
        }

        startArmFeedback(generation, parts) {
            let view = this.armFeedbackView;
            const container = this.element('songBetaTransportInfo');
            if (!view && this.document.createElement && container?.append) {
                const panel = this.document.createElement('div');
                panel.className = 'song-beta-arm-feedback';
                panel.setAttribute('role', 'group');
                panel.setAttribute('aria-label', 'Song cache preparation');
                const meter = this.document.createElement('div');
                meter.className = 'song-beta-arm-meter';
                meter.setAttribute('role', 'progressbar');
                meter.setAttribute('aria-label', 'Song cache preparation (indeterminate)');
                const detail = this.document.createElement('p');
                detail.setAttribute('role', 'status');
                detail.setAttribute('aria-live', 'polite');
                const clock = this.document.createElement('p');
                clock.setAttribute('aria-live', 'off');
                panel.append(meter, detail, clock);
                container.append(panel);
                view = this.armFeedbackView = { panel, meter, detail, clock };
            }
            const feedback = this.armFeedback = {
                generation, started: root.performance?.now() ?? Date.now(), state: 'running',
                stage: 'Waiting for audio to be ready', total: parts.length, placements: this.song.parts.length,
                completed: 0, reused: 0, current: new Map(), timer: null, paints: new Set()
            };
            this.element('songBetaArm')?.setAttribute?.('aria-busy', 'true');
            this.paintArmFeedback(feedback);
            const tick = () => {
                if (this.armFeedback !== feedback || feedback.state !== 'running' || generation !== this.generation) return;
                this.paintArmFeedback(feedback, true);
                feedback.timer = root.setTimeout(tick, 1000);
            };
            feedback.timer = root.setTimeout(tick, 1000);
        }

        paintArmFeedback(feedback, heartbeat = false) {
            const view = this.armFeedbackView;
            if (!view || this.armFeedback !== feedback) return;
            if (!heartbeat) {
                view.panel.setAttribute('data-state', feedback.state);
                view.meter.hidden = feedback.state !== 'running';
                view.meter.setAttribute('aria-busy', String(feedback.state === 'running'));
                const current = [...feedback.current.values()].map(entry => `${entry.name}: ${entry.stage}`).join(' · ');
                const detail = `${feedback.stage} · ${feedback.completed}/${feedback.total} unique parts complete (${feedback.reused} reused) · ${feedback.placements} placements${current ? ` · ${current}` : ''}`;
                view.detail.textContent = detail;
                view.meter.setAttribute('aria-valuetext', detail);
            }
            const seconds = Math.floor(((feedback.ended ?? (root.performance?.now() ?? Date.now())) - feedback.started) / 1000);
            view.clock.textContent = `${feedback.state === 'running' ? 'Arming Song Cache' : 'Song Cache'} · ${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')} elapsed${feedback.state === 'running' ? ' · Page responsive; completion time unknown. Keep this page open.' : ''}`;
        }

        armStage(generation, stage, part = null) {
            if (generation === this.generation && this.amendLoading && part?.id === this.amendLoading.id) {
                this.amendLoading.stage = stage;
                const progress = this.element('songBetaAmendProgress');
                if (progress) progress.textContent = `Please wait… ${stage}. Ready when this part turns orange.`;
                const wait = this.element('songBetaAmendWait');
                if (wait) wait.textContent = `Please wait — loading ${part.name} for Amend… ${stage}. Ready when the part turns orange.`;
            }
            const feedback = this.armFeedback;
            if (!feedback || feedback.state !== 'running' || feedback.generation !== generation || generation !== this.generation) return;
            if (part) feedback.current.set(sourceId(part), { name: part.name, stage });
            else feedback.stage = stage;
            this.paintArmFeedback(feedback);
        }

        async paintBeforeArmWork(generation) {
            const feedback = this.armFeedback;
            if (!root.requestAnimationFrame || !feedback || feedback.generation !== generation || feedback.state !== 'running') return;
            await new Promise(resolve => {
                let frame;
                let fallback;
                const finish = () => {
                    root.cancelAnimationFrame(frame);
                    root.clearTimeout(fallback);
                    feedback.paints.delete(finish);
                    resolve();
                };
                feedback.paints.add(finish);
                frame = root.requestAnimationFrame(() => { frame = root.requestAnimationFrame(finish); });
                fallback = root.setTimeout(finish, 100);
            });
            if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
        }

        finishArmFeedback(generation, state, message) {
            const feedback = this.armFeedback;
            if (!feedback || feedback.generation !== generation || feedback.state !== 'running') return;
            feedback.state = state;
            feedback.stage = message;
            feedback.ended = root.performance?.now() ?? Date.now();
            root.clearTimeout(feedback.timer);
            feedback.timer = null;
            for (const finish of [...feedback.paints]) finish();
            feedback.current.clear();
            this.element('songBetaArm')?.setAttribute?.('aria-busy', 'false');
            this.paintArmFeedback(feedback);
        }

        async request(path = '', options = {}) {
            const mutation = options.method === 'POST' && path && !/^\/[^/]+\/lock\//.test(path) && !/\/parts\/[a-f0-9]{32}\/(?:render|server-arm)(?:\?|$)/.test(path);
            if (mutation) this.requireEditing();
            const response = await this.fetch(`${this.api}${path}`, {
                ...options,
                cache: 'no-store',
                headers: { 'X-Mygrain-Song-Key': this.key, ...(mutation ? { ...this.lease.credentials(), 'If-Match': `"${this.song.revision}"` } : {}), ...options.headers }
            });
            if (options.binary && response.ok) {
                const limit = options.maxBinaryBytes;
                if (limit !== undefined) {
                    if (Number(response.headers?.get('Content-Length')) > limit) {
                        await response.body?.cancel();
                        throw new Error('Saved sound exceeds its declared size.');
                    }
                    if (response.body?.getReader) {
                        const reader = response.body.getReader(), chunks = [];
                        let length = 0;
                        try {
                            while (true) {
                                const { done, value } = await reader.read();
                                if (done) break;
                                length += value.byteLength;
                                if (length > limit) throw new Error('Saved sound exceeds its declared size.');
                                chunks.push(value);
                            }
                            const bytes = new Uint8Array(length);
                            let offset = 0;
                            for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
                            return bytes.buffer;
                        } finally { await reader.cancel().catch(() => {}); reader.releaseLock(); }
                    }
                }
                const bytes = await response.arrayBuffer();
                if (limit !== undefined && bytes.byteLength > limit) throw new Error('Saved sound exceeds its declared size.');
                return bytes;
            }
            const payload = await response.json().catch(() => ({}));
            if (!response.ok || !payload.ok) {
                if (mutation && response.status === 423) this.lease.lost(payload);
                if (mutation && payload.code === 'SONG_REVISION_CONFLICT') this.revisionConflict = true;
                const error = new Error(payload.error || `Song request failed (${response.status}).`);
                Object.assign(error, { code: payload.code, lock: payload.lock });
                throw error;
            }
            return payload;
        }

        canEditSong() {
            return Boolean(this.song && this.lease?.songId === this.song.id && this.lease.canWrite && !this.revisionConflict);
        }

        requireEditing() {
            if (!this.canEditSong()) throw new Error(this.revisionConflict ? 'This song changed on the server. Refresh Songs before saving; your live pattern is still available.' : 'This song is read-only. Use Edit Song first; an expired session must obtain a new lock before saving.');
        }

        async ensureEditing(part) {
            if (!this.song) throw new Error('Create or choose a song first.');
            if (this.revisionConflict) this.requireEditing();
            const songId = this.song.id;
            const revision = this.song.revision;
            const library = this.key;
            if (!this.canEditSong()) {
                this.status('Checking editing access…');
                if (this.lease.token) await this.lease.check();
                if (!this.canEditSong()) {
                    if (this.lease.token) throw Object.assign(new Error(this.lease.message || 'Editing is paused until this device’s connection is verified. Reconnect and try again.'), { code: 'SONG_EDIT_UNVERIFIED' });
                    await this.beginEditing();
                }
            }
            this.requireEditing();
            if (this.key !== library || this.song.id !== songId || this.song.revision !== revision) throw new Error('The song changed while requesting editing. Refresh Songs before trying again; your live pattern is still available.');
            if (part && !this.song.parts.some(entry => entry.id === part.id && entry.sha256 === part.sha256)) throw new Error('The saved part changed. Refresh Songs before editing it.');
        }

        renderLockUi() {
            const status = this.element('songBetaLockStatus');
            if (status) {
                status.textContent = !this.song ? 'Choose a song. One editing session per song; everyone else can still play it.'
                    : this.revisionConflict ? 'Song changed on the server: Refresh Songs before saving. Your live pattern is still available.'
                    : this.lease.message || (this.canEditSong() ? `Editing on ${this.lease.device.label}. Finish Editing releases access for another device.`
                    : this.lease.lock ? `Read-only: being edited on ${this.lease.lock.label}. Last confirmed expiry: ${new Date(this.lease.lock.expiresAt * 1000).toLocaleTimeString()}. Playback is available.`
                    : 'Ready to edit. Changes request editing access automatically. A same-name crashed session can be cleared explicitly; other device names stay protected.');
                status.classList.toggle('song-beta-error', Boolean(this.lease.message || this.revisionConflict));
            }
            const edit = this.element('songBetaEditSong');
            if (edit) edit.disabled = this.busy || !this.song || Boolean(this.lease.token);
            const finish = this.element('songBetaFinishEditing');
            if (finish) finish.disabled = this.busy || !this.lease.token;
            const device = this.element('songBetaDeviceName');
            if (device) device.disabled = this.busy || Boolean(this.lease.token);
            const recover = this.element('songBetaRecoverLock');
            if (recover) {
                recover.hidden = !this.canRecoverLock();
                recover.disabled = this.busy || this.playing || this.revisionConflict;
            }
        }

        canRecoverLock() {
            const label = (this.element('songBetaDeviceName')?.value || this.lease.device.label).trim();
            return Boolean(this.song && !this.canEditSong() && this.lease.lock?.recoveryId
                && label && label.toLowerCase() === this.lease.lock.label.trim().toLowerCase());
        }

        async recoverEditingLock() {
            if (!this.canRecoverLock()) throw new Error('Only a lock with the same device name can be cleared here.');
            const recoveryId = this.lease.lock.recoveryId;
            const label = this.lease.lock.label;
            if (!root.confirm(`Clear the editing lock for ${label} and edit this song here? Use this after a crash. Any other session using that name will lose editing access. Saved song data and your unsaved live pattern stay unchanged.`)) return;
            await this.beginEditing(recoveryId);
        }

        async beginEditing(recoveryId = null) {
            if (!this.song) throw new Error('Choose a song first.');
            if (this.revisionConflict) throw new Error('Refresh Songs before editing the changed song.');
            const label = (this.element('songBetaDeviceName')?.value || this.lease.device.label).trim();
            if (!label || label.length > 100 || /[\x00-\x1f]/.test(label)) throw new Error('Use a device name between 1 and 100 characters.');
            const song = await this.lease.acquire(this.song.id, this.song.revision, label, recoveryId);
            this.lease.device.label = label;
            this.storage.setItem('mygrain-song-device-label-v1', label);
            this.song = song;
            this.songs = this.songs.map(entry => entry.id === song.id ? song : entry);
            this.status(`Editing ${song.name} on ${label}. Finish Editing releases the song for other devices.`);
        }

        async finishEditing() {
            if (this.editing && !root.confirm('Finish editing without saving this amendment? The server part is unchanged and your live pattern will remain available.')) return;
            this.editing = null;
            await this.lease.release();
            this.status('Editing released for other devices. Your next change requests access automatically. Your live pattern and playback are unchanged.');
        }

        cancelAmendment() {
            this.editing = null;
            this.status('Amendment cancelled. The server part is unchanged; the live pattern remains available for New Part.');
            this.render();
        }

        async run(action) {
            if (this.busy) return;
            this.busy = true;
            this.render();
            try {
                await action();
            } catch (error) {
                if (error.name !== 'AbortError') this.status(error.message, true);
            } finally {
                this.busy = false;
                this.render();
            }
        }

        bind() {
            this.element('songBetaConvertK')?.addEventListener('click', () => this.run(() => this.convertKTracks()));
            this.element('songBetaConvertFx')?.addEventListener('click', () => this.run(() => this.convertLoopFx()));
            this.element('songBetaConvertW')?.addEventListener('click', () => this.run(() => this.convertWLoop()));
            this.element('songBetaEditSong')?.addEventListener('click', () => this.run(() => this.beginEditing()));
            this.element('songBetaRecoverLock')?.addEventListener('click', () => this.run(() => this.recoverEditingLock()));
            this.element('songBetaDeviceName')?.addEventListener('input', () => this.renderLockUi());
            this.element('songBetaFinishEditing')?.addEventListener('click', () => this.run(() => this.finishEditing()));
            this.element('songBetaBackupAccess')?.addEventListener('click', () => this.run(() => this.backupLibraryAccess()));
            this.element('songBetaOpenAccess')?.addEventListener('click', () => this.element('songBetaAccessFile')?.click());
            this.element('songBetaAccessFile')?.addEventListener('change', event => {
                const file = event.target.files?.[0];
                event.target.value = '';
                if (file) this.run(() => this.openLibraryAccess(file));
            });
            for (const id of ['performanceMainStopAllBtn', 'performancePanicBtn', 'resetEngineBtn', 'performanceResetPatchBtn']) {
                this.element(id)?.addEventListener('click', () => { if (this.playing || this.abort) this.stop(); }, true);
            }
            root.addEventListener?.('pagehide', () => {
                if (this.playing || this.abort) this.stop();
                this.lease.release({ keepalive: true });
            });
            root.addEventListener?.('pageshow', () => this.lease.check());
            this.document.addEventListener?.('visibilitychange', () => { if (!this.document.hidden) this.lease.check(); });
            this.element('songBetaNewSong').addEventListener('click', () => this.run(() => this.newSong()));
            this.element('songBetaRenameSong')?.addEventListener('click', () => this.run(() => this.renameSong()));
            this.element('songBetaNewPart').addEventListener('click', () => this.run(() => this.newPart()));
            this.element('songBetaPasteParts')?.addEventListener('click', event => this.openPastePartsPicker(event.currentTarget));
            this.element('songBetaSavePart').addEventListener('click', () => this.run(() => this.savePart()));
            this.element('songBetaCancelEdit').addEventListener('click', () => this.cancelAmendment());
            this.element('songBetaArm').addEventListener('click', () => this.run(() => this.arm()));
            this.element('songBetaArmConcurrency')?.addEventListener('change', event => {
                this.armConcurrency = this.phonePreparation ? 1 : armConcurrency(event.target.value);
                this.storage.setItem('mygrain-song-arm-concurrency-v1', String(this.armConcurrency));
                event.target.value = String(this.armConcurrency);
            });
            this.element('songBetaPlay').addEventListener('click', () => this.run(() => this.playSong()));
            this.element('songBetaLoop')?.addEventListener('click', () => {
                if (this.busy || this.playing || this.editing) return;
                this.loopSong = !this.loopSong;
                this.status(this.loopSong ? 'Loop Song on. Play Song repeats the arrangement until Stop Song.' : 'Loop Song off. Play Song plays the arrangement once.');
                this.render();
            });
            this.element('songBetaExport')?.addEventListener('click', () => this.run(() => this.exportSong()));
            this.element('songBetaStop').addEventListener('click', () => this.stop());
            this.element('songBetaRefresh').addEventListener('click', () => this.run(() => this.refresh()));
            this.element('songBetaSongs').addEventListener('change', event => {
                const id = event.target.value;
                return this.run(async () => {
                    this.cancel(true);
                    this.invalidate();
                    this.editing = null;
                    this.song = id ? (await this.request(`/${encodeURIComponent(id)}`)).song : null;
                    this.revisionConflict = false;
                    await this.lease.watch(this.song?.id);
                    this.storage.setItem('mygrain-song-selected-v1', id);
                    this.status(this.song ? `Loaded ${this.song.name}. Arm Cache before playing the order.` : 'Create or choose a song.');
                });
            });
        }

        cancel(stopAudio = false, stopOptions = {}) {
            this.finishArmFeedback(this.generation, 'cancelled', 'Arming cancelled');
            this.generation += 1;
            this.renderLoads.clear();
            if (this.abort) this.abort.abort();
            this.abort = null;
            if (this.timer !== null) root.clearTimeout(this.timer);
            this.timer = null;
            this.playback?.stop();
            this.playback = null;
            if (stopAudio && (this.playing || this.active)) this.adapter.stop(stopOptions);
            this.playing = false;
            this.loopPartId = null;
            this.active = null;
            this.prepared = null;
        }

        stop() {
            this.cancel();
            this.adapter.stop();
            this.status('Song stopped. Saved parts and armed cache are unchanged.');
            this.render();
        }

        invalidate(preserve = false) {
            this.armed = false;
            if (preserve) {
                const parts = new Map((this.song?.parts || []).map(part => [sourceId(part), part]));
                for (const [id, decoded] of this.cache) {
                    if (!parts.has(id) || (decoded.contentSha256 || decoded.sourceSha256) !== contentKey(parts.get(id))) this.releasePart({ id });
                    else decoded.sourceSha256 = parts.get(id).sha256;
                }
                for (const [id, decoded] of this.snapshots) {
                    if (!parts.has(id) || decoded.contentSha256 !== contentKey(parts.get(id))) this.snapshots.delete(id);
                }
                for (const [id, source] of this.renderSources) {
                    if (!parts.has(id) || source !== contentKey(parts.get(id))) this.renderSources.delete(id);
                }
                for (const id of this.renders.keys()) {
                    if (!parts.has(id) || this.renderSources.get(id) !== contentKey(parts.get(id))) {
                        this.renders.delete(id);
                        this.renderSources.delete(id);
                    }
                }
                const retained = new Set([...this.cache.values()].flatMap(decoded => [...(decoded.buffers?.values() || [])]));
                this.audioCache.buffers = new Map([...this.audioCache.buffers].filter(([, buffer]) => retained.has(buffer)));
                this.audioCache.bytes = [...this.audioCache.buffers.values()].reduce((bytes, buffer) => bytes + buffer.length * buffer.numberOfChannels * 4, 0);
                this.renderBytes = [...this.renders.values()].reduce((bytes, buffer) => bytes + buffer.length * buffer.numberOfChannels * 4, 0);
                return;
            }
            for (const id of [...this.cache.keys()]) this.releasePart({ id });
            this.snapshots.clear();
            this.renders.clear();
            this.renderSources.clear();
            this.renderBytes = 0;
            this.audioCache = { buffers: new Map(), bytes: 0 };
        }

        async refresh() {
            if (this.editing && !root.confirm('Refresh Songs and cancel the unsaved amendment? Your live pattern will remain available.')) return;
            const selected = this.song?.id || this.storage.getItem('mygrain-song-selected-v1');
            const payload = await this.request();
            this.cancel(true);
            this.editing = null;
            this.songs = payload.songs;
            this.partManifests = payload.features?.partManifests === 1;
            this.partAudioAssets = payload.features?.partAudioAssets === 1;
            this.serverPreparation = payload.features?.serverPreparation === 1;
            const previous = this.song?.id;
            this.song = this.songs.find(song => song.id === selected) || null;
            this.revisionConflict = false;
            await this.lease.watch(this.song?.id);
            this.invalidate(Boolean(previous && previous === this.song?.id));
            this.status(this.song ? `Loaded ${this.song.name}. ${this.song.parts.length} saved parts.` : 'Create a song, then save named parts.');
        }

        async backupLibraryAccess() {
            if (this.playing || this.editing) throw new Error('Stop the song and finish the amendment before backing up library access.');
            const saved = await this.adapter.downloadLibraryAccess({ format: 'mygrain-song-library-access', version: 1, key: this.key, songId: this.song?.id || null });
            if (saved === false) { this.status('Song Access backup cancelled. No library settings changed.'); return; }
            this.status('Song Access file downloaded. Keep it private: it grants access to all songs in this library. Open it on another device to load the original songs and audio from the server.');
        }

        async openLibraryAccess(file) {
            if (this.playing || this.editing) throw new Error('Stop the song and finish the amendment before opening another library.');
            if (!file || file.size > 4096) throw new Error('Choose a MYGRAIN Song Access JSON file (up to 4 KB).');
            const access = parseLibraryAccess(await file.text());
            if (access.key !== this.key && this.songs.length && !root.confirm('Switch song libraries? Back up this device’s current Song Access first. No server songs will be deleted.')) return;
            const payload = await this.request('', { headers: { 'X-Mygrain-Song-Key': access.key } });
            if (!Array.isArray(payload.songs)) throw new Error('The song server returned an invalid library. Current access is unchanged.');
            this.cancel(true);
            this.invalidate();
            await this.lease.watch(null);
            this.key = access.key;
            this.loopClipboard = null;
            this.storage.setItem('mygrain-song-library-key-v1', this.key);
            this.songs = payload.songs;
            this.partManifests = payload.features?.partManifests === 1;
            this.partAudioAssets = payload.features?.partAudioAssets === 1;
            this.serverPreparation = payload.features?.serverPreparation === 1;
            this.song = this.songs.find(song => song.id === access.songId) || this.songs[0] || null;
            this.storage.setItem('mygrain-song-selected-v1', this.song?.id || '');
            this.editing = null;
            this.expandedParts.clear();
            this.revisionConflict = false;
            await this.lease.watch(this.song?.id);
            this.status(`Opened server library: ${this.songs.length} songs. Recall restores editable settings and original audio; Arm Cache loads or prepares server playback. ${this.storage.persistent ? 'Access is remembered on this device.' : 'Browser storage is unavailable; reopen your Song Access file after each reload.'}`);
        }

        acceptSong(song) {
            const preserve = this.song?.id === song.id;
            this.editing = null;
            this.song = song;
            this.songs = [...this.songs.filter(entry => entry.id !== song.id), song];
            this.storage.setItem('mygrain-song-selected-v1', song.id);
            this.invalidate(preserve);
        }

        uniqueParts() {
            const parts = new Map();
            for (const part of this.song?.parts || []) {
                if (!parts.has(sourceId(part))) parts.set(sourceId(part), part);
            }
            return [...parts.values()];
        }

        async reusePart(part) {
            if (this.playing || this.editing) throw new Error('Stop the song and finish the amendment before reusing a part.');
            await this.ensureEditing(part);
            const wasArmed = this.armed;
            this.cancel(true, { hardCut: true });
            const result = await this.request(`/${encodeURIComponent(this.song.id)}/parts/${part.id}/reuse?sha256=${part.sha256}`, { method: 'POST' });
            this.acceptSong(result.song);
            this.armed = wasArmed && this.song.parts.every(entry => this.isPartReady(entry));
            this.status(`Added another use of ${part.name} at the end of the song. Move it with the arrows. Audio and amendments are shared; order and repeat counts are independent. No sounds or renders were copied.`);
        }

        async fullCopyPart(part) {
            if (this.playing || this.editing) throw new Error('Stop the song and finish the amendment before making a full copy.');
            await this.ensureEditing(part);
            const wasArmed = this.armed;
            const sourceReady = this.isPartReady(part);
            this.status(`Making a full independent copy of ${part.name}…`);
            const result = await this.request(`/${encodeURIComponent(this.song.id)}/parts/${part.id}/full-copy?sha256=${part.sha256}`, { method: 'POST' });
            this.acceptSong(result.song);
            const copied = this.song.parts.find(entry => entry.id === result.partId);
            if (copied && sourceReady && copied.sha256 === part.sha256 && copied.render?.sha256 === part.render?.sha256 && this.hasSavedRender(copied)) {
                this.renderSources.set(copied.id, contentKey(copied));
            }
            this.armed = wasArmed && this.song.parts.every(entry => this.isPartReady(entry));
            if (copied) this.expandedParts.add(`${this.song.id}:${copied.id}`);
            this.status(`Added ${copied?.name || 'the full copy'} at the end of the song. It has independent saved sounds and settings: Amend either part without changing the other. Your live pattern is unchanged.`);
        }

        async newSong() {
            const name = this.element('songBetaName').value.trim();
            if (!name) throw new Error('Enter a song name first.');
            const result = await this.request('', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }) });
            this.cancel(true);
            await this.lease.watch(result.song.id);
            this.acceptSong(result.song);
            this.revisionConflict = false;
            await this.beginEditing();
            this.element('songBetaName').value = '';
            this.status(`Created ${this.song.name} on the server. Set up a pattern and save New Part.`);
        }

        async renameSong() {
            if (!this.song) throw new Error('Create or choose a song first.');
            if (this.playing || this.editing) throw new Error('Stop the song and finish the amendment before renaming.');
            const value = root.prompt('Song name', this.song.name);
            if (value === null) return;
            const name = value.trim();
            if (!name || name.length > 100 || /[\x00-\x1f]/.test(name)) throw new Error('Use a song name between 1 and 100 characters.');
            if (name === this.song.name) return;
            await this.ensureEditing();
            const wasArmed = this.armed;
            const result = await this.request(`/${encodeURIComponent(this.song.id)}/rename`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name })
            });
            this.song = result.song;
            this.songs = this.songs.map(song => song.id === result.song.id ? result.song : song);
            this.invalidate(true);
            this.armed = wasArmed && this.song.parts.length > 0 && this.song.parts.every(part => this.isPartReady(part));
            this.status(`Renamed song to ${name}. Saved parts and unchanged cached audio are retained.`);
        }

        async newPart(options = {}) {
            if (!this.song) throw new Error('Create or choose a song first.');
            const name = String(options.name ?? this.element('songBetaPartName').value).trim();
            const repeats = Number(options.repeats ?? this.element('songBetaRepeats').value);
            if (!name) throw new Error('Enter a part name, such as Intro or Verse 1.');
            if (!Number.isInteger(repeats) || repeats < 1 || repeats > 64) throw new Error('Choose 1–64 pattern repeats.');
            await this.ensureEditing();
            const songId = this.song.id;
            this.status('Capturing complete settings, patterns, and current audio…');
            const blob = options.blob || await this.adapter.capture();
            if (blob.size > 128 * 1024 * 1024) throw new Error('This part exceeds the 128 MB upload limit. Shorten its source audio.');
            if (options.signal?.aborted) throw new DOMException('Cancelled', 'AbortError');
            this.status(`Saving ${name} and its sounds to the song folder…`);
            const result = await this.request(`/${encodeURIComponent(songId)}/parts?name=${encodeURIComponent(name)}&repeats=${repeats}`, {
                method: 'POST', headers: { 'Content-Type': 'application/zip' }, body: blob, ...(options.signal ? { signal: options.signal } : {})
            });
            this.acceptSong(result.song);
            if (options.name === undefined) this.element('songBetaPartName').value = '';
            this.active = this.song.parts.at(-1).id;
            this.status(`Saved ${name}, including ${this.song.parts.at(-1).audioAssets} audio assets. Existing parts are unchanged.`);
            return this.song.parts.at(-1);
        }

        async readPart(part, generation = this.generation) {
            if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
            this.armStage(generation, 'Waiting for download memory', part);
            const releaseDownload = await this.downloadBudget.acquire(Number(part.bytes) || 128 * 1024 * 1024, this.abort?.signal);
            try {
                if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
                const cacheKey = JSON.stringify([this.key, this.song.id, sourceId(part), part.sha256]);
                this.armStage(generation, 'Checking local original sounds', part);
                let body = await this.sourceStore.get(cacheKey);
                if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
                const digestOf = async value => Array.from(new Uint8Array(await this.crypto.subtle.digest('SHA-256', value)), value => value.toString(16).padStart(2, '0')).join('');
                let cached = false;
                if (body) {
                    try { cached = await digestOf(body) === part.sha256; } catch { /* Optional cache damage must fall back to the server. */ }
                }
                if (body && !cached) { body = null; await this.sourceStore.delete(cacheKey); }
                if (!cached) {
                    this.armStage(generation, 'Downloading original sounds', part);
                    body = await this.request(`/${encodeURIComponent(this.song.id)}/parts/${part.id}`, { binary: true, signal: this.abort?.signal });
                }
                this.armStage(generation, 'Checking saved part integrity', part);
                const digest = cached ? part.sha256 : await digestOf(body);
                if (digest !== part.sha256) throw new Error(`Saved audio integrity check failed for ${part.name}.`);
                if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
                this.armStage(generation, 'Inspecting saved part', part);
                await this.paintBeforeArmWork(generation);
                const info = this.adapter.inspectPart(body);
                if (!cached) await this.sourceStore.put(cacheKey, body);
                if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
                this.snapshots.set(sourceId(part), { snapshot: info.snapshot, decodedBytes: info.decodedBytes, fxBytes: info.fxBytes, contentSha256: contentKey(part), upgradePending: Boolean(info.upgrade), upgradeExplicitOnly: Boolean(info.upgrade?.explicitOnly) });
                return { body, ...info, releaseDownload };
            } catch (error) { releaseDownload(); throw error; }
        }

        async readPartMetadata(part, generation = this.generation) {
            if (!this.partManifests || !this.adapter.inspectSnapshot) return this.readPart(part, generation);
            if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
            this.armStage(generation, 'Checking saved-part metadata', part);
            const payload = await this.request(`/${encodeURIComponent(this.song.id)}/parts/${part.id}/manifest?sha256=${part.sha256}`, { signal: this.abort?.signal });
            if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
            if (payload.format !== 'mygrain-song-part-manifest' || payload.version !== 1 || payload.sourceSha256 !== part.sha256) {
                throw new Error(`Saved metadata integrity check failed for ${part.name}. Refresh Songs and arm again.`);
            }
            const info = this.adapter.inspectSnapshot(payload.snapshot);
            info.audioAssets = payload.audioAssets;
            this.snapshots.set(sourceId(part), { snapshot: info.snapshot, audioAssets: info.audioAssets, decodedBytes: info.decodedBytes, fxBytes: info.fxBytes, contentSha256: contentKey(part), upgradePending: Boolean(info.upgrade), upgradeExplicitOnly: Boolean(info.upgrade?.explicitOnly) });
            return info;
        }

        async prepareOnServer(part, generation) {
            const songId = this.song.id, revision = this.song.revision;
            const path = `/${encodeURIComponent(songId)}/parts/${part.id}/server-arm?sha256=${part.sha256}`;
            const signal = this.abort?.signal;
            let reply = await this.request(path, { method: 'POST', signal });
            const deadline = Date.now() + 12 * 60 * 1000;
            while (reply.job?.state !== 'done') {
                if (signal?.aborted || generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
                if (['failed', 'missing'].includes(reply.job?.state)) throw new Error(reply.job.message);
                if (!['queued', 'running'].includes(reply.job?.state)) throw new Error('Unexpected server preparation response.');
                if (Date.now() > deadline) throw new Error('Server preparation is taking too long. Arm Cache can check again; source audio is unchanged.');
                this.armStage(generation, 'Preparing audio on server', part);
                this.status(`Preparing ${part.name} on the server to stay within this device’s audio memory limit…`);
                await new Promise((resolve, reject) => {
                    const abort = () => { clearTimeout(timer); reject(new DOMException('Cancelled', 'AbortError')); };
                    const timer = setTimeout(() => { signal?.removeEventListener('abort', abort); resolve(); }, 1000);
                    signal?.addEventListener('abort', abort, { once: true });
                    if (signal?.aborted) { signal.removeEventListener('abort', abort); abort(); }
                });
                reply = await this.request(path, { signal });
            }
            if (signal?.aborted || generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
            const saved = reply.song?.parts.find(entry => entry.id === part.id && entry.sha256 === part.sha256);
            if (reply.song?.id !== songId || reply.song.revision !== revision || !saved?.render || saved.render.sourceSha256 !== part.sha256) {
                throw new Error('The Song changed during server preparation. Refresh Songs before arming again.');
            }
            this.song = { ...this.song, parts: this.song.parts.map(entry => sourceId(entry) === sourceId(part) ? { ...entry, render: saved.render } : entry) };
            this.songs = this.songs.map(song => song.id === songId ? this.song : song);
            if (!this.hasSavedRender(saved)) throw new Error('The server returned an incompatible playback render. Refresh Songs and try Arm Cache again.');
            return saved;
        }

        preparationBytes(part, info, rendering = true) {
            const renderSize = sourcePartDurationSeconds(part) * (this.adapter.context?.()?.sampleRate || 48000) * 8;
            // Include encoded originals, source/deck clones, capture/PCM/upload
            // copies and headroom for the isolated renderer, not just decodes.
            return 16 * 1048576 + (Number(info?.fxBytes) || 0) + (Number(part.bytes) || info?.body?.byteLength || 0) * 2
                + (Number(info?.decodedBytes) || 0) * 2 + (rendering ? renderSize * 4 : 0);
        }

        trimRenderMemory(limit) {
            while (this.renders.size && this.renderBytes > limit) {
                const [id, buffer] = this.renders.entries().next().value;
                this.renderBytes -= buffer.length * buffer.numberOfChannels * 4;
                this.renders.delete(id);
            }
        }

        async reservePreparation(bytes, signal) {
            const release = await this.memoryBudget.acquire(bytes, signal);
            // Hot playback buffers must not sit outside the preparation budget.
            this.trimRenderMemory(Math.max(0, this.memoryBudget.limitBytes - this.memoryBudget.bytes));
            return release;
        }

        async loadPart(part, generation = this.generation, inspected = null, options = {}) {
            if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
            const existing = this.cache.get(sourceId(part));
            if (existing && (existing.contentSha256 || existing.sourceSha256) === contentKey(part)) return existing;
            let info = inspected;
            let release;
            try {
                if (!info) {
                    info = this.snapshots.get(sourceId(part));
                    if (!Number.isFinite(info?.decodedBytes)) info = await this.readPartMetadata(part, generation);
                }
                this.armStage(generation, 'Waiting for preparation memory', part);
                const reserved = this.preparationBytes(part, info, options.rendering === true);
                release = await this.reservePreparation(reserved, this.abort?.signal);
                if (!info.body) info = await this.readPart(part, generation);
                if (this.preparationBytes(part, info, options.rendering === true) > reserved) throw new Error('Saved audio exceeds its preparation estimate. Refresh Songs before trying again.');
                if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
                const sourceCache = { buffers: new Map(), bytes: 0, limitBytes: this.memoryBudget.limitBytes };
                this.armStage(generation, 'Decoding saved audio', part);
                await this.paintBeforeArmWork(generation);
                const decoded = await this.adapter.decode(info.body, sourceCache);
                if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
                decoded.sourceSha256 = part.sha256;
                decoded.contentSha256 = contentKey(part);
                decoded.releaseMemory = release;
                this.cache.set(sourceId(part), decoded);
                this.updateSourceMemory();
                return decoded;
            } catch (error) { release?.(); throw error; }
            finally { if (info) info.body = null; info?.releaseDownload?.(); }
        }

        updateSourceMemory() {
            const buffers = new Set([...this.cache.values()].flatMap(decoded => [...(decoded.buffers?.values() || [])]));
            this.audioCache = { buffers: new Map([...buffers].map(buffer => [buffer, buffer])), bytes: [...buffers].reduce((bytes, buffer) => bytes + buffer.length * buffer.numberOfChannels * 4, 0) };
        }

        releasePart(part) {
            const decoded = this.cache.get(sourceId(part));
            this.cache.delete(sourceId(part));
            decoded?.releaseMemory?.();
            this.updateSourceMemory();
        }

        needsCurrentMutilator(decoded) {
            const snapshot=decoded?.snapshot,d=snapshot?.state?.modes?.loopD,m=d?.mutilator;
            const positive=v=>{const n=Number(v===undefined?.5:v);return !Number.isFinite(n)||n>0;};
            return (!m?.input||m.input==='D')&&d?.enabled===true&&m?.enabled===true&&positive(m.mix)&&positive(m.amount)&&(Object.hasOwn(m,'rhythm')||['diode','cinder','shred','vortex','maw'].includes(m.strain))&&snapshot.assets?.some(a=>a.key==='bastardD');
        }

        isRenderCompatible(part, decoded = this.snapshots.get(sourceId(part)) || this.cache.get(sourceId(part))) {
            const modes=decoded?.snapshot?.state?.modes||{},bass=modes.bassFace,m=modes.loopD?.mutilator;
            if(Math.max(Number(part.unifiedInputsVersion)||0,unifiedInputsVersion(decoded))>Number(part.render?.unifiedInputsVersion||0))return false;
            const characterRequired=part.characterFxVersion || (bass?.enabled&&bass.input!=='DAW'&&bass.amount>0&&bass.mix>0) || (m?.enabled&&m.input&&m.input!=='D'&&m.input!=='DAW'&&m.amount>0&&m.mix>0);
            if(characterRequired&&part.render?.characterFxVersion!==1)return false;
            const acousticRequired=part.acousticFxVersion || window.MygrainAcousticFx?.KEYS.some(k => modes[k]?.source!=='DAW' && window.MygrainAcousticFx.audible(k,modes[k]));
            if(acousticRequired && part.render?.acousticFxVersion!==1)return false;
            if(Number(part.render?.cookingPotVersion||0)<cookingPotRenderVersion(decoded,part))return false;
            if(effectOutputRenderVersion(decoded,part) && Number(part.render?.effectOutputVersion||0)<effectOutputRenderVersion(decoded,part))return false;
            if((part.mutilatorControlsVersion || needsMutilatorControlsRender(decoded)) && part.render?.mutilatorControlsVersion!==1)return false;
            if((part.kickRoutingVersion || needsKickRoutingRender(decoded)) && part.render?.kickRoutingVersion!==1)return false;
            const legacyWasp = decoded?.snapshot?.state?.modes?.wasp;
            if ((part.waspSourceVersion || (legacyWasp?.enabled && legacyWasp.routes?.slice(0,2).filter(route => route.enabled).length > 1)) && part.render?.waspSourceVersion !== 1) return false;
            if (Math.max(Number(part.playgroundVersion)||0,playgroundRenderVersion(decoded)) > (Number(part.render?.playgroundVersion)||0)) return false;
            if (part.playgroundVersion && !decoded && Number(part.render?.playgroundVersion||0)<2) return false;
            const dRequired = Math.max(Number(part.loopDVersion||0), decoded?.snapshot?.state?.modes?.loopD?.enabled === true && decoded?.snapshot?.assets?.some(asset => asset.key === 'bastardD') ? (Number(decoded.snapshot.state.modes.loopD.maximiser)>0?2:1) : 0);
            if (Number(part.render?.loopDVersion||0) < dRequired) return false;
            if ((part.mutilatorVersion || this.needsCurrentMutilator(decoded)) && part.render?.mutilatorVersion !== 2) return false;
            if(part.render?.mutilatorVersion===1)return false;
            const fxRequired = part.loopFxVersion === 1 || decoded?.snapshot?.state?.modes?.loopFx?.version === 1;
            if (fxRequired && part.render?.loopFxVersion !== 1) return false;
            const extendedEq = Number(part.eqVersion) >= 3 || Object.entries(decoded?.snapshot?.state?.modes?.channelEq?.channels || {}).some(([key, channel]) => !['X','L'].includes(key) && channel?.manualBypass !== true && channel?.automation?.read === true && channel.automation.points?.some(point => point.enabled));
            if (extendedEq && Number(part.render?.channelEqVersion || 0) < 3) return false;
            const eqRequired = Number(part.eqVersion) >= 1 || Object.values(decoded?.snapshot?.state?.modes?.channelEq?.channels || {}).some(channel => channel?.manualBypass !== true && (channel?.enabled === true || (channel?.automation?.read === true && channel.automation.points?.some(point => point.enabled))));
            if (eqRequired && !(Number(part.render?.channelEqVersion) >= 2)) return false;
            const pianoVersion = Number(part.qVersion) >= 2 ? Math.max(3, Number(part.qVersion)) : Number(part.qVersion) || 0;
            if (!decoded) return (!pianoVersion || Number(part.render?.qVersion) >= pianoVersion) && ((this.renderSources.has(sourceId(part)) && this.renderSources.get(sourceId(part)) === contentKey(part))
                || (part.render?.keyboardVersion === 1 && Number(part.render?.grainVersion) >= 5 && part.render?.portableVersion === 1 && part.render?.kReverbVersion === 1));
            const keyboard = Boolean(decoded?.snapshot?.extra?.heldNotes?.length);
            const grains = decoded?.snapshot?.state?.modes?.granularLayersEnabled === true;
            const vocalCut = decoded?.snapshot?.state?.modes?.bastardLoopVCut?.enabled === true;
            const vocalRepeat = vocalCut && decoded.snapshot.state.modes.bastardLoopVCut.repeat === true;
            const drumLanes = Object.values(decoded?.snapshot?.state?.modes?.drumMachineExtraTracks || {}).some(track => track?.pattern?.some(Boolean));
            return (!needsDrumAccentRender(decoded) || part.render?.drumAccentVersion === 1) && (!keyboard || part.render?.keyboardVersion === 1) && (!grains || Number(part.render?.grainVersion) >= 5) && (!vocalCut || part.render?.vocalCutVersion === 1) && (!vocalRepeat || part.render?.vocalRepeatVersion === 1) && (!drumLanes || part.render?.drumLanesVersion === 1) && (!needsDrumRollRender(decoded) || part.render?.drumRollVersion === 1) && (!needsDrumSampleRender(decoded) || part.render?.drumSampleVersion === 1) && (!needsPortableFreeze(decoded) || part.render?.portableVersion === 1) && (!qRenderVersion(decoded) || Number(part.render?.qVersion) >= qRenderVersion(decoded)) && (!needsKReverbRender(decoded) || part.render?.kReverbVersion === 1);
        }

        isPartReady(part) {
            return this.renderSources.get(sourceId(part)) === contentKey(part) && this.isRenderCompatible(part);
        }

        hasSavedRender(part) {
            const known = this.snapshots.has(sourceId(part)) || this.cache.has(sourceId(part)) || this.renderSources.has(sourceId(part));
            return part.render?.version === 1 && part.render.sourceSha256 === part.sha256 && (Number(part.render.unifiedInputsVersion||0)>=Number(part.unifiedInputsVersion||0)) && (!part.waspSourceVersion || part.render.waspSourceVersion === 1) && (!part.playgroundVersion || Number(part.render.playgroundVersion)>=Number(part.playgroundVersion)) && (Number(part.render.loopDVersion||0)>=Number(part.loopDVersion||0)) && (!(Number(part.eqVersion) >= 3) || Number(part.render.channelEqVersion) >= 3) && (!part.acousticFxVersion || part.render.acousticFxVersion === 1) && (Number(part.render.cookingPotVersion||0)>=Number(part.cookingPotVersion||0)) && (!part.effectOutputVersion || Number(part.render.effectOutputVersion)>=Number(part.effectOutputVersion)) && (!part.kickRoutingVersion || part.render.kickRoutingVersion === 1) && (!part.characterFxVersion || part.render.characterFxVersion === 1) && (!part.mutilatorControlsVersion || part.render.mutilatorControlsVersion === 1) && (!part.mutilatorVersion || part.render.mutilatorVersion === 2) && part.render.mutilatorVersion !== 1 && (!(part.loopDVersion || part.playgroundVersion) || this.isRenderCompatible(part)) && (!known || this.isRenderCompatible(part));
        }

        async prepareRender(part, decoded, generation) {
            if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
            const portable = needsPortableFreeze(decoded);
            const piano = qRenderVersion(decoded);
            const drumSamples = needsDrumSampleRender(decoded);
            const drumRoll = needsDrumRollRender(decoded);
            const keyboard = Boolean(decoded?.snapshot?.extra?.heldNotes?.length);
            const grains = decoded?.snapshot?.state?.modes?.granularLayersEnabled === true;
            const vocalCut = decoded?.snapshot?.state?.modes?.bastardLoopVCut?.enabled === true;
            const vocalRepeat = vocalCut && decoded.snapshot.state.modes.bastardLoopVCut.repeat === true;
            const drumLanes = Object.values(decoded?.snapshot?.state?.modes?.drumMachineExtraTracks || {}).some(track => track?.pattern?.some(Boolean));
            const compatible = this.isRenderCompatible(part, decoded);
            if (this.renderSources.get(sourceId(part)) === contentKey(part) && compatible) return;
            if (this.renders.has(sourceId(part))) {
                const previous = this.renders.get(sourceId(part));
                this.renderBytes -= previous.length * previous.numberOfChannels * 4;
                this.renders.delete(sourceId(part));
                this.renderSources.delete(sourceId(part));
            }
            let buffer;
            let bytes;
            let rendered = false;
            if (part.render?.version === 1 && part.render.sourceSha256 === part.sha256 && (Number(part.render.unifiedInputsVersion||0)>=Number(part.unifiedInputsVersion||0)) && compatible) {
                bytes = await this.readRender(part, this.abort?.signal, generation);
                this.armStage(generation, 'Decoding playback render', part);
                await this.paintBeforeArmWork(generation);
                buffer = await this.adapter.decodeRender(bytes.slice(0));
            } else {
                rendered = true;
                this.status(`Rendering ${part.name} for exact beat playback (${sourcePartDurationSeconds(part).toFixed(1)}s). Keep this page open…`);
                this.armStage(generation, 'Rendering exact beat playback', part);
                await this.paintBeforeArmWork(generation);
                buffer = await this.adapter.renderPart(decoded, part, this.abort?.signal);
                if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
                this.armStage(generation, 'Encoding playback render', part);
                await this.paintBeforeArmWork(generation);
                const body = this.adapter.encodeRender(buffer);
                bytes = body;
                this.armStage(generation, 'Saving playback render to server', part);
                const result = await this.request(`/${encodeURIComponent(this.song.id)}/parts/${part.id}/render?sha256=${part.sha256}&kreverb=1&channeleq=${Number(part.eqVersion) >= 3 || Object.entries(decoded?.snapshot?.state?.modes?.channelEq?.channels || {}).some(([key, channel]) => !['X','L'].includes(key) && channel?.manualBypass !== true && channel?.automation?.read === true && channel.automation.points?.some(point => point.enabled)) ? 3 : 2}&loopfx=1&loopd=2&characterfx=1&acousticfx=1&effectoutput=${effectOutputRenderVersion(decoded,part)||1}&cookingpot=3&unifiedinputs=3&kickrouting=1&mutilator=2&mutilatorcontrols=1&playground=3&waspsource=1&drumaccent=1${keyboard ? '&keyboard=1' : ''}${grains ? '&grain=5' : ''}${vocalCut ? '&vocalcut=1' : ''}${vocalRepeat ? '&vocalrepeat=1' : ''}${drumLanes ? '&drumlanes=1' : ''}${drumSamples ? '&drumsample=1' : ''}${drumRoll ? '&drumroll=1' : ''}${portable ? '&portable=1' : ''}${piano ? `&q=${piano}` : ''}`, {
                    method: 'POST', headers: { 'Content-Type': 'audio/wav' }, body, signal: this.abort?.signal
                });
                if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
                const saved = result.song.parts.find(entry => entry.id === part.id && entry.sha256 === part.sha256);
                if (!saved?.render) throw new Error(`The song changed while rendering ${part.name}. Refresh Songs and arm again.`);
                if ((part.mutilatorControlsVersion || needsMutilatorControlsRender(decoded)) && saved.render.mutilatorControlsVersion !== 1) throw new Error('The song server needs expanded Mutilator support. Reload MYGRAIN and arm again.');
                if ((part.mutilatorVersion || this.needsCurrentMutilator(decoded)) && saved.render.mutilatorVersion !== 2) throw new Error('The song server needs switchable Mutilator support. Reload MYGRAIN and arm again.');
                if (Math.max(Number(part.playgroundVersion)||0,playgroundRenderVersion(decoded)) > Number(saved.render.playgroundVersion||0)) throw new Error('The song server needs current Playground input/clock support. Reload MYGRAIN and arm again.');
                if ((part.loopFxVersion === 1 || decoded?.snapshot?.state?.modes?.loopFx?.version === 1) && saved.render.loopFxVersion !== 1) throw new Error('The song server needs standard loop FX support. Reload MYGRAIN and arm again.');
                if (Object.values(decoded?.snapshot?.state?.modes?.channelEq?.channels || {}).some(channel => channel?.manualBypass !== true && (channel?.enabled === true || (channel?.automation?.read === true && channel.automation.points?.some(point => point.enabled)))) && !(Number(saved.render.channelEqVersion) >= 2)) throw new Error('The song server needs channel EQ render support. Reload MYGRAIN and arm again.');
                if (Number(saved.render.loopDVersion||0)<Math.max(Number(part.loopDVersion||0),decoded?.snapshot?.state?.modes?.loopD?.enabled === true && decoded?.snapshot?.assets?.some(asset => asset.key === 'bastardD')?(Number(decoded.snapshot.state.modes.loopD.maximiser)>0?2:1):0)) throw new Error('The song server needs D loop render support. Reload MYGRAIN and arm again.');
                if (needsKReverbRender(decoded) && saved.render.kReverbVersion !== 1) throw new Error('The song server needs K Hall reverb render support. Reload MYGRAIN and arm again.');
                if (keyboard && saved.render.keyboardVersion !== 1) throw new Error('The song server needs keyboard-render support. Reload MYGRAIN and arm again.');
                if (grains && !(Number(saved.render.grainVersion) >= 5)) throw new Error('The song server needs current smooth-grain render support. Reload MYGRAIN and arm again.');
                if (vocalCut && saved.render.vocalCutVersion !== 1) throw new Error('The song server needs vocal-cut render support. Reload MYGRAIN and arm again.');
                if (vocalRepeat && saved.render.vocalRepeatVersion !== 1) throw new Error('The song server needs vocal section-repeat render support. Reload MYGRAIN and arm again.');
                if (drumLanes && saved.render.drumLanesVersion !== 1) throw new Error('The song server needs Clap/Cymbals render support. Reload MYGRAIN and arm again.');
                if (drumRoll && saved.render.drumRollVersion !== 1) throw new Error('The song server needs snare Roll render support. Reload MYGRAIN and arm again.');
                if(Math.max(Number(part.unifiedInputsVersion)||0,unifiedInputsVersion(decoded))>Number(saved.render.unifiedInputsVersion||0))throw new Error('The song server needs current effects input routing. Reload MYGRAIN and arm again.');
                if (Number(saved.render.cookingPotVersion||0)<cookingPotRenderVersion(decoded,part)) throw new Error('The song server needs cooking pot support. Reload MYGRAIN and arm again.');
                if (effectOutputRenderVersion(decoded,part) && Number(saved.render.effectOutputVersion||0)<effectOutputRenderVersion(decoded,part)) throw new Error('The song server needs independent effect-output support. Reload MYGRAIN and arm again.');
                if ((part.kickRoutingVersion || needsKickRoutingRender(decoded)) && saved.render.kickRoutingVersion !== 1) throw new Error('The song server needs corrected kick routing support. Reload MYGRAIN and arm again.');
                if (saved.render.drumAccentVersion !== 1) throw new Error('The song server needs drum accent render support. Reload MYGRAIN and arm again.');
                if (drumSamples && saved.render.drumSampleVersion !== 1) throw new Error('The song server needs full-decay drum sample render support. Reload MYGRAIN and arm again.');
                if (portable && saved.render.portableVersion !== 1) throw new Error('The song server needs portable-freeze support. Reload MYGRAIN and arm again.');
                if (piano && !(Number(saved.render.qVersion) >= piano)) throw new Error(`The song server needs Q ${piano >= 9 ? 'OSC / grain / sample' : piano >= 8 ? 'chord hold' : piano >= 7 ? 'sample length / decay' : piano >= 6 ? 'accent / custom arpeggiator' : piano >= 5 ? 'strings' : piano >= 4 ? 'piano effects' : piano >= 2 ? 'piano arpeggiator' : 'piano'} render support. Reload MYGRAIN and arm again.`);
                this.song = { ...this.song, parts: this.song.parts.map(entry => sourceId(entry) === sourceId(part) ? { ...entry, render: saved.render } : entry) };
                this.songs = this.songs.map(song => song.id === this.song.id ? this.song : song);
                this.armStage(generation, 'Decoding saved playback render', part);
                await this.paintBeforeArmWork(generation);
                // Release the full Float32 capture before allocating its decoded
                // PCM16 replacement. The server/cache WAV remains authoritative.
                buffer = null;
                buffer = await this.adapter.decodeRender(body.slice(0));
            }
            if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
            const saved = this.song.parts.find(entry => entry.id === part.id);
            if (rendered) {
                this.armStage(generation, 'Saving playback render in browser storage', part);
                await this.renderStore.put(this.renderKey(saved), bytes);
            }
            if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
            this.retainRender(part, buffer);
            this.renderSources.set(sourceId(part), contentKey(part));
        }

        renderKey(part) {
            return `${this.key}:${this.song.id}:${sourceId(part)}:${contentKey(part)}:${part.render.sha256}`;
        }

        async readRender(part, signal, generation = this.generation) {
            const key = this.renderKey(part);
            this.armStage(generation, 'Reading browser render cache', part);
            let bytes = await this.renderStore.get(key);
            const digest = async body => Array.from(new Uint8Array(await this.crypto.subtle.digest('SHA-256', body)), value => value.toString(16).padStart(2, '0')).join('');
            if (bytes && await digest(bytes) !== part.render.sha256) { await this.renderStore.delete(key); bytes = null; }
            if (!bytes) {
                if (signal?.aborted) throw new DOMException('Cancelled', 'AbortError');
                this.armStage(generation, 'Downloading playback render', part);
                bytes = await this.request(`/${encodeURIComponent(this.song.id)}/parts/${part.id}/render`, { binary: true, signal });
                this.armStage(generation, 'Checking playback render integrity', part);
                if (await digest(bytes) !== part.render.sha256) throw new Error(`Song render integrity check failed for ${part.name}.`);
                if (signal?.aborted) throw new DOMException('Cancelled', 'AbortError');
                this.armStage(generation, 'Saving playback render in browser storage', part);
                await this.renderStore.put(key, bytes);
            }
            if (signal?.aborted) throw new DOMException('Cancelled', 'AbortError');
            return bytes;
        }

        retainRender(part, buffer) {
            const expected = sourcePartDurationSeconds(part);
            if (Math.abs(buffer.duration - expected) > 2 / buffer.sampleRate) throw new Error(`Prepared audio has the wrong pattern length for ${part.name}.`);
            const size = buffer.length * buffer.numberOfChannels * 4;
            if (this.renders.has(sourceId(part))) {
                const previous = this.renders.get(sourceId(part));
                this.renderBytes -= previous.length * previous.numberOfChannels * 4;
                this.renders.delete(sourceId(part));
            }
            const limit = Math.min(this.renderLimitBytes, Math.max(0, this.memoryBudget.limitBytes - this.memoryBudget.bytes));
            this.trimRenderMemory(Math.max(0, limit - size));
            // An oversized individual render stays on disk/server, not in the
            // hot cache. Never exceed the cache bound to keep just one buffer.
            if (size > limit) return;
            this.renderBytes += size;
            this.renders.set(sourceId(part), buffer);
        }

        async loadRender(part, signal, generation = this.generation) {
            if (signal?.aborted || generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
            if (!this.isPartReady(part)) throw new Error(`Arm Cache again: ${part.name} has changed audio.`);
            const id = sourceId(part);
            if (this.renders.has(id)) return this.renders.get(id);
            if (this.renderLoads.has(id)) return this.renderLoads.get(id);
            const load = (async () => {
                const bytes = await this.readRender(part, signal);
                const buffer = await this.adapter.decodeRender(bytes);
                if (signal?.aborted || generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
                this.retainRender(part, buffer);
                return buffer;
            })();
            this.renderLoads.set(id, load);
            try { return await load; }
            finally { if (this.renderLoads.get(id) === load) this.renderLoads.delete(id); }
        }

        assertUpgradeCurrent(generation, expected, committed = false) {
            const sameSong = this.key === expected.library && this.song?.id === expected.songId;
            const sources = sameSong ? this.song.parts.filter(entry => sourceId(entry) === expected.sourceId) : [];
            if (generation !== this.generation || !sameSong || this.song.revision !== expected.revision
                || !sources.some(entry => entry.id === expected.partId) || sources.some(entry => entry.sha256 !== expected.sha256)) {
                if (committed && sameSong) this.revisionConflict = true;
                throw new DOMException('Song upgrade response is stale. Refresh Songs to reconcile any committed save.', 'AbortError');
            }
        }

        async upgradeSongParts(generation, options = {}) {
            let pending = 0;
            let writable = !this.editing;
            for (const part of this.uniqueParts()) {
                if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
                const known = this.snapshots.get(sourceId(part));
                if (known && (!known.upgradePending || options.automatic)) {
                    if (options.automatic && known.upgradePending) pending += 1;
                    continue;
                }
                let info;
                let releaseRender;
                try {
                    this.armStage(generation, 'Checking saved-part compatibility', part);
                    info = await this.readPartMetadata(part, generation);
                    if (!info.upgrade) continue;
                    // Inspection normalizes all legacy empty lanes and K metadata
                    // in memory. Arm must never rewrite editable source ZIPs:
                    // that work precedes rendering and can exceed phone RAM.
                    if (options.automatic) { pending += 1; continue; }
                    if (info.upgrade.lanes.includes('W loop')) {
                        throw new Error('Device-side W conversion is disabled. Use Convert W to run it on the server.');
                    }
                    if (info.upgrade.lanes.includes('K five-track recorder')) {
                        throw new Error('Device-side K conversion is disabled. Use Convert K to run it on the server.');
                    }
                    if (writable) {
                        this.armStage(generation, 'Checking editing access for upgrade', part);
                        try { await this.ensureEditing(part); }
                        catch (error) {
                            if (!['SONG_LOCKED', 'SONG_LOCK_REQUIRED', 'SONG_LOCK_LOST', 'SONG_EDIT_UNVERIFIED'].includes(error.code)) throw error;
                            writable = false;
                        }
                    }
                    if (!writable) { pending += 1; continue; }
                    if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
                    // Compatibility upgrades also build/hash/upload a ZIP. Admit
                    // their full encoded working set before loading originals;
                    // one reservation includes any retained old playback WAV.
                    const archiveSize = Number(part.bytes) || info.body?.byteLength || 0;
                    releaseRender = await this.reservePreparation(16 * 1048576 + archiveSize * 3 + (Number(part.render?.bytes) || 0) * 3, this.abort?.signal);
                    // Only genuine legacy upgrades need original WAV bytes.
                    // Normal/current snapshots and reusable renders use JSON.
                    if (!info.body) {
                        info = await this.readPart(part, generation);
                        if (!info.upgrade) continue;
                    }
                    const songId = this.song.id;
                    const library = this.key;
                    const expected = { songId, library, revision: this.song.revision, sourceRevision: part.revision || 1, sourceId: sourceId(part), partId: part.id, sha256: part.sha256 };
                    this.armStage(generation, 'Upgrading saved-part snapshot', part);
                    await this.paintBeforeArmWork(generation);
                    const body = await this.adapter.upgradePart(info);
                    if (body.size > 128 * 1024 * 1024) throw new Error('The upgraded part exceeds the 128 MB upload limit. No saved part was changed.');
                    const digest = Array.from(new Uint8Array(await this.crypto.subtle.digest('SHA-256', await body.arrayBuffer())), value => value.toString(16).padStart(2, '0')).join('');
                    let renderBytes;
                    if (part.render?.version === 1 && part.render.sourceSha256 === part.sha256 && (Number(part.render.unifiedInputsVersion||0)>=Number(part.unifiedInputsVersion||0)) && this.isRenderCompatible(part, info)) {
                        renderBytes = await this.readRender(part, this.abort?.signal, generation);
                    }
                    this.assertUpgradeCurrent(generation, expected);
                    if (!this.canEditSong()) { writable = false; pending += 1; continue; }
                    this.status(`Upgrading ${part.name}: ${info.upgrade.lanes.join(', ')} compatibility metadata; recorded audio is unchanged…`);
                    let result;
                    try {
                        this.armStage(generation, 'Saving upgraded part to server', part);
                        result = await this.request(`/${encodeURIComponent(songId)}/parts/${part.id}/save?sha256=${part.sha256}`, {
                            method: 'POST', headers: { 'Content-Type': 'application/zip' }, body
                        });
                    } catch (error) {
                        if (!['SONG_LOCKED', 'SONG_LOCK_REQUIRED', 'SONG_LOCK_LOST', 'SONG_EDIT_UNVERIFIED'].includes(error.code)) throw error;
                        writable = false;
                        pending += 1;
                        continue;
                    }
                    this.assertUpgradeCurrent(generation, expected, true);
                    const saved = result.song?.parts?.find(entry => entry.id === part.id && sourceId(entry) === expected.sourceId && entry.sha256 === digest);
                    if (result.song?.id !== songId || result.song.revision !== expected.revision + 1 || !saved || saved.revision !== expected.sourceRevision + 1
                        || result.song.parts.some(entry => sourceId(entry) === expected.sourceId && entry.sha256 !== digest)) {
                        this.revisionConflict = true;
                        throw new Error('Unexpected saved-song upgrade revision or audio hash. Refresh Songs to reconcile the committed save.');
                    }
                    this.song = result.song;
                    this.songs = this.songs.map(song => song.id === songId ? this.song : song);
                    this.invalidate(true);
                    this.snapshots.set(sourceId(saved), { snapshot: info.snapshot, decodedBytes: info.decodedBytes, fxBytes: info.fxBytes, contentSha256: contentKey(saved), upgradePending: false });
                    if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
                    if (renderBytes && !this.hasSavedRender(saved)) {
                        const renderExpected = { ...expected, revision: this.song.revision, sha256: digest };
                        const flags = [['unifiedinputs','unifiedInputsVersion'], ['cookingpot','cookingPotVersion'], ['mutilatorcontrols','mutilatorControlsVersion'], ['effectoutput','effectOutputVersion'], ['kickrouting','kickRoutingVersion'], ['acousticfx','acousticFxVersion'], ['characterfx','characterFxVersion'], ['waspsource', 'waspSourceVersion'], ['mutilator', 'mutilatorVersion'], ['loopd', 'loopDVersion'], ['keyboard', 'keyboardVersion'], ['grain', 'grainVersion'], ['vocalcut', 'vocalCutVersion'],
                            ['vocalrepeat', 'vocalRepeatVersion'], ['drumlanes', 'drumLanesVersion'], ['drumsample', 'drumSampleVersion'], ['drumaccent', 'drumAccentVersion'], ['drumroll', 'drumRollVersion'], ['portable', 'portableVersion'], ['q', 'qVersion'], ['kreverb', 'kReverbVersion'], ['playground', 'playgroundVersion']]
                            .filter(([, field]) => part.render[field]).map(([flag, field]) => `&${flag}=${part.render[field]}`).join('');
                        this.armStage(generation, 'Saving retained playback render', part);
                        result = await this.request(`/${encodeURIComponent(songId)}/parts/${saved.id}/render?sha256=${saved.sha256}${flags}`, {
                            method: 'POST', headers: { 'Content-Type': 'audio/wav' }, body: renderBytes, signal: this.abort?.signal
                        });
                        this.assertUpgradeCurrent(generation, renderExpected, true);
                        const rendered = result.song?.parts?.find(entry => entry.id === saved.id && entry.sha256 === saved.sha256);
                        if (result.song?.id !== songId || result.song.revision !== renderExpected.revision || sourceId(rendered || {}) !== expected.sourceId || rendered?.revision !== saved.revision
                            || rendered?.render?.sourceSha256 !== digest || rendered?.render?.sha256 !== part.render.sha256) {
                            this.revisionConflict = true;
                            throw new Error('The song changed while retaining its render. Refresh Songs and arm again.');
                        }
                        this.song = { ...this.song, parts: this.song.parts.map(entry => sourceId(entry) === sourceId(saved) ? { ...entry, render: rendered.render } : entry) };
                        this.songs = this.songs.map(song => song.id === songId ? this.song : song);
                    }
                } finally {
                    if (info) info.body = null;
                    info?.releaseDownload?.();
                    releaseRender?.();
                    if (this.armFeedback?.generation === generation && this.armFeedback.state === 'running') this.armFeedback.current.delete(sourceId(part));
                }
            }
            return pending;
        }

        async convertKTracks() {
            if (!this.song?.parts.length) throw new Error('Choose a saved Song with parts first.');
            if (this.playing || this.editing) throw new Error('Stop Song playback and finish the current amendment before converting K.');
            this.adapter.assertNotRecording?.();
            await this.ensureEditing();
            const generation = this.generation, songId = this.song.id, library = this.key, revision = this.song.revision;
            const sources = JSON.stringify(this.song.parts.map(part => [part.id, part.sha256]));
            this.status('Converting K to five tracks on the server. Recorded audio stays on the server…');
            const result = await this.request(`/${encodeURIComponent(songId)}/convert-k`, { method: 'POST' });
            if (generation !== this.generation || library !== this.key || this.song?.id !== songId || this.song.revision !== revision
                || JSON.stringify(this.song.parts.map(part => [part.id, part.sha256])) !== sources) {
                if (this.song?.id === songId && library === this.key) this.revisionConflict = true;
                throw new DOMException('K conversion completed or was interrupted on the server. Refresh Songs to reconcile the saved result.', 'AbortError');
            }
            if (result.song?.id !== songId || !Number.isInteger(result.converted) || result.converted < 0 || result.converted > 64
                || result.song.revision !== revision + (result.converted ? 1 : 0)) {
                this.revisionConflict = true;
                throw new Error('Unexpected server K conversion response. Refresh Songs before saving.');
            }
            this.acceptSong(result.song);
            this.invalidate(true);
            this.status(`Server K conversion complete: ${result.converted} unique parts converted; single-track takes map to K1 and existing multitrack takes keep all five tracks. All recorded audio and existing playback files are unchanged. Arm Cache remains manual.`);
        }

        async convertWLoop() {
            if (!this.song?.parts.length) throw new Error('Choose a saved Song with parts first.');
            if (this.playing || this.editing) throw new Error('Stop Song playback and finish the current amendment before converting W.');
            this.adapter.assertNotRecording?.();
            await this.ensureEditing();
            const generation = this.generation, songId = this.song.id, library = this.key, revision = this.song.revision;
            const sources = JSON.stringify(this.song.parts.map(part => [part.id, part.sha256]));
            this.status('Adding W compatibility on the server. Recorded audio stays on the server…');
            const result = await this.request(`/${encodeURIComponent(songId)}/convert-w`, { method: 'POST' });
            if (generation !== this.generation || library !== this.key || this.song?.id !== songId || this.song.revision !== revision
                || JSON.stringify(this.song.parts.map(part => [part.id, part.sha256])) !== sources) {
                if (this.song?.id === songId && library === this.key) this.revisionConflict = true;
                throw new DOMException('W conversion completed or was interrupted on the server. Refresh Songs to reconcile the saved result.', 'AbortError');
            }
            if (result.song?.id !== songId || !Number.isInteger(result.converted) || result.converted < 0 || result.converted > 64
                || result.song.revision !== revision + (result.converted ? 1 : 0)) {
                this.revisionConflict = true;
                throw new Error('Unexpected server W conversion response. Refresh Songs before saving.');
            }
            this.acceptSong(result.song);
            this.invalidate(true);
            this.status(`Server W conversion complete: ${result.converted} unique parts converted; older parts get W empty and off; existing W audio and settings stay unchanged. All recorded audio and existing playback files are unchanged. Arm Cache remains manual.`);
        }

        async convertLoopFx() {
            if (!this.song?.parts.length) throw new Error('Choose a saved Song with parts first.');
            if (this.playing || this.editing) throw new Error('Stop Song playback and finish the current amendment before converting loop effects.');
            this.adapter.assertNotRecording?.();
            await this.ensureEditing();
            const generation = this.generation, songId = this.song.id, library = this.key, revision = this.song.revision;
            const sources = JSON.stringify(this.song.parts.map(part => [part.id, part.sha256]));
            this.status('Converting loop filters, stereo halls and delays on the server. Recorded audio stays on the server…');
            const result = await this.request(`/${encodeURIComponent(songId)}/convert-fx`, { method: 'POST' });
            if (generation !== this.generation || library !== this.key || this.song?.id !== songId || this.song.revision !== revision
                || JSON.stringify(this.song.parts.map(part => [part.id, part.sha256])) !== sources) {
                if (this.song?.id === songId && library === this.key) this.revisionConflict = true;
                throw new DOMException('FX conversion completed or was interrupted on the server. Refresh Songs to reconcile the saved result.', 'AbortError');
            }
            if (result.song?.id !== songId || !Number.isInteger(result.converted) || result.converted < 0 || result.converted > 64
                || result.song.revision !== revision + (result.converted ? 1 : 0)) {
                this.revisionConflict = true;
                throw new Error('Unexpected server FX conversion response. Refresh Songs before saving.');
            }
            this.acceptSong(result.song);
            this.invalidate(true);
            this.status(`Server FX conversion complete: ${result.converted} unique parts converted. Recorded samples and original archives are unchanged. Arm Cache to rebuild playback using the standard loop effects.`);
        }

        async arm() {
            if (!this.song?.parts.length) throw new Error('Save at least one part first.');
            this.cancel(true);
            this.invalidate(true);
            for (const id of [...this.cache.keys()]) this.releasePart({ id });
            const generation = this.generation;
            const abort = this.abort = new AbortController();
            let uniqueParts = this.uniqueParts();
            this.render();
            this.status('Arming cache: waiting for audio to be ready…');
            this.startArmFeedback(generation, uniqueParts);
            let next = 0;
            let completed = 0;
            let workers = [];
            try {
                if (root.requestAnimationFrame) await this.paintBeforeArmWork(generation);
                if (generation !== this.generation) return;
                await this.adapter.ready();
                if (generation !== this.generation) return;
                this.song.parts.forEach(partDurationSeconds);
                this.armStage(generation, 'Checking saved-part compatibility');
                const pendingUpgrades = this.adapter.upgradePart ? await this.upgradeSongParts(generation, { automatic: true }) : 0;
                if (generation !== this.generation) return;
                uniqueParts = this.uniqueParts();
                const parts = uniqueParts.filter(part => !this.isPartReady(part));
                const reused = uniqueParts.length - parts.length;
                this.armFeedback.completed = reused;
                this.armFeedback.reused = reused;
                this.armStage(generation, 'Preparing playback cache');
                const preparationConcurrency = this.preparationConcurrency();
                workers = Array.from({ length: Math.min(preparationConcurrency, parts.length) }, async () => {
                    while (next < parts.length) {
                        if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
                        const part = parts[next++];
                        this.armStage(generation, 'Preparing part', part);
                        this.status(`Arming ${completed}/${parts.length} pending (${preparationConcurrency === 1 ? 'one part at a time' : `up to ${preparationConcurrency} memory-aware workers`}; ${reused} reused): ${part.name}…`);
                        let decoded;
                        let info;
                        let releaseRender;
                        try {
                            info = this.snapshots.get(sourceId(part));
                            // Older render metadata cannot tell whether full-decay
                            // sampled drums are present. Inspect the editable source
                            // before trusting a legacy freeze's fast reuse path.
                            if (!info && ((part.cookingPotVersion && Number(part.render?.cookingPotVersion||0)<3) || !this.isRenderCompatible(part) || Number(part.render?.effectOutputVersion||0) < 2 || part.render?.kickRoutingVersion !== 1 || Number(part.render?.loopDVersion||0) < 1 || part.render?.drumAccentVersion !== 1 || part.render?.drumSampleVersion !== 1 || part.render?.drumRollVersion !== 1 || part.render?.kReverbVersion !== 1 || Number(part.render?.playgroundVersion||0) < 3 || part.render?.waspSourceVersion !== 1 || (Number(part.qVersion) > 0 && Number(part.render?.qVersion) < 6))) info = await this.readPartMetadata(part, generation);
                            if (this.hasSavedRender(part)) {
                                const renderSize = sourcePartDurationSeconds(part) * (this.adapter.context?.()?.sampleRate || 48000) * 8;
                                this.armStage(generation, 'Waiting for playback memory', part);
                                releaseRender = await this.reservePreparation(renderSize * 4, abort.signal);
                                await this.prepareRender(part, info || {}, generation);
                            } else if (this.serverPreparation && (this.phonePreparation || this.preparationBytes(part, info, true) > this.memoryBudget.limitBytes)) {
                                // Phones offload every new/stale render, not just those
                                // whose estimate already exceeds the safety budget.
                                // The server uses the current app engine; fetch only PCM.
                                const saved = await this.prepareOnServer(part, generation);
                                const renderSize = sourcePartDurationSeconds(part) * (this.adapter.context?.()?.sampleRate || 48000) * 8;
                                releaseRender = await this.reservePreparation(renderSize * 4, abort.signal);
                                await this.prepareRender(saved, info || {}, generation);
                            } else {
                                decoded = await this.loadPart(part, generation, info?.body ? info : null, { rendering: true });
                                await this.prepareRender(part, decoded, generation);
                            }
                        } finally {
                            decoded = null;
                            if (info) info.body = null;
                            info?.releaseDownload?.();
                            releaseRender?.();
                            this.releasePart(part);
                        }
                        if (generation !== this.generation) throw new DOMException('Cancelled', 'AbortError');
                        completed += 1;
                        this.armFeedback.completed = reused + completed;
                        this.armFeedback.current.delete(sourceId(part));
                        this.armStage(generation, 'Preparing playback cache');
                        this.renderCacheSummary();
                        this.status(`Arming ${completed}/${parts.length} pending complete; ${reused} unchanged parts reused. Keep this page open.`);
                    }
                });
                await Promise.all(workers);
                if (generation !== this.generation) return;
                if (this.song.parts.some(part => !this.isPartReady(part))) {
                    throw new Error('The song changed while arming. Refresh Songs and arm its current parts again.');
                }
                this.armed = true;
                this.finishArmFeedback(generation, 'success', 'Song cache armed');
                this.status(`Armed ${this.song.parts.length} parts (${Math.round(this.renderBytes / 1048576)} MB playback memory): ${parts.length} prepared, ${reused} unchanged reused. Original samples stay on the server; renders use browser storage and bounded playback memory. ${this.renderStore.warning}${pendingUpgrades ? ` ${pendingUpgrades} legacy parts use compatible in-memory defaults; saved source archives are unchanged. Convert K runs separately on the server.` : ''}`);
            } catch (error) {
                const failed = generation === this.generation;
                if (failed) {
                    this.finishArmFeedback(generation, error.name === 'AbortError' ? 'cancelled' : 'failure', error.name === 'AbortError' ? 'Arming cancelled' : `Arming failed: ${error.message}`);
                    this.cancel();
                }
                await Promise.allSettled(workers);
                if (failed) {
                    for (const part of uniqueParts) {
                        if (!this.isPartReady(part)) this.cache.delete(sourceId(part));
                    }
                    this.invalidate(true);
                }
                if (!failed || this.generation !== generation + 1) throw new DOMException('Cancelled', 'AbortError');
                throw error;
            } finally {
                if (this.abort === abort) this.abort = null;
            }
        }

        async recallEditable(part, generation, options) {
            const check = () => {
                if (generation !== this.generation || this.abort?.signal.aborted) throw new DOMException('Cancelled', 'AbortError');
                if (options.amend) this.requireEditing();
                this.adapter.assertNotRecording?.();
            };
            let release, decoded, previous, plan, checkpoint, parked, finishPreparation, inheritedEditorBytes = 0;
            let detached = false, committed = false, keepCheckpoint = false;
            const account = root.mygrainAccountContext?.user?.username;
            try {
                check();
                // Do not retain queued IndexedDB copies, another decoded Song
                // deck, or hot playback renders alongside an editing restore.
                await this.adapter.whenPersisted?.();
                check();
                finishPreparation = this.adapter.beginEditingPreparation?.();
                for (const id of [...this.cache.keys()]) this.releasePart({ id });
                this.trimRenderMemory(0);
                let info = this.snapshots.get(sourceId(part));
                if (!Array.isArray(info?.audioAssets)) info = await this.readPartMetadata(part, generation);
                check();
                const resident = this.adapter.editingResidency();
                // A large *current* sample may need no hashing at all. If a full
                // WAV/hash scratch copy cannot fit, skip reuse and checkpoint in
                // bounded Float32 chunks instead of rejecting before planning.
                const skipReuse = 16 * 1048576 + resident.bytes + resident.scratch > this.memoryBudget.limitBytes
                    && Number.isFinite(resident.checkpointScratch);
                // An editor loaded before this operation can already exceed the
                // preparation limit. Do not allocate another deck alongside it.
                // Charge bounded checkpoint work separately, preserve the old
                // residency as rollback-only credit, then detach before decode.
                if (skipReuse) inheritedEditorBytes = resident.bytes;
                release = await this.reservePreparation(skipReuse
                    ? 4 * 1048576 + resident.checkpointScratch
                    : 16 * 1048576 + resident.bytes + resident.scratch, this.abort?.signal);
                plan = await this.adapter.planEditing(info, check, { skipReuse });
                check();
                release(); release = null;
                if (plan.bytes > this.memoryBudget.limitBytes && this.adapter.detachEditingSources && root.MygrainSongStorage.EditCheckpoint) {
                    // If the new deck alone cannot fit, fail before creating a
                    // checkpoint or changing a single live sound.
                    if (plan.emptyBytes > this.memoryBudget.limitBytes) await this.reservePreparation(plan.emptyBytes, this.abort?.signal);
                    this.status('Temporarily saving the current live sounds before loading this large part…');
                    release = await this.reservePreparation(inheritedEditorBytes
                        ? 4 * 1048576 + resident.checkpointScratch
                        : 16 * 1048576 + resident.bytes + (resident.checkpointScratch ?? resident.scratch), this.abort?.signal);
                    previous = await this.adapter.capture({ liveOnly: true });
                    plan.verify(); check();
                    checkpoint = new root.MygrainSongStorage.EditCheckpoint();
                    parked = await checkpoint.save(previous, () => { plan.verify(); check(); });
                    // Rollback also has to fit, including its sequential IDB
                    // read/PCM copies. Keep the old deck untouched if it cannot.
                    const rollbackBytes = inheritedEditorBytes
                        ? 4 * 1048576 + Math.max(0, parked.bytes - inheritedEditorBytes) + parked.largest
                        : 16 * 1048576 + parked.bytes + parked.largest;
                    if (rollbackBytes > this.memoryBudget.limitBytes) throw new Error('The current live sounds are too large for a safe editing rollback. Save them before loading another part.');
                    await this.adapter.releaseEditorHistory?.();
                    plan.verify(); check();
                    previous = null; plan = null;
                    this.adapter.detachEditingSources(); detached = true;
                    release(); release = null;
                    plan = await this.adapter.planEditing(info, check);
                    check();
                }
                release = await this.reservePreparation(plan.bytes, this.abort?.signal);
                check();
                this.status(`Loading ${part.name}, one sound at a time…`);
                decoded = await this.adapter.decodeEditing(info, plan, record => this.request(
                    `/${encodeURIComponent(this.song.id)}/parts/${part.id}/audio?sha256=${part.sha256}&key=${encodeURIComponent(record.key)}`,
                    { binary: true, maxBinaryBytes: record.bytes, signal: this.abort?.signal }));
                plan.verify(); check();
                if (!detached) previous = await this.adapter.capture({ liveOnly: true });
                plan.verify(); check();
                try {
                    this.adapter.recall(decoded, { start: options.start !== false, takeOwnership: true });
                    committed = true;
                } catch (error) {
                    // Restoring settings is synchronous. If a control fails,
                    // put back the exact pre-load buffers/state, without clones.
                    if (previous) this.adapter.recall(previous, { start: false, prepared: previous });
                    throw error;
                }
                previous = null;
                // The editor is the sole owner; do not put these mutable sounds
                // into cache/audioCache. Persistence runs one source at a time.
                decoded = null; plan = null;
                await this.adapter.whenPersisted?.();
                check();
            } catch (error) {
                if (detached && !committed && account === root.mygrainAccountContext?.user?.username && root.mygrainAccounts?.authenticated !== false) {
                    decoded = null; plan = null; previous = null;
                    this.adapter.detachEditingSources();
                    release?.(); release = null;
                    release = await this.reservePreparation(inheritedEditorBytes
                        ? 4 * 1048576 + Math.max(0, parked.bytes - inheritedEditorBytes) + parked.largest
                        : 16 * 1048576 + parked.bytes + parked.largest);
                    try {
                        previous = await checkpoint.restore(this.adapter.context());
                        this.adapter.recall(previous, { start: false, prepared: previous });
                        previous = null;
                        await this.adapter.whenPersisted?.();
                    } catch (rollbackError) {
                        keepCheckpoint = true;
                        throw new Error(`Editing restore failed (${error.message}); the original live sounds remain in browser checkpoint ${checkpoint.name}. ${rollbackError.message}`, { cause: rollbackError });
                    }
                }
                throw error;
            } finally {
                previous = null; decoded = null; plan = null;
                release?.();
                if (keepCheckpoint) checkpoint.database?.close();
                if (checkpoint && !keepCheckpoint) {
                    try { await checkpoint.dispose(); }
                    catch (error) { console.warn('Temporary editing checkpoint cleanup deferred:', error); }
                }
                finishPreparation?.();
            }
        }

        async audition(part) {
            // The phone's ready mix must not load the entire editable source
            // deck merely to hear one part. Recall/Amend remain live editing.
            if (this.phonePreparation) return this.loopPart(part.id);
            return this.recall(part);
        }

        async recall(part, options = {}) {
            this.cancel(true);
            const generation = this.generation;
            this.abort = new AbortController();
            this.status(`Loading ${part.name}…`);
            await this.adapter.ready();
            if (generation !== this.generation) return;
            if (this.partAudioAssets && this.adapter.planEditing && this.adapter.decodeEditing) {
                await this.recallEditable(part, generation, options);
            } else {
                for (const id of [...this.cache.keys()]) if (id !== sourceId(part)) this.releasePart({ id });
                const decoded = await this.loadPart(part, generation);
                if (generation !== this.generation) return;
                if (options.amend) {
                    this.requireEditing();
                    this.adapter.assertNotRecording?.();
                }
                this.armStage(generation, 'Restoring settings and sounds', part);
                this.adapter.recall(decoded, { start: options.start !== false });
                decoded.releaseMemory?.();
            }
            this.active = part.id;
            this.editing = options.amend ? { id: part.id, sha256: part.sha256, songId: this.song.id } : null;
            this.element('songBetaPartName').value = part.name;
            this.element('songBetaRepeats').value = part.repeats;
            this.status(options.amend ? `Amending ${part.name}. Edit the live pattern/settings/sounds, then Save Amendment to commit to every use of this part. The server copy is unchanged until saved.` : options.start === false ? `${part.name} loaded for editing. New Part saves a separate copy; Amend + Save Amendment updates every use of the existing part.` : `${part.name} recalled and playing live. It loops until stopped or another part is chosen.`);
        }

        copyLoop(part, selection) {
            if (this.playing || this.editing) throw new Error('Stop the song and finish the amendment before copying a saved loop.');
            const layers = copySelection(selection);
            if (!layers.length || !this.song?.parts.some(entry => entry.id === part.id && entry.sha256 === part.sha256)) throw new Error('Choose a current saved part and one or more loops, K tracks, drum lanes or EQs.');
            this.loopClipboard = {
                sourceSongId: this.song.id, sourcePartId: sourceId(part), sourceSha256: part.sha256,
                layers, ...(layers.length === 1 ? { layer: layers[0] } : {}), name: part.name, library: this.key
            };
            this.status(`Copied ${copiedLabel(this.loopClipboard)} from ${part.name}. Use Global Paste on the Song card to choose destination channels and parts. Nothing has changed yet.`);
        }

        openLoopCopyPicker(part, opener) {
            if (this.busy || this.playing || this.editing || !this.song || this.document.querySelector('.song-beta-copy-dialog, .song-beta-paste-dialog')) return;
            const dialog = this.document.createElement('dialog');
            dialog.className = 'song-beta-copy-dialog';
            dialog.setAttribute('aria-labelledby', 'songBetaCopyTitle');
            dialog.setAttribute('aria-describedby', 'songBetaCopyHelp');
            const heading = this.document.createElement('h3');
            heading.id = 'songBetaCopyTitle';
            heading.textContent = `Copy from ${part.name}`;
            const help = this.document.createElement('p');
            help.id = 'songBetaCopyHelp';
            help.textContent = 'Tick one or more items, then Copy selected. Use Global Paste on the Song card to choose destination channels and song parts, or Paste Part on one part. Sound targets include their EQ; EQ-only targets never copy audio or patterns. Unsaved live edits are not copied.';
            const buttons = this.document.createElement('div');
            buttons.className = 'song-beta-copy-layers';
            const inputs = new Map();
            const addChoice = (parent, id, text) => {
                const label = this.document.createElement('label');
                label.className = 'song-beta-copy-choice';
                const input = this.document.createElement('input');
                input.type = 'checkbox';
                input.dataset.layer = id;
                const caption = this.document.createElement('span');
                caption.textContent = text;
                label.append(input, caption);
                parent.append(label);
                inputs.set(id, input);
                return input;
            };
            for (const layer of loopLayers) {
                addChoice(buttons, layer, copyLabels.get(layer));
            }
            const kTracks = this.document.createElement('fieldset');
            kTracks.className = 'song-beta-copy-k-tracks';
            const kLegend = this.document.createElement('legend');
            kLegend.textContent = 'K recorder';
            const kChoices = this.document.createElement('div');
            kChoices.className = 'song-beta-copy-layers';
            for (const track of kCopyTracks) addChoice(kChoices, track, copyLabels.get(track));
            const kHelp = this.document.createElement('p');
            kHelp.textContent = 'Each track includes its recording, length, level, mute, pan, tuning, filter and effects. Other tracks and the destination’s K master on/off and level stay unchanged. Old K recordings are track 1.';
            kTracks.append(kLegend, kChoices, kHelp);
            const drums = this.document.createElement('fieldset');
            drums.className = 'song-beta-copy-drums';
            const legend = this.document.createElement('legend');
            legend.textContent = 'Drum machine';
            drums.append(legend);
            const all = addChoice(drums, 'drums', 'Drum machine (all)');
            const lanes = this.document.createElement('div');
            lanes.className = 'song-beta-copy-layers';
            for (const [id, label] of drumCopyLanes) addChoice(lanes, id, label);
            const drumHelp = this.document.createElement('p');
            drumHelp.textContent = 'All includes the shared drum mix/FX. Individual lanes keep the destination’s drum mix. Snare and Roll share their sound; Roll alone copies its pattern.';
            drums.append(lanes, drumHelp);
            const eqs = this.document.createElement('fieldset'); eqs.className = 'song-beta-copy-eqs';
            const eqLegend = this.document.createElement('legend'); eqLegend.textContent = 'Channel EQs only'; eqs.append(eqLegend);
            const eqAll = this.document.createElement('label'); eqAll.className = 'song-beta-copy-choice';
            const eqAllInput = this.document.createElement('input'); eqAllInput.type = 'checkbox'; eqAllInput.dataset.eqAll = 'true';
            eqAll.append(eqAllInput, this.document.createTextNode('All channel EQs')); eqs.append(eqAll);
            for (const [title, keys] of [['Loops', [...loopLayers, 'generated', 'sample']], ['K tracks', kCopyTracks], ['Drum lanes', drumCopyLanes.map(([id]) => id)]]) {
                const section = this.document.createElement('details'); section.open = true;
                const summary = this.document.createElement('summary'); summary.textContent = title;
                const choices = this.document.createElement('div'); choices.className = 'song-beta-copy-layers';
                for (const key of keys) addChoice(choices, 'eq:' + key, eqChannelLabel(key) + ' EQ');
                section.append(summary, choices); eqs.append(section);
            }
            const eqHelp = this.document.createElement('p'); eqHelp.textContent = 'EQ On/bypass and all four bands only. No audio, notes, patterns, track mix or other effects. Old parts without EQ copy a bypassed EQ; conversion happens on the server.'; eqs.append(eqHelp);
            const copy = this.document.createElement('button');
            copy.type = 'button';
            copy.className = 'performance-btn primary song-beta-copy-selected';
            copy.textContent = 'Copy selected';
            copy.disabled = true;
            const selection = () => copySelection([...inputs].filter(([, input]) => input.checked).map(([id]) => id));
            const sync = () => {
                const selectedDrums = drumCopyLanes.filter(([id]) => inputs.get(id).checked).length;
                all.checked = selectedDrums === drumCopyLanes.length;
                all.indeterminate = selectedDrums > 0 && !all.checked;
                const eqCount = eqCopyChannels.filter(id => inputs.get('eq:' + id).checked).length;
                eqAllInput.checked = eqCount === eqCopyChannels.length; eqAllInput.indeterminate = eqCount > 0 && !eqAllInput.checked;
                const count = selection().length;
                copy.disabled = !count;
                copy.textContent = count ? `Copy selected (${count})` : 'Copy selected';
            };
            eqAllInput.addEventListener('change', () => { for (const key of eqCopyChannels) inputs.get('eq:' + key).checked = eqAllInput.checked; sync(); });
            for (const [id, input] of inputs) input.addEventListener('change', () => {
                if (id === 'drums') for (const [lane] of drumCopyLanes) inputs.get(lane).checked = all.checked;
                sync();
            });
            copy.addEventListener('click', () => {
                const selected = selection();
                if (!selected.length) return;
                dialog.close();
                this.run(() => this.copyLoop(part, selected));
            });
            const cancel = this.document.createElement('button');
            cancel.type = 'button';
            cancel.className = 'performance-btn';
            cancel.textContent = 'Cancel';
            cancel.addEventListener('click', () => dialog.close());
            const actions = this.document.createElement('div');
            actions.className = 'song-beta-copy-actions';
            actions.append(copy, cancel);
            dialog.append(heading, help, buttons, kTracks, drums, eqs, actions);
            dialog.addEventListener('keydown', event => event.stopPropagation());
            dialog.addEventListener('keyup', event => event.stopPropagation());
            dialog.addEventListener('close', () => {
                dialog.remove();
                if (opener?.isConnected) opener.focus();
            }, { once: true });
            this.document.body.append(dialog);
            dialog.showModal();
        }

        openPastePartsPicker(opener) {
            if (this.busy || this.playing || this.editing || !this.song?.parts.length || this.document.querySelector('.song-beta-copy-dialog, .song-beta-paste-dialog')) return;
            const copied = this.loopClipboard;
            if (!copied || copied.library !== this.key || !copySelection(copied.layers || copied.layer).length) {
                this.status('Use Copy From Part and choose loops, K tracks, drum lanes or EQs first.', true);
                return;
            }
            try { this.adapter.assertNotRecording?.(); }
            catch (error) { this.status(error.message, true); return; }
            const expected = { library: this.key, songId: this.song.id, revision: this.song.revision };
            const parts = this.song.parts.map(part => ({ ...part }));
            const dialog = this.document.createElement('dialog');
            dialog.className = 'song-beta-copy-dialog song-beta-paste-dialog';
            dialog.setAttribute('aria-labelledby', 'songBetaPasteTitle');
            dialog.setAttribute('aria-describedby', 'songBetaPasteHelp');
            const heading = this.document.createElement('h3');
            heading.id = 'songBetaPasteTitle'; heading.textContent = 'Global Paste — choose destinations';
            const help = this.document.createElement('p');
            help.id = 'songBetaPasteHelp';
            help.textContent = `Paste ${copiedLabel(copied)} from ${copied.name}. Tick the destinations, then Paste selected. Selected items will be replaced; unselected sounds, tempo and repeats stay unchanged. Shared uses are linked and change together. Arm Cache is not started.`;
            const destinations = this.document.createElement('fieldset'); destinations.className = 'song-beta-paste-targets';
            const targetLegend = this.document.createElement('legend'); targetLegend.textContent = 'Destination channels'; destinations.append(targetLegend);
            const fullInputs = new Map(), eqInputs = new Map(), eqSources = new Map();
            const copiedLayers = copySelection(copied.layers || copied.layer), copiedEqs = copiedLayers.filter(item => item.startsWith('eq:')).map(item => item.slice(3));
            const inputs = new Map();
            const choice = (parent, text) => {
                const label = this.document.createElement('label'); label.className = 'song-beta-copy-choice';
                const input = this.document.createElement('input'); input.type = 'checkbox';
                const caption = this.document.createElement('span'); caption.textContent = text;
                label.append(input, caption); parent.append(label); return input;
            };
            const fullLayers = copiedLayers.filter(item => !item.startsWith('eq:')).flatMap(item => item === 'drums' ? drumCopyLanes.map(([id]) => id) : [item]);
            let allDrums = null;
            if (copiedLayers.includes('drums')) { allDrums = choice(destinations, 'All drum lanes + shared drum mix/FX'); allDrums.checked = true; allDrums.dataset.pasteAllDrums = 'true'; }
            const fullChoices = this.document.createElement('div'); fullChoices.className = 'song-beta-copy-layers';
            for (const layer of fullLayers) { const input = choice(fullChoices, copyLabels.get(layer)); input.dataset.pasteLayer = layer; input.checked = true; fullInputs.set(layer, input); }
            destinations.append(fullChoices);
            if (copiedEqs.length) {
                const note = this.document.createElement('p'); note.textContent = 'Tick the destination EQs. A single copied EQ can go to several channels. If several EQs were copied, choose the source beside each destination. Audio and other settings stay unchanged.'; destinations.append(note);
                const allEq = choice(destinations, 'Select all destination EQs'); allEq.dataset.pasteAllEq = 'true';
                for (const [title, keys] of [['Loop EQs', [...loopLayers, 'generated', 'sample']], ['K track EQs', kCopyTracks], ['Drum EQs', drumCopyLanes.map(([id]) => id)]]) {
                    const group = this.document.createElement('details'); group.open = true;
                    const summary = this.document.createElement('summary'); summary.textContent = title;
                    const grid = this.document.createElement('div'); grid.className = 'song-beta-copy-layers';
                    for (const target of keys) {
                        const row = this.document.createElement('div'); row.className = 'song-beta-eq-destination';
                        const input = choice(row, eqChannelLabel(target) + ' EQ'); input.dataset.pasteEq = target; input.checked = copiedEqs.includes(target); eqInputs.set(target, input);
                        const select = this.document.createElement('select'); select.dataset.eqSourceFor = target; select.setAttribute('aria-label', 'Source EQ for ' + eqChannelLabel(target));
                        for (const source of copiedEqs) { const option = this.document.createElement('option'); option.value = source; option.textContent = 'From ' + eqChannelLabel(source); select.append(option); }
                        select.value = copiedEqs.includes(target) ? target : copiedEqs[0]; select.hidden = copiedEqs.length === 1; eqSources.set(target, select);
                        row.append(select); grid.append(row);
                    }
                    group.append(summary, grid); destinations.append(group);
                }
                allEq.addEventListener('change', () => { for (const input of eqInputs.values()) input.checked = allEq.checked; sync(); });
            }
            const targetSelection = () => {
                const full = [...fullInputs].filter(([, input]) => input.checked).map(([id]) => id);
                if (allDrums?.checked) full.push('drums');
                const eqMap = Object.fromEntries([...eqInputs].filter(([, input]) => input.checked).map(([target]) => [target, eqSources.get(target).value]));
                return { layers: copySelection([...full, ...new Set(Object.values(eqMap).map(source => 'eq:' + source))]), eqMap };
            };
            const master = this.document.createElement('div');
            const all = choice(master, 'Select all song parts'); all.dataset.selectAll = 'true';
            const list = this.document.createElement('div'); list.className = 'song-beta-paste-parts';
            const counts = new Map();
            parts.forEach(part => counts.set(sourceId(part), (counts.get(sourceId(part)) || 0) + 1));
            parts.forEach((part, index) => {
                const uses = counts.get(sourceId(part));
                const input = choice(list, `${index + 1}. ${part.name}${uses > 1 ? ` (shared: all ${uses} uses change)` : ''}`);
                input.dataset.partId = part.id; inputs.set(part.id, input);
            });
            const paste = this.document.createElement('button'); paste.type = 'button';
            paste.className = 'performance-btn primary song-beta-paste-selected';
            const sync = () => {
                const selected = [...inputs.values()].filter(input => input.checked).length;
                all.checked = selected === parts.length;
                all.indeterminate = selected > 0 && !all.checked;
                const targets = targetSelection();
                paste.disabled = !selected || !targets.layers.length;
                paste.textContent = selected ? `Paste selected (${selected})` : 'Paste selected';
                const allEq = destinations.querySelector('[data-paste-all-eq]');
                if (allEq) { const n = [...eqInputs.values()].filter(i => i.checked).length; allEq.checked = n === eqInputs.size; allEq.indeterminate = n > 0 && !allEq.checked; }
                for (const [target, select] of eqSources) select.disabled = !eqInputs.get(target).checked;
            };
            for (const [id, input] of fullInputs) input.addEventListener('change', () => {
                if (allDrums && drumCopyLanes.some(([key]) => key === id)) { const n = drumCopyLanes.filter(([key]) => fullInputs.get(key).checked).length; allDrums.checked = n === drumCopyLanes.length; allDrums.indeterminate = n > 0 && !allDrums.checked; }
                sync();
            });
            if (allDrums) allDrums.addEventListener('change', () => { for (const [key] of drumCopyLanes) fullInputs.get(key).checked = allDrums.checked; sync(); });
            for (const input of eqInputs.values()) input.addEventListener('change', sync);
            for (const select of eqSources.values()) select.addEventListener('change', sync);
            for (const part of parts) inputs.get(part.id).addEventListener('change', () => {
                const checked = inputs.get(part.id).checked;
                for (const entry of parts) if (sourceId(entry) === sourceId(part)) inputs.get(entry.id).checked = checked;
                sync();
            });
            all.addEventListener('change', () => { for (const input of inputs.values()) input.checked = all.checked; sync(); });
            paste.addEventListener('click', () => {
                const selected = parts.filter(part => inputs.get(part.id).checked);
                if (!selected.length) return;
                dialog.close();
                this.run(() => this.pasteParts(selected, expected, copied, targetSelection()));
            });
            const cancel = this.document.createElement('button'); cancel.type = 'button';
            cancel.className = 'performance-btn'; cancel.textContent = 'Cancel';
            cancel.addEventListener('click', () => dialog.close());
            const actions = this.document.createElement('div'); actions.className = 'song-beta-copy-actions';
            actions.append(paste, cancel); dialog.append(heading, help, destinations, master, list, actions);
            dialog.addEventListener('keydown', event => event.stopPropagation());
            dialog.addEventListener('keyup', event => event.stopPropagation());
            dialog.addEventListener('close', () => { dialog.remove(); if (opener?.isConnected) opener.focus(); }, { once: true });
            sync(); this.document.body.append(dialog); dialog.showModal();
        }

        async pasteParts(parts, expected = { library: this.key, songId: this.song?.id, revision: this.song?.revision }, copied = this.loopClipboard, selection = null) {
            if (expected.library !== this.key || expected.songId !== this.song?.id || expected.revision !== this.song?.revision) throw new Error('The song changed while choosing destinations. Reopen Paste Part to select its current parts.');
            if (!copied || copied !== this.loopClipboard || copied.library !== this.key || !copySelection(copied.layers || copied.layer).length) throw new Error('The copy buffer changed. Reopen Paste Part before pasting.');
            if (this.playing || this.editing) throw new Error('Stop the song and finish the amendment before pasting parts.');
            this.adapter.assertNotRecording?.();
            if (!Array.isArray(parts) || !parts.length || parts.some(part => !this.song.parts.some(entry => entry.id === part?.id && entry.sha256 === part.sha256 && sourceId(entry) === sourceId(part)))) throw new Error('Choose current song parts before pasting.');
            const chosen = pasteSelection(copied, selection);
            const targets = [...new Map(parts.map(part => [sourceId(part), part])).values()];
            // Select all can include the copied source. Save it last so every
            // other destination still reads the unchanged pinned source hash.
            if (copied.sourceSongId === this.song.id) targets.sort((a, b) => Number(sourceId(a) === copied.sourcePartId) - Number(sourceId(b) === copied.sourcePartId));
            const positions = this.song.parts.filter(part => targets.some(target => sourceId(target) === sourceId(part))).length;
            let completed = 0;
            let revision = this.song.revision;
            for (const part of targets) {
                try {
                    if (this.key !== expected.library || this.song?.id !== expected.songId || this.song.revision !== revision || this.loopClipboard !== copied) throw new Error('Song or copy buffer changed during pasting.');
                    await this.pasteLoop(part, { confirmed: true, copied, selection: selection ? chosen : null, batch: true, progress: `${completed + 1}/${targets.length}: ` });
                    completed += 1; revision = this.song.revision;
                } catch (error) {
                    throw new Error(`Saved ${completed}/${targets.length} selected saved parts; stopped at ${part.name}: ${error.message} Earlier successful pastes remain saved. No further destinations were attempted. Refresh Songs before retrying; a lost response may mean this destination was also saved.`, { cause: error });
                }
            }
            this.status(`Pasted ${pasteLabel(copied, chosen)} from ${copied.name} into ${completed} saved part${completed === 1 ? '' : 's'} (${positions} song position${positions === 1 ? '' : 's'}). Unselected sounds are unchanged. Use Arm Cache once when ready. Your live pattern and copy buffer are unchanged.`);
        }

        async pasteLoop(part, options = {}) {
            if (this.revisionConflict) this.requireEditing();
            if (this.playing || this.editing) throw new Error('Stop the song and finish the amendment before pasting a loop.');
            this.adapter.assertNotRecording?.();
            const copied = options.copied || this.loopClipboard;
            if (!copied || copied.library !== this.key || !copySelection(copied.layers || copied.layer).length) throw new Error('Use Copy From Part and choose loops, K tracks, drum lanes or EQs first.');
            const chosen = pasteSelection(copied, options.selection), layers = chosen.layers;
            const label = pasteLabel(copied, chosen);
            if (!this.song?.parts.some(entry => entry.id === part.id && entry.sha256 === part.sha256)) throw new Error('Refresh Songs before pasting into a changed part.');
            const uses = this.song.parts.filter(entry => sourceId(entry) === sourceId(part)).length;
            if (!options.confirmed && !root.confirm(`Replace ${label} in ${part.name} completely with the saved copy from ${copied.name}?${uses > 1 ? ` This shared part is used ${uses} times; every use changes.` : ''} Unselected sounds, tempo, grid length and repeats stay unchanged.${!this.canEditSong() ? ' Editing access will be requested automatically; another device’s lock cannot be overridden.' : ''}`)) return;
            await this.ensureEditing();
            this.adapter.assertNotRecording?.();
            if (!this.song?.parts.some(entry => entry.id === part.id && entry.sha256 === part.sha256)) throw new Error('The destination changed while requesting editing. Refresh Songs before pasting.');
            this.status(`${options.progress || ''}Pasting ${label} into ${part.name} on the server…`);
            const result = await this.request(`/${encodeURIComponent(this.song.id)}/parts/${part.id}/paste-loop?sha256=${part.sha256}`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ sourceSongId: copied.sourceSongId, sourcePartId: copied.sourcePartId, sourceSha256: copied.sourceSha256, ...(layers.length === 1 ? { layer: layers[0] } : { layers }), ...(options.selection ? { eqMap: chosen.eqMap } : {}) })
            });
            this.cancel(true, { hardCut: true });
            this.acceptSong(result.song);
            const message = `Pasted ${label} from ${copied.name} into every use of ${part.name}. Unselected sounds and arrangement settings are unchanged.`;
            if (!options.batch) this.status(`${message} Paste more parts, then use Arm Cache once when ready; unchanged audio will be reused. Your live pattern was not replaced; Amend loads the pasted part for editing.`);
        }

        async savePart() {
            if (!this.editing || this.editing.songId !== this.song?.id) throw new Error('Choose Amend on a saved part first.');
            const draft = { ...this.editing };
            const name = this.element('songBetaPartName').value.trim();
            const repeats = Number(this.element('songBetaRepeats').value);
            if (!name || !Number.isInteger(repeats) || repeats < 1 || repeats > 64) throw new Error('Enter a part name and 1–64 pattern repeats.');
            await this.ensureEditing(draft);
            this.cancel(true, { hardCut: true });
            this.status('Capturing the amended full pattern and sounds…');
            const body = await this.adapter.capture();
            if (body.size > 128 * 1024 * 1024) throw new Error('This part exceeds the 128 MB upload limit.');
            const result = await this.request(`/${encodeURIComponent(draft.songId)}/parts/${draft.id}/save?sha256=${draft.sha256}&name=${encodeURIComponent(name)}&repeats=${repeats}`, {
                method: 'POST', headers: { 'Content-Type': 'application/zip' }, body
            });
            this.acceptSong(result.song);
            this.active = draft.id;
            const saved = this.song.parts.find(part => part.id === draft.id);
            this.status(`Saved amendment to every use of ${name}. Its previous revision is retained on the server. ${this.hasSavedRender(saved) ? 'Audio is unchanged; its saved render is retained.' : 'Only this shared part needs a new render.'} Arm Cache to prepare pending parts.`);
        }

        async amendPart(part) {
            if (this.playing || this.editing) throw new Error('Stop Song and save or cancel the current amendment before amending another part.');
            this.adapter.assertNotRecording?.();
            this.amendLoading = { id: part.id, stage: 'Checking editing access' };
            this.expandedParts.add(`${this.song.id}:${part.id}`);
            this.render();
            try {
                await this.ensureEditing(part);
                this.adapter.assertNotRecording?.();
                if (this.active !== part.id) return await this.recall(part, { start: false, amend: true });
                this.cancel(true, { hardCut: true });
                this.active = part.id;
                this.editing = { id: part.id, sha256: part.sha256, songId: this.song.id };
                if (!this.element('songBetaPartName').value.trim()) this.element('songBetaPartName').value = part.name;
                this.status(`Amending the currently loaded ${part.name}. Your live edits are kept; Save Amendment commits them to every use of this part.`);
            } finally {
                this.amendLoading = null;
                this.render();
            }
        }

        async deletePart(part) {
            if (!root.confirm(`Remove this occurrence of ${part.name} from the song? Other uses are unchanged. Its saved files remain in the server recovery history.`)) return;
            await this.ensureEditing(part);
            this.cancel(true, { hardCut: true });
            const result = await this.request(`/${encodeURIComponent(this.song.id)}/parts/${part.id}/delete?sha256=${part.sha256}`, { method: 'POST' });
            this.acceptSong(result.song);
            this.status(`Removed this occurrence of ${part.name}. Other uses and server recovery files are retained.`);
            const songId = result.song.id;
            root.requestAnimationFrame?.(() => {
                if (this.song?.id !== songId) return;
                this.element('songBetaCard')?.scrollIntoView({ behavior: 'instant', block: 'start', inline: 'nearest' });
            });
        }

        async exportSong() {
            if (!this.song?.parts.length) throw new Error('Save at least one part before exporting.');
            if (this.playing || this.editing) throw new Error('Stop the song and finish the amendment before exporting.');
            const promptGeneration = this.generation;
            const filename = await this.adapter.chooseSongExportFilename(this.song);
            if (promptGeneration !== this.generation) throw new DOMException('Cancelled', 'AbortError');
            if (!filename) { this.status('Song WAV export cancelled.'); return; }
            if (!this.armed) await this.arm();
            if (!this.armed) throw new DOMException('Cancelled', 'AbortError');
            const generation = this.generation;
            const abort = this.abort = new AbortController();
            try {
                this.status(`Building ${filename} from the complete arrangement…`);
                const renders = this.song.parts.every(part => this.renders.has(sourceId(part))) ? this.renders : part => this.loadRender(part, abort.signal, generation);
                const result = await this.adapter.exportSong(this.song.parts, renders, filename, abort.signal);
                if (generation !== this.generation) return;
                this.status(`Saved ${result.savedName || filename} to the rendered WAV folder.${result.peak >= .999 ? ' Audio reaches full scale; check the saved part levels if you hear distortion.' : ''}`);
            } finally {
                if (this.abort === abort) this.abort = null;
            }
        }

        async playSongFromHere(partId) {
            if (this.editing) throw new Error('Finish or cancel the amendment before playing the song.');
            const part = this.song?.parts.find(part => part.id === partId);
            if (!part) throw new Error('That part is no longer in this song. Choose a current part.');
            if (!this.armed) {
                if (!root.confirm(`Arm Cache?\n\nThe song cache is not armed. Prepare it now, then play from ${part.name}?`)) return;
                await this.arm();
                if (!this.armed) return;
            }
            await this.playSong(partId);
        }

        async loopPart(partId) {
            if (this.playing && this.loopPartId === partId) { this.stop(); return; }
            if (this.editing) throw new Error('Finish or cancel the amendment before looping a part.');
            const part = this.song?.parts.find(part => part.id === partId);
            if (!part) throw new Error('That part is no longer in this song. Choose a current part.');
            if (!this.armed) {
                if (!root.confirm(`Arm Cache?\n\nPrepare the song cache, then loop ${part.name} until Stop Song?`)) return;
                await this.arm();
                if (!this.armed) return;
            }
            await this.playSong(partId, { loopPart: true });
        }

        async playSong(startPartId = null, options = {}) {
            if (!this.armed || !this.song?.parts.length) throw new Error('Arm Cache successfully before playing the song.');
            if (this.editing) throw new Error('Finish or cancel the amendment before playing the song.');
            const startIndex = startPartId === null ? 0 : this.song.parts.findIndex(part => part.id === startPartId);
            if (startIndex < 0) throw new Error('That part is no longer in this song. Choose a current part.');
            const looping = options.loopPart === true || this.loopSong;
            const parts = options.loopPart ? [this.song.parts[startIndex]] : looping ? this.song.parts : this.song.parts.slice(startIndex);
            this.cancel(true);
            const generation = this.generation;
            await this.adapter.ready();
            if (generation !== this.generation) return;
            this.adapter.stop({ hardCut: true });
            this.playing = true;
            this.loopPartId = options.loopPart ? startPartId : null;
            try {
                const ended = reason => {
                    if (generation !== this.generation) return;
                    this.cancel(true, { hardCut: true });
                    const finishedMessage = startIndex ? `Song finished. Played from ${parts[0].name} through the last part.` : 'Song finished. All parts played in order.';
                    this.status(reason === 'interrupted' ? 'Song stopped because its audio context was interrupted. Resume MYGRAIN before playing again.' : reason === 'finished' ? finishedMessage : `Song stopped: ${reason}`, !['finished', 'interrupted'].includes(reason));
                    this.render();
                };
                if (!looping && parts.every(part => this.renders.has(sourceId(part)))) {
                    this.playback = this.adapter.scheduleSong(parts, this.renders, ended);
                } else {
                    const abort = this.abort = new AbortController();
                    this.status(`Loading song audio from ${this.song.parts[startIndex].name}…`);
                    const load = part => this.renders.get(sourceId(part)) || this.loadRender(part, abort.signal, generation);
                    const playback = await this.adapter.scheduleStoredSong(parts, load, ended, abort.signal, undefined, { loop: looping, startIndex: options.loopPart ? 0 : startIndex });
                    if (generation !== this.generation) { playback.stop(); return; }
                    this.playback = playback;
                }
                const tick = () => {
                    if (generation !== this.generation) return;
                    if (!this.adapter.clockRunning(this.playback)) {
                        this.cancel(true);
                        this.status('Song stopped because its audio clock was suspended.');
                        this.render();
                        return;
                    }
                    const entry = this.playback.entries.find(entry => this.adapter.time() < entry.end) || this.playback.entries.at(-1);
                    if (entry.id !== this.active) {
                        this.active = entry.id;
                        const mode = this.loopPartId ? 'Looping part' : looping ? 'Looping song' : 'Playing';
                        this.status(`${mode} ${this.song.parts.findIndex(part => part.id === entry.id) + 1}/${this.song.parts.length}: ${this.song.parts.find(part => part.id === entry.id).name} · audio-clock scheduled.`);
                        this.render();
                    }
                    this.timer = root.setTimeout(tick, 25);
                };
                tick();
            } catch (error) {
                this.cancel(true);
                this.status(error.message, true);
                this.render();
            }
        }

        async setRepeats(part, value) {
            if (this.playing || this.editing) throw new Error('Stop playback and finish the amendment before changing repeats.');
            const repeats = Number(value);
            if (!Number.isInteger(repeats) || repeats < 1 || repeats > 64) throw new Error('Choose 1–64 whole-pattern repeats.');
            if (repeats === part.repeats) return;
            const parts = this.song.parts.map(entry => ({ id: entry.id, name: entry.name, playbackSteps: entry.playbackSteps, repeats: entry.id === part.id ? repeats : entry.repeats }));
            await this.saveArrangement(parts);
            if (this.active === part.id) this.element('songBetaRepeats').value = repeats;
        }

        async setSteps(part, value) {
            if (this.playing || this.editing) throw new Error('Stop playback and finish the amendment before changing steps.');
            const steps = Number(value);
            const fullSteps = part.patternSteps * (part.patternCycleMultiplier ?? 1);
            if (!Number.isInteger(steps) || steps < 1 || steps > fullSteps) throw new Error(`Choose 1–${fullSteps} steps. The complete saved pattern is retained.`);
            if (steps === (part.playbackSteps ?? fullSteps)) return;
            const parts = this.song.parts.map(entry => ({ id: entry.id, name: entry.name, repeats: entry.repeats, playbackSteps: entry.id === part.id ? steps : entry.playbackSteps }));
            await this.saveArrangement(parts);
            this.status(`Saved ${steps} of ${fullSteps} steps for this occurrence of ${part.name}. The full pattern is unchanged; increase Steps to restore it. Arm Cache before playback; existing audio is reused.`);
        }

        async setColour(part, value) {
            if (value !== null && !/^#[a-f0-9]{6}$/i.test(value)) throw new Error('Choose a six-digit hex colour or clear the colour.');
            const colour = value === null ? null : value.toLowerCase();
            if (colour === (part.colour || null)) return;
            await this.ensureEditing(part);
            const result = await this.request(`/${encodeURIComponent(this.song.id)}/parts/${part.id}/colour?sha256=${part.sha256}`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ colour })
            });
            this.song = result.song;
            this.songs = this.songs.map(song => song.id === result.song.id ? result.song : song);
            this.status(colour ? `Colour saved for ${part.name}. Playback and the armed cache are unchanged.` : `Colour cleared for ${part.name}.`);
        }

        async arrange(part, direction = 0) {
            if (this.playing) throw new Error('Stop the song before changing its arrangement.');
            const parts = this.song.parts.map(entry => ({ id: entry.id, name: entry.name, repeats: entry.repeats, playbackSteps: entry.playbackSteps }));
            const index = parts.findIndex(entry => entry.id === part.id);
            if (direction) {
                const destination = index + direction;
                if (destination < 0 || destination >= parts.length) return;
                [parts[index], parts[destination]] = [parts[destination], parts[index]];
            } else {
                const name = root.prompt('Part name', part.name);
                if (name === null) return;
                for (const [position, entry] of this.song.parts.entries()) {
                    if (sourceId(entry) === sourceId(part)) parts[position] = { ...parts[position], name };
                }
            }
            await this.saveArrangement(parts);
        }

        async saveArrangement(parts) {
            await this.ensureEditing();
            const result = await this.request(`/${encodeURIComponent(this.song.id)}/arrange`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ parts })
            });
            this.acceptSong(result.song);
            this.status('Arrangement saved. Arm Cache again before Play Song.');
        }

        renderCacheSummary() {
            const uniqueParts = this.uniqueParts();
            const ready = uniqueParts.filter(part => this.isPartReady(part)).length;
            const pending = uniqueParts.length - ready;
            const summary = this.element('songBetaCacheSummary');
            if (summary) summary.textContent = this.song ? `${ready} unique parts ready · ${pending} to prepare · ${this.song.parts.length} placements. Reused parts share sounds and renders. Only new or changed audio is rendered.` : 'Choose a song to see its cache status.';
            return pending;
        }

        render() {
            this.renderLockUi();
            const changesBlocked = this.revisionConflict;
            for (const id of ['songBetaBackupAccess', 'songBetaOpenAccess']) {
                const button = this.element(id);
                if (button) button.disabled = this.busy || this.playing || Boolean(this.editing);
            }
            const accessStatus = this.element('songBetaAccessStatus');
            if (accessStatus) accessStatus.textContent = this.storage.persistent
                ? 'Songs and samples live on the server. Back up Song Access once; open that file on another device. Keep it private: it grants access to this entire library. Browser audio storage is only an optional cache.'
                : 'Browser storage is unavailable. Songs and audio still load from the server; keep your Song Access file and reopen it after each reload.';
            const select = this.element('songBetaSongs');
            select.replaceChildren();
            const placeholder = this.document.createElement('option');
            placeholder.value = '';
            placeholder.textContent = 'Choose a saved song';
            select.append(placeholder);
            for (const song of this.songs) {
                const option = this.document.createElement('option');
                option.value = song.id;
                option.textContent = song.name;
                select.append(option);
            }
            select.value = this.song?.id || '';
            select.disabled = this.busy || this.playing || Boolean(this.editing);
            this.element('songBetaNewSong').disabled = this.busy || this.playing || Boolean(this.editing);
            this.element('songBetaRefresh').disabled = this.busy || this.playing;
            const renameSong = this.element('songBetaRenameSong');
            if (renameSong) renameSong.disabled = changesBlocked || this.busy || this.playing || !this.song || Boolean(this.editing);
            this.element('songBetaSavePart').disabled = changesBlocked || this.busy || this.playing || !this.editing;
            this.element('songBetaCancelEdit').disabled = this.busy || this.playing || !this.editing;
            this.element('songBetaNewPart').disabled = changesBlocked || this.busy || this.playing || !this.song;
            const pasteParts = this.element('songBetaPasteParts');
            if (pasteParts) {
                pasteParts.disabled = changesBlocked || this.busy || this.playing || Boolean(this.editing) || !this.song?.parts.length || !this.loopClipboard || this.loopClipboard.library !== this.key;
                pasteParts.title = this.loopClipboard ? `Paste ${copiedLabel(this.loopClipboard)} from ${this.loopClipboard.name} into selected saved song parts. Arm Cache stays manual.` : 'Use Copy From Part to fill the copy buffer first.';
            }
            const convertK = this.element('songBetaConvertK');
            if (convertK) convertK.disabled = changesBlocked || this.busy || this.playing || Boolean(this.editing) || !this.song?.parts.length;
            const convertFx = this.element('songBetaConvertFx');
            if (convertFx) convertFx.disabled = changesBlocked || this.busy || this.playing || Boolean(this.editing) || !this.song?.parts.length;
            const convertW = this.element('songBetaConvertW');
            if (convertW) convertW.disabled = changesBlocked || this.busy || this.playing || Boolean(this.editing) || !this.song?.parts.length;
            this.element('songBetaArm').disabled = this.busy || this.playing || !this.song?.parts.length || Boolean(this.editing);
            const pending = this.renderCacheSummary();
            this.element('songBetaArm').textContent = this.armed ? 'Cache Armed ✓' : `Arm Cache${pending ? ` (${pending})` : ''}`;
            this.element('songBetaArm').classList.toggle('song-beta-armed', this.armed);
            const concurrency = this.element('songBetaArmConcurrency');
            if (concurrency) {
                concurrency.value = String(this.preparationConcurrency());
                concurrency.disabled = this.busy || this.playing || this.phonePreparation;
                if (this.phonePreparation) {
                    const sequential = concurrency.querySelector?.('option[value="1"]');
                    if (sequential) sequential.textContent = 'One part at a time (phone/tablet memory protection)';
                    concurrency.title = 'Phones and iPads prepare one part at a time to reduce audio memory use.';
                }
            }
            this.element('songBetaPlay').disabled = this.busy || this.playing || !this.armed || Boolean(this.editing);
            const loopSong = this.element('songBetaLoop');
            if (loopSong) {
                loopSong.disabled = this.busy || this.playing || !this.song?.parts.length || Boolean(this.editing);
                loopSong.setAttribute('aria-pressed', String(this.loopSong));
                loopSong.classList.toggle('song-beta-looping', this.loopSong);
                loopSong.textContent = this.loopSong ? 'Loop Song: On' : 'Loop Song';
                loopSong.title = 'Repeat the complete song until Stop Song. Stop playback to change this option.';
            }
            const exportButton = this.element('songBetaExport');
            if (exportButton) exportButton.disabled = this.busy || this.playing || !this.song?.parts.length || Boolean(this.editing);
            const list = this.element('songBetaParts');
            const clipboard = this.element('songBetaClipboard');
            if (clipboard) {
                clipboard.textContent = this.loopClipboard ? `Copied: ${copiedLabel(this.loopClipboard)} from ${this.loopClipboard.name}. Use Global Paste to choose destination channels and parts.` : '';
                clipboard.hidden = !this.loopClipboard;
            }
            let amendWait = this.element('songBetaAmendWait');
            if (this.amendLoading) {
                if (!amendWait) {
                    amendWait = this.document.createElement('div');
                    amendWait.id = 'songBetaAmendWait';
                    amendWait.setAttribute('role', 'status');
                    amendWait.setAttribute('aria-live', 'polite');
                    amendWait.setAttribute('aria-atomic', 'true');
                    this.document.body.append(amendWait);
                }
                const loadingPart = this.song?.parts.find(part => part.id === this.amendLoading.id);
                amendWait.textContent = `Please wait — loading ${loadingPart?.name || 'part'} for Amend… ${this.amendLoading.stage}. Ready when the part turns orange.`;
            } else if (amendWait) amendWait.remove();
            list.replaceChildren();
            for (const [index, part] of (this.song?.parts || []).entries()) {
                const row = this.document.createElement('div');
                row.className = 'song-beta-part';
                if (/^#[a-f0-9]{6}$/i.test(part.colour || '')) {
                    row.style.setProperty('--song-beta-part-colour', part.colour);
                    row.style.setProperty('--song-beta-part-tint', `${part.colour}22`);
                }
                row.classList.toggle('song-beta-active', part.id === this.active);
                row.classList.toggle('song-beta-amending', !this.amendLoading && part.id === this.editing?.id);
                if (part.id === this.amendLoading?.id) {
                    row.setAttribute('aria-busy', 'true');
                    const progress = this.document.createElement('p');
                    progress.id = 'songBetaAmendProgress';
                    progress.className = 'song-beta-amend-progress';
                    progress.setAttribute('role', 'status');
                    progress.textContent = `Please wait… ${this.amendLoading.stage}. Ready when this part turns orange.`;
                    row.append(progress);
                }
                const header = this.document.createElement('div');
                header.className = 'song-beta-part-header';
                const controls = this.document.createElement('div');
                controls.className = 'song-beta-part-controls';
                controls.id = `song-beta-controls-${this.song.id}-${part.id}`;
                const expansionKey = `${this.song.id}:${part.id}`;
                controls.hidden = !this.expandedParts.has(expansionKey);
                const toggle = this.document.createElement('button');
                toggle.type = 'button';
                toggle.className = 'performance-btn song-beta-toggle';
                const partName = this.document.createElement('span');
                partName.className = 'song-beta-part-name';
                partName.textContent = `${index + 1}. ${part.name}`;
                toggle.append(partName);
                toggle.setAttribute('aria-expanded', String(!controls.hidden));
                toggle.setAttribute('aria-controls', controls.id);
                toggle.title = `${part.name}: show or hide part controls`;
                toggle.addEventListener('click', () => {
                    controls.hidden = !controls.hidden;
                    toggle.setAttribute('aria-expanded', String(!controls.hidden));
                    if (controls.hidden) this.expandedParts.delete(expansionKey);
                    else this.expandedParts.add(expansionKey);
                });
                header.append(toggle);
                const actions = this.document.createElement('div');
                actions.className = 'song-beta-part-actions';
                const transport = this.document.createElement('button');
                const canStop = this.playing || Boolean(this.abort);
                transport.type = 'button';
                transport.className = `performance-btn song-beta-part-transport ${canStop ? 'song-beta-part-stop' : 'song-beta-part-play'}`;
                transport.textContent = canStop ? '■ Stop' : '▶ Play';
                transport.setAttribute('aria-label', canStop ? `Stop song from ${part.name}` : `Play song at ${part.name}`);
                transport.title = canStop ? 'Stop the entire song, from any part. Also cancels cache preparation.' : `Start the song at ${part.name} and continue through the following parts.`;
                transport.disabled = !canStop && (this.busy || Boolean(this.editing));
                transport.addEventListener('click', () => {
                    if (this.playing || this.abort) this.stop();
                    else this.run(() => this.playSongFromHere(part.id));
                });
                actions.append(transport);
                const cacheStatus = this.document.createElement('span');
                cacheStatus.className = 'song-beta-cache-state';
                cacheStatus.textContent = this.isPartReady(part) ? 'Ready' : this.hasSavedRender(part) ? 'Saved' : (part.revision || 1) > 1 ? 'Changed' : 'New';
                cacheStatus.title = this.isPartReady(part) ? 'Unchanged audio is ready in playback memory or song storage.' : this.hasSavedRender(part) ? 'The existing server render will be loaded without rendering again.' : 'Arm Cache will render only this new or changed part.';
                toggle.append(cacheStatus);
                row.append(header, controls);
                const button = this.document.createElement('button');
                button.type = 'button';
                button.className = 'performance-btn song-beta-recall';
                button.textContent = 'Audition';
                button.setAttribute('aria-label', `Audition ${part.name}`);
                button.setAttribute('aria-pressed', String(part.id === this.active));
                button.disabled = this.busy || Boolean(this.editing);
                button.title = this.phonePreparation ? 'Loop this part using prepared song audio. Recall loads editable instruments and original sounds.' : 'Load this part into the live instruments and audition it.';
                button.addEventListener('click', () => this.run(() => this.audition(part)));
                controls.append(button);
                const playFrom = this.document.createElement('button');
                playFrom.type = 'button';
                playFrom.className = 'performance-btn song-beta-play-from';
                playFrom.textContent = 'Play Song From Here';
                playFrom.setAttribute('aria-label', `Play song from ${part.name}`);
                playFrom.title = this.armed ? 'Play this part and every following part with the saved repeats and tempos.' : 'Ask to arm the cache, then play this part and the rest of the song.';
                playFrom.disabled = this.busy || Boolean(this.editing);
                playFrom.addEventListener('click', () => this.run(() => this.playSongFromHere(part.id)));
                controls.append(playFrom);
                const loopPart = this.document.createElement('button');
                loopPart.type = 'button';
                loopPart.className = 'performance-btn song-beta-loop-part';
                const isLoopingPart = this.playing && this.loopPartId === part.id;
                loopPart.textContent = isLoopingPart ? 'Stop Part Loop' : 'Loop Part';
                loopPart.setAttribute('aria-label', `${isLoopingPart ? 'Stop looping' : 'Loop part'} ${part.name}`);
                loopPart.setAttribute('aria-pressed', String(isLoopingPart));
                loopPart.classList.toggle('song-beta-looping', isLoopingPart);
                loopPart.title = 'Play only this saved part repeatedly until Stop Song or Stop Part Loop.';
                loopPart.disabled = this.busy || Boolean(this.editing);
                loopPart.addEventListener('click', () => this.run(() => this.loopPart(part.id)));
                controls.append(loopPart);
                const detail = this.document.createElement('span');
                detail.className = 'song-beta-part-detail';
                const uses = this.song.parts.filter(entry => sourceId(entry) === sourceId(part)).length;
                const savedSteps = part.patternSteps * (part.patternCycleMultiplier ?? 1);
                const playedSteps = part.playbackSteps ?? savedSteps;
                detail.textContent = `${part.bpm} BPM · ${playedSteps} steps${playedSteps < savedSteps ? ` of ${savedSteps} saved` : ''} · ${partDurationSeconds(part).toFixed(1)}s${uses > 1 ? ` · Shared: ${uses} uses` : ''}`;
                controls.append(detail);
                const colourLabel = this.document.createElement('label');
                colourLabel.className = 'song-beta-part-colour';
                colourLabel.textContent = 'Colour';
                const colour = this.document.createElement('input');
                colour.type = 'color';
                colour.value = part.colour || '#75dfb4';
                colour.setAttribute('aria-label', `Colour for ${part.name}`);
                colour.title = 'Choose a colour. Saves automatically and stays with this part.';
                colour.disabled = changesBlocked || this.busy;
                colour.addEventListener('change', () => this.run(() => this.setColour(part, colour.value)));
                colourLabel.append(colour);
                controls.append(colourLabel);
                const clearColour = this.document.createElement('button');
                clearColour.type = 'button';
                clearColour.className = 'performance-btn song-beta-clear-colour';
                clearColour.textContent = 'Clear Colour';
                clearColour.setAttribute('aria-label', `Clear colour for ${part.name}`);
                clearColour.disabled = changesBlocked || this.busy || !part.colour;
                clearColour.addEventListener('click', () => this.run(() => this.setColour(part, null)));
                controls.append(clearColour);
                const repeatLabel = this.document.createElement('label');
                repeatLabel.className = 'song-beta-part-repeats';
                repeatLabel.textContent = 'Repeats';
                const repeats = this.document.createElement('input');
                repeats.type = 'number';
                repeats.min = '1';
                repeats.max = '64';
                repeats.step = '1';
                repeats.value = part.repeats;
                repeats.setAttribute('aria-label', `Repeats for ${part.name}`);
                repeats.title = '1–64 whole-pattern repeats. Saves when you leave the box or press Enter.';
                repeats.disabled = changesBlocked || this.busy || this.playing || Boolean(this.editing);
                repeats.addEventListener('change', () => this.run(() => this.setRepeats(part, repeats.value)));
                repeats.addEventListener('keydown', event => {
                    if (event.key !== 'Enter') return;
                    event.preventDefault();
                    repeats.blur();
                });
                repeatLabel.append(repeats);
                header.append(repeatLabel);
                const stepsLabel = this.document.createElement('label');
                stepsLabel.className = 'song-beta-part-steps';
                stepsLabel.textContent = 'Steps';
                const steps = this.document.createElement('input');
                const fullSteps = part.patternSteps * (part.patternCycleMultiplier ?? 1);
                steps.type = 'number';
                steps.min = '1';
                steps.max = String(fullSteps);
                steps.step = '1';
                steps.value = part.playbackSteps ?? fullSteps;
                steps.setAttribute('aria-label', `Steps for ${part.name}`);
                steps.title = `Play the first 1–${fullSteps} steps per repeat. The full saved pattern is retained. Saves when you leave the box or press Enter.`;
                steps.disabled = changesBlocked || this.busy || this.playing || Boolean(this.editing);
                steps.addEventListener('change', () => this.run(() => this.setSteps(part, steps.value)));
                steps.addEventListener('keydown', event => {
                    if (event.key !== 'Enter') return;
                    event.preventDefault();
                    steps.blur();
                });
                stepsLabel.append(steps);
                header.append(stepsLabel);
                for (const [label, className, action] of [
                    ['Recall', 'song-beta-load', () => this.recall(part, { start: false })],
                    ['Reuse Part', 'song-beta-reuse', () => this.reusePart(part)],
                    ['Make a full copy', 'song-beta-full-copy', () => this.fullCopyPart(part)],
                    ['Amend', 'song-beta-amend', () => this.amendPart(part)],
                    ['Delete', 'song-beta-delete', () => this.deletePart(part)],
                    ['Copy From Part', 'song-beta-copy', null],
                    ['Paste Part', 'song-beta-paste', () => this.pasteLoop(part)]
                ]) {
                    const actionButton = this.document.createElement('button');
                    actionButton.type = 'button';
                    actionButton.className = `performance-btn ${className}`;
                    actionButton.textContent = label;
                    if (className === 'song-beta-amend' && part.id === this.amendLoading?.id) actionButton.textContent = 'Please wait…';
                    actionButton.setAttribute('aria-label', `${label} ${part.name}`);
                    if (className === 'song-beta-reuse') actionButton.title = 'Add this existing part again at the end, without copying sounds or renders. Amendments affect every use; order and repeats are independent.';
                    if (className === 'song-beta-full-copy') actionButton.title = 'Append a full independent copy of this saved part, including all sounds and settings. Its name ends in _full_copy; editing it does not change the original.';
                    if (className === 'song-beta-amend') actionButton.title = 'Amend the shared pattern and sounds for every use of this part.';
                    if (className === 'song-beta-paste') actionButton.title = !this.loopClipboard ? 'Copy loops, K tracks, drum lanes or EQs from a saved part first.' : this.busy ? 'Wait for the current Song operation to finish.' : this.playing ? 'Stop Song before pasting.' : this.editing ? 'Save or cancel the current amendment before pasting.' : `Replace ${copiedLabel(this.loopClipboard)} with the saved copy from ${this.loopClipboard.name}. Shared occurrences change together. Editing access is requested automatically.`;
                    actionButton.disabled = (!['song-beta-load', 'song-beta-copy'].includes(className) && changesBlocked) || this.busy || this.playing || Boolean(this.editing) || (className === 'song-beta-paste' && !this.loopClipboard);
                    actionButton.addEventListener('click', () => className === 'song-beta-copy' ? this.openLoopCopyPicker(part, actionButton) : this.run(action));
                    controls.append(actionButton);
                }
                for (const [label, direction] of [['Rename', 0], ['↑', -1], ['↓', 1]]) {
                    const edit = this.document.createElement('button');
                    edit.type = 'button';
                    edit.className = 'performance-btn song-beta-edit';
                    edit.textContent = label;
                    edit.setAttribute('aria-label', direction ? `Move ${part.name} ${direction < 0 ? 'up' : 'down'}` : `Rename ${part.name}`);
                    edit.disabled = changesBlocked || this.busy || this.playing || Boolean(this.editing) || (direction === -1 && index === 0) || (direction === 1 && index === this.song.parts.length - 1);
                    edit.addEventListener('click', () => this.run(() => this.arrange(part, direction)));
                    if (direction) actions.append(edit);
                    else controls.append(edit);
                }
                header.append(actions);
                list.append(row);
            }
            this.adapter.refreshPlaybackUi?.();
        }
    }

    root.MygrainSongBeta = { Controller, partDurationSeconds, sourcePartDurationSeconds, libraryKey, libraryStorage, parseLibraryAccess };
    if (typeof module !== 'undefined' && module.exports) module.exports = root.MygrainSongBeta;
})(globalThis);
