(function(root){
'use strict';
if(root.__mygrainSongRenderDeck)return;
const card=document.getElementById('genreatorCard');if(!card)return;
const bpm=document.getElementById('genreatorBpm'),status=document.getElementById('genreatorStatus'),cancel=document.getElementById('genreatorCancel'),undo=document.getElementById('genreatorUndo');
let genres=[],pending=false,lastGenre=null,confirming=false;
const protection=document.createElement('details');protection.className='ai-patch-protection';
protection.innerHTML='<summary>Protected Layers · AI patch</summary><label><input type="checkbox" data-ai-eq-protect> EQ · all channels</label><p>Preserve EQ settings and recorded automation when creating an AI patch.</p>';
bpm.closest('label')?.after(protection);
if(!protection.isConnected)card.prepend(protection);
document.addEventListener('change',e=>{if(!e.target.matches('[data-ai-eq-protect]'))return;for(const box of document.querySelectorAll('[data-ai-eq-protect]'))box.checked=e.target.checked;});

const tempoDialog=document.createElement('dialog');tempoDialog.id='genreatorTempoDialog';tempoDialog.setAttribute('aria-labelledby','genreatorTempoTitle');
tempoDialog.innerHTML='<h2 id="genreatorTempoTitle">Use BPM override?</h2><p id="genreatorTempoQuestion"></p><div class="genreator-tempo-actions"><button type="button" data-tempo-choice="yes">Yes</button><button type="button" data-tempo-choice="cancel" autofocus>Cancel</button><button type="button" data-tempo-choice="suggested">Use suggested</button></div>';
document.body.append(tempoDialog);
for(const button of tempoDialog.querySelectorAll('[data-tempo-choice]'))button.addEventListener('click',()=>tempoDialog.close(button.dataset.tempoChoice));
function resetTempo(){bpm.value='';bpm.defaultValue='';if(tempoDialog.open)tempoDialog.close('cancel')}
bpm.autocomplete='off';resetTempo();
root.addEventListener('pageshow',resetTempo);
Promise.resolve(root.mygrainCardHistory?.ready).then(resetTempo);
document.getElementById('randomizeBtn')?.addEventListener('click',resetTempo,{capture:true});
root.addEventListener('mygrain-account-lock',resetTempo);root.addEventListener('mygrain-account-changed',resetTempo);
function confirmTempo(profile,tempo){
 confirming=true;sync();document.getElementById('genreatorTempoQuestion').textContent=`Use ${tempo} BPM for ${profile.label}? Use suggested lets the genre choose its tempo (${profile.bpm[0]}–${profile.bpm[1]} BPM).`;
 return new Promise(resolve=>{const previous=document.activeElement;tempoDialog.returnValue='';tempoDialog.addEventListener('close',()=>{confirming=false;sync();if(previous?.isConnected)previous.focus({preventScroll:true});resolve(tempoDialog.returnValue||'cancel')},{once:true});tempoDialog.showModal()});
}
function sync(){
 const ai=root.mygrainAiPatch,busy=confirming||pending||ai?.busy||root.mygrainCardHistory?.busy||root.mygrainInstareel?.capturing;
 for(const b of card.querySelectorAll('[data-genre]'))b.disabled=!!busy||!ai?.ready;
 bpm.disabled=!!busy;cancel.hidden=!pending;undo.disabled=!!busy||!root.mygrainCardHistory?.undoLabel;
 card.dataset.genreBuild='GENRE.6';card.setAttribute('aria-busy',String(!!busy));
 if(pending&&ai?.diagnostics().status)status.textContent=ai.diagnostics().status;
}
async function generate(id){
 const profile=genres.find(g=>g.id===id),ai=root.mygrainAiPatch;
 if(!profile||pending||confirming||ai?.busy||!ai?.ready)return;
 let tempo=bpm.value.trim()===''?null:Number(bpm.value);
 if(tempo!==null){const choice=await confirmTempo(profile,tempo);if(choice==='cancel'){status.textContent='Generation cancelled. Current patch unchanged.';return}if(choice==='suggested'){resetTempo();tempo=null}}
 if(ai?.busy||!ai?.ready||root.mygrainCardHistory?.busy)return;
 if(tempo!==null&&(!Number.isInteger(tempo)||tempo<60||tempo>180)){status.textContent='Enter a whole BPM from 60 to 180, or leave blank for AI tempo.';return;}
 pending=true;lastGenre=id;status.textContent=`Choosing a fresh ${profile.label} patch…`;sync();
 try{
  const prompt=`GENREator: create a fresh ${profile.label} patch. ${profile.direction} ${tempo===null?`Choose a suitable tempo within ${profile.bpm[0]}–${profile.bpm[1]} BPM.`:`Use exactly ${tempo} BPM.`} Choose coherent sources, notes, drum steps and useful levels using the supplied card knowledge. Respect this genre's excluded sources. Preserve recorded audio. Make a different musical variation each time.`;
  const result=await ai.generateGenre(id,tempo,prompt);
  status.textContent=result?.applied?`${profile.label} patch applied. ${document.getElementById('globalBpmSlider').value} BPM. Use Play to hear it if stopped; Undo restores the previous patch.`:(ai.diagnostics().status||'No patch applied.');
 }catch(error){status.textContent=error.message||'Generation failed. No fallback preset was applied.'}
 finally{pending=false;sync()}
}
cancel.addEventListener('click',()=>root.mygrainAiPatch?.cancel());
undo.addEventListener('click',async()=>{if(!pending&&!root.mygrainAiPatch?.busy){await root.mygrainCardHistory?.undo();status.textContent='Undo finished.';sync()}});
root.addEventListener('mygrain-ai-update',sync);root.addEventListener('mygrain-history-update',sync);
root.mygrainGenreator=Object.freeze({generate,resetTempo,get busy(){return pending||confirming},get genres(){return genres.map(g=>g.id)},get lastGenre(){return lastGenre}});
(async()=>{try{
 const response=await fetch(new URL('genre-presets.json?v=20261029-genre-3',document.baseURI),{credentials:'same-origin'});if(!response.ok)throw Error('Genre list could not load. Reload to try again.');genres=await response.json();
 const host=document.getElementById('genreatorGenres');
 for(const group of [...new Set(genres.map(g=>g.group))]){
  const section=document.createElement('fieldset'),legend=document.createElement('legend');legend.textContent=group;section.append(legend);
  const grid=document.createElement('div');grid.className='genreator-buttons';
  for(const profile of genres.filter(g=>g.group===group)){const button=document.createElement('button');button.type='button';button.className='performance-btn';button.dataset.genre=profile.id;button.textContent=profile.label;button.title=`${profile.bpm[0]}–${profile.bpm[1]} BPM · ${profile.direction}`;button.addEventListener('click',()=>generate(profile.id));grid.append(button)}
  section.append(grid);host.append(section);
 }
 sync();
}catch(error){status.textContent=error.message;sync()}})();
})(window);

// INSTAREEL is deliberately confined to G; it never recalls or edits the live patch.
(function(root){
'use strict';
if(root.__mygrainSongRenderDeck)return;
const card=document.getElementById('genreatorCard');if(!card)return;
const box=document.createElement('fieldset');box.id='instareelControls';box.dataset.mygrainWorkspace='instareel';
box.innerHTML=`<legend>INSTAREEL <small>· 10</small></legend>
 <p>Evolve your current sounds into a loopable 30–60 second reel. Your patch stays unchanged; the finished WAV is not editable.</p>
 <div class="instareel-options"><label>Target seconds <input id="instareelSeconds" type="number" min="30" max="60" step="1" value="45" inputmode="numeric"></label>
 <label>Variation <select id="instareelVariation"><option value="none">No variation · repeat loop</option><option value="subtle" selected>Subtle</option><option value="moderate">Moderate</option><option value="extreme">Extreme</option></select></label></div>
 <div class="instareel-options"><label><input id="instareelNotes" type="checkbox"> X / L root-note variations</label><label><input id="instareelDrums" type="checkbox"> Drum variations + Roll fills</label></div>
 <div class="instareel-options"><label><input id="instareelRecutV" type="checkbox"> Re-cut V · original phrase every other repeat</label></div>
 <details class="instareel-protection"><summary>Protected layers · exclude from variations</summary><p>Checked layers keep their original level, on/off state, notes and cuts. Drums includes Roll fills. Generated master-filter motion is disabled whenever any protection is selected. Your own effects still run.</p><div class="instareel-protected-grid"><label><input type="checkbox" data-mirror-control="instareel-protection" data-reel-protected="A"> A</label><label><input type="checkbox" data-mirror-control="instareel-protection" data-reel-protected="B"> B</label><label><input type="checkbox" data-mirror-control="instareel-protection" data-reel-protected="C"> C</label><label><input type="checkbox" data-mirror-control="instareel-protection" data-reel-protected="D"> D</label><label><input type="checkbox" data-mirror-control="instareel-protection" data-reel-protected="V"> V</label><label><input type="checkbox" data-mirror-control="instareel-protection" data-reel-protected="W"> W</label><label><input type="checkbox" data-mirror-control="instareel-protection" data-reel-protected="P"> P</label><label><input type="checkbox" data-mirror-control="instareel-protection" data-reel-protected="O"> O</label><label><input type="checkbox" data-mirror-control="instareel-protection" data-reel-protected="L"> L</label><label><input type="checkbox" data-mirror-control="instareel-protection" data-reel-protected="X"> X</label><label><input type="checkbox" data-mirror-control="instareel-protection" data-reel-protected="M"> M</label><label><input type="checkbox" data-mirror-control="instareel-protection" data-reel-protected="M+"> M+</label><label><input type="checkbox" data-mirror-control="instareel-protection" data-reel-protected="K"> K</label><label><input type="checkbox" data-mirror-control="instareel-protection" data-reel-protected="Q"> Q</label><label><input type="checkbox" data-mirror-control="instareel-protection" data-reel-protected="N"> N · Noise</label><label><input type="checkbox" data-mirror-control="instareel-protection" data-reel-protected="DRUMS"> Drums + Roll</label><label><input type="checkbox" data-mirror-control="instareel-protection" data-reel-protected="GLOBAL"> Master filter</label></div></details>
 <p>N Noise enters and leaves; A/B/C/W receive fresh cuts each repeat. D keeps its loop source and receives random gaps only. V stays original unless re-cut is selected, then alternates fresh cuts with the original phrase. Optional X/L notes and drums evolve from each previous loop, with occasional hat ratchets and short Roll fills. Extreme makes bolder changes. Existing solos are respected. The original groove returns at the loop boundary.</p>
 <p id="instareelLength">Duration rounds to complete source cycles for a musical loop.</p>
 <div class="instareel-actions"><button id="instareelMake" type="button">Make Reel</button><button id="instareelCancel" type="button" hidden>Cancel reel</button></div>
 <div class="instareel-actions"><button id="instareelNewCurrent" type="button">New reel with current patch</button></div>
 <p id="instareelStatus" role="status" aria-live="polite">Find a patch you like, then make a reel. No extra AI calls.</p>
 <div id="instareelPreview" hidden><strong id="instareelPreviewTitle">Rendered reel</strong>
 <div class="instareel-player"><button id="instareelPlay" type="button">Load & Play</button><label class="instareel-loop"><input id="instareelLoop" type="checkbox" checked> Loop</label><input id="instareelSeek" data-mirror-control="instareel-playback" type="range" min="0" max="1" value="0" step=".01" aria-label="Reel playback position" disabled><span id="instareelTime">0.0s</span></div>
 <div class="instareel-actions"><button id="instareelMaster" type="button">Master Reel</button><button id="instareelMasters" type="button">Browse Reel Masters</button></div><div id="instareelSaveControls"><label>Reel name <input id="instareelName" type="text" maxlength="64" value="My Reel"></label><div class="instareel-actions"><button id="instareelSave" type="button">Save to INSTAREEL</button><button id="instareelDiscard" type="button">Discard preview</button></div></div></div>
 <details id="instareelLibrary"><summary>INSTAREEL WAV Browser</summary><button id="instareelRefresh" type="button">Refresh reels</button><div id="instareelLibraryList">Open to load your saved reels.</div></details>`;
card.append(box);
const el=id=>document.getElementById('instareel'+id),base='/mygrain/api/instareel';
let busy=false,capturing=false,job=null,generation=0,controller=null,timer=null,current=null,buffer=null,source=null,context=null,position=0,started=0,loading=false,playerGeneration=0,disposed=false;
const user=()=>root.mygrainAccounts?.user?.username;
const message=text=>{el('Status').textContent=text};
function sync(){
 const blocked=busy||root.mygrainAiPatch?.busy||root.mygrainCardHistory?.busy;
 el('NewCurrent').disabled=!!blocked;el('Make').disabled=!!blocked;el('Seconds').disabled=busy;el('Variation').disabled=busy;el('Notes').disabled=busy||el('Variation').value==='none';el('Drums').disabled=busy||el('Variation').value==='none';el('RecutV').disabled=busy||el('Variation').value==='none';el('Cancel').hidden=!busy;el('Cancel').disabled=busy&&!job;
 el('Make').textContent=current?.jobId?'Try Another':'Make Reel';
 el('Master').disabled=busy||!current;
 el('Save').disabled=busy||!current?.jobId||!!current?.saved;
}
function abortTask(){generation++;clearTimeout(timer);timer=null;controller?.abort();controller=null;busy=false;capturing=false;sync();root.dispatchEvent(new Event('mygrain-ai-update'))}
async function json(url,options={}){
 const response=await fetch(url,{...options,cache:'no-store'}),payload=await response.json();
 if(!response.ok||!payload.ok){const error=Error(payload.error||`Request failed (${response.status})`);error.status=response.status;throw error}return payload;
}
function currentPosition(){if(!source||!buffer)return position;const t=position+context.currentTime-started;return source.loop?t%(current.duration||buffer.duration):Math.min(current.duration||buffer.duration,t)}
const progressClock=root.mygrainProgressClock(el('Preview'),()=>{if(source)update()});
function update(){const time=currentPosition();el('Seek').value=String(time);el('Time').textContent=`${time.toFixed(1)} / ${(current?.duration||0).toFixed(1)}s`;if(source)progressClock.start()}
function stopSource(){if(source){position=currentPosition();const old=source;source=null;old.onended=null;try{old.stop()}catch{}old.disconnect();old.buffer=null}progressClock.stop();el('Play').textContent=buffer?'Play':'Load & Play'}
function cancelPlayer(){playerGeneration++;playerRequest?.abort();playerRequest=null;stopSource();buffer=null;context=null;position=0;loading=false;el('Play').disabled=false;el('Seek').disabled=true;el('Play').textContent='Load & Play';if(typeof wavIphonePreviewActive!=='undefined'&&wavIphonePreviewActive===player)wavIphonePreviewActive=null;update()}
let playerRequest=null;
const libraryRequest=new AbortController();
let libraryGeneration=0;
const player={cancel:cancelPlayer,displayState:()=>progressClock.snapshot(),get playing(){return !!source},get buffer(){return buffer},get source(){return source}};
function playBuffer(){
 const length=Math.min(buffer.duration,current.duration);if(position>=length)position=0;
 source=context.createBufferSource();source.buffer=buffer;source.loop=el('Loop').checked;source.loopEnd=length;source.connect(context.destination);
 source.onended=()=>{stopSource();position=0;update()};started=context.currentTime;source.start(0,position);
 if(!source.loop)source.stop(started+length-position);
 el('Play').textContent='Pause';update();
}
async function togglePreview(){
 if(!current||loading||disposed)return;if(source){stopSource();update();return}
 const identity=user();context=audioContext;
 if(!identity||!context){message('Start MYGRAIN and sign in before previewing.');return}
 if(typeof wavIphonePreviewActive!=='undefined'){if(wavIphonePreviewActive&&wavIphonePreviewActive!==player)wavIphonePreviewActive.cancel();wavIphonePreviewActive=player}
 context.resume().catch(()=>{});const token=++playerGeneration,selected=current;
 const valid=()=>!disposed&&token===playerGeneration&&selected===current&&identity===user()&&context===audioContext;
 let timeout;
 try{
  if(!buffer){loading=true;el('Play').disabled=true;el('Play').textContent='Loading…';playerRequest=new AbortController();timeout=setTimeout(()=>playerRequest?.abort(),120000);
   const response=await fetch(selected.preview,{cache:'no-store',signal:playerRequest.signal,priority:'high'});
   const decoded=await loadLoopAudioResponse(response,context,{signal:playerRequest.signal,maxEncodedBytes:4*1048576,maxDecodedBytes:64*1048576});
   if(!valid())return;buffer=decoded;playerRequest=null;el('Seek').max=String(Math.min(current.duration,buffer.duration));el('Seek').disabled=false;
  }
  await context.resume();if(valid())playBuffer();
 }catch(error){if(valid()){cancelPlayer();message(`Preview could not play: ${error.name==='AbortError'?'Download timed out; tap Play to retry':error.message}`)}}
 finally{clearTimeout(timeout);if(valid()){loading=false;el('Play').disabled=false}}
}
el('Play').addEventListener('click',togglePreview);
el('Loop').addEventListener('change',()=>{if(source){stopSource();playBuffer()}});
el('Seek').addEventListener('input',()=>{if(!buffer)return;const playing=!!source;stopSource();position=Number(el('Seek').value)||0;if(playing)playBuffer();else update()});
function select(item){cancelPlayer();current=item;el('Preview').hidden=false;el('PreviewTitle').textContent=item.name;el('SaveControls').hidden=!item.jobId;el('Seek').max=String(item.duration);update();sync()}
function length(){
 const seconds=Number(el('Seconds').value),bpm=Number(document.getElementById('globalBpmSlider')?.value)||120;
 el('Length').textContent=`Target ${Number.isFinite(seconds)?seconds:45}s · ${bpm} BPM. ${el('Variation').value==='none'?'No variation: repeats unchanged, rounded to complete source cycles (30–60s).':'Actual duration rounds to complete source cycles (30–60s).'}`;
}
el('Seconds').addEventListener('input',length);
el('Variation').addEventListener('change',()=>{length();sync()});
async function poll(token,identity){
 if(token!==generation||identity!==user())return;
 try{
  const data=await json(`${base}/${job.id}`,{signal:controller.signal});if(token!==generation||identity!==user())return;job=data.job;message(job.message);
  if(job.state==='done'){
   const ready=job;busy=false;controller=null;select({jobId:ready.id,preview:`${base}/${ready.id}/preview`,duration:ready.plan.duration,name:`${ready.plan.duration.toFixed(1)}s · ${ready.plan.variation} · ${ready.plan.bpm} BPM`});
   message(`${ready.plan.duration.toFixed(1)}s loopable reel ready · ${ready.plan.variation==='none'?'no variation · repeat loop':ready.plan.variation+' variations'}${ready.plan.options?.notes?' · X/L notes':''}${ready.plan.options?.drums?' · drums/fills':''}${ready.plan.options?.recutV&&!ready.plan.options?.protectedLayers?.includes('V')?' · V cuts/original':''}${ready.plan.options?.protectedLayers?.length?' · protected '+ready.plan.options.protectedLayers.join(', '):''} (${ready.plan.requestedSeconds}s requested). Preview, save, or Try Another. Current patch unchanged.`);sync();return;
  }
  if(['failed','cancelled'].includes(job.state)){busy=false;controller=null;sync();return}
  timer=setTimeout(()=>poll(token,identity),1000);
 }catch(error){if(token===generation){if(error.status===404||error.status===401){busy=false;controller=null;message(error.message);sync()}else{message(`Reel status unavailable: ${error.message}. Retrying; Cancel remains available.`);timer=setTimeout(()=>poll(token,identity),2000)}}}
}
async function makeCurrentReel(){
 if(busy||disposed)return;const seconds=Number(el('Seconds').value),variation=el('Variation').value,notes=el('Notes').checked,drums=el('Drums').checked,recutV=el('RecutV').checked,protectedLayers=[...box.querySelectorAll('[data-reel-protected]:checked')].map(e=>e.dataset.reelProtected),identity=user();
 if(!Number.isFinite(seconds)||seconds<30||seconds>60){message('Enter a target from 30 to 60 seconds.');return}
 if(!identity||!root.mygrainSongBetaAdapter){message('Start MYGRAIN and sign in first.');return}
 if(root.mygrainAiPatch?.busy||root.mygrainCardHistory?.busy){message('Wait for the current patch change to finish.');return}
 abortTask();cancelPlayer();el('Preview').hidden=true;job=null;const token=generation;controller=new AbortController();busy=true;capturing=true;sync();root.dispatchEvent(new Event('mygrain-ai-update'));
 try{
  message(`Capturing current sounds · ${seconds}s requested · ${variation==='none'?'no variation · repeat loop':variation+' variations'}…`);
  const adapter=root.mygrainSongBetaAdapter;
  const live=await adapter.capture({liveOnly:true});
  const estimated=[...live.buffers.values()].reduce((sum,b)=>sum+(b?b.length*b.numberOfChannels*2:0),0);
  const maxBytes=/iPhone|iPad|iPod/.test(navigator.userAgent)||navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1?48*1048576:96*1048576;
  if(estimated>maxBytes)throw Error('This patch has too much source audio to snapshot safely. Shorten its samples before making a reel.');
  const serial=sourceMutationSerial,archive=await adapter.capture();
  if(token!==generation||identity!==user())return;
  if(sourceMutationSerial!==serial)throw Error('Source sounds changed during capture. Try Make Reel again.');
  capturing=false;root.dispatchEvent(new Event('mygrain-ai-update'));
  const query=new URLSearchParams({seconds:String(seconds),variation,notes:notes?'1':'0',drums:drums?'1':'0',recutV:recutV?'1':'0',protectedLayers:protectedLayers.join(',')});
  message('Uploading snapshot. Rendering runs on the server; your current patch stays unchanged.');
  const data=await json(base+'?'+query,{method:'POST',headers:{'Content-Type':'application/zip'},body:archive,signal:controller.signal});
  if(token!==generation||identity!==user())return;job=data.job;sync();message(`Rendering ${job.plan.duration.toFixed(1)}s · ${job.plan.variation==='none'?'no variation · repeat loop':job.plan.variation+' variations'} (${job.plan.requestedSeconds}s requested)…`);poll(token,identity);
 }catch(error){if(token===generation){abortTask();message(`Could not make reel: ${error.message}. Current patch unchanged.`)}}
 finally{if(token===generation){capturing=false;root.dispatchEvent(new Event('mygrain-ai-update'));sync()}}
}
el('Make').addEventListener('click',makeCurrentReel);
el('NewCurrent').addEventListener('click',makeCurrentReel);
el('Cancel').addEventListener('click',async()=>{const pending=job;abortTask();const token=generation;busy=true;sync();message('Cancelling reel…');try{if(pending&&['queued','running'].includes(pending.state)){const data=await json(`${base}/${pending.id}/cancel`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});if(token!==generation)return;job=data.job}busy=false;message('Reel cancelled. Current patch unchanged.');sync()}catch(error){if(token===generation){message(`Cancellation could not be confirmed: ${error.message}. Tap Cancel to retry.`);sync()}}});
el('Save').addEventListener('click',async()=>{
 if(!current?.jobId||current.saved||busy)return;const item=current,identity=user();el('Save').disabled=true;
 try{const data=await json(`${base}/${item.jobId}/save`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:el('Name').value})});if(identity!==user()||item!==current)return;item.saved=true;message(`Saved ${data.reel.filename} to INSTAREEL.`);await library()}
 catch(error){message(`Save failed: ${error.message}. Your preview is still available.`)}finally{sync()}
});
el('Master').addEventListener('click',()=>{if(!current||busy)return;stopSource();root.mygrainMastering?.openReel(current);});
el('Masters').addEventListener('click',()=>root.openWavMastersBrowser?.('reels'));
el('Discard').addEventListener('click',()=>{cancelPlayer();current=null;el('Preview').hidden=true;message('Preview discarded. Saved reels and current patch unchanged.');sync()});
async function library(){
 const token=++libraryGeneration,identity=user(),list=el('LibraryList');list.textContent='Loading reels…';
 try{const data=await json(base+'/library');
  if(root.mygrainUiActivity?.busy&&!disposed)await new Promise(resolve=>{const ready=()=>{root.removeEventListener('mygrain-ui-settled',ready);libraryRequest.signal.removeEventListener('abort',ready);resolve()};root.addEventListener('mygrain-ui-settled',ready,{once:true});libraryRequest.signal.addEventListener('abort',ready,{once:true})});
  if(token!==libraryGeneration||identity!==user()||disposed)return;list.replaceChildren();
  if(!data.reels.length){list.textContent='No saved reels yet.';return}
  for(const reel of data.reels){const row=document.createElement('div');row.className='instareel-library-row';const title=document.createElement('span');title.textContent=`${reel.name} · ${reel.duration.toFixed(1)}s · ${reel.bpm} BPM`;
   const play=document.createElement('button');play.type='button';play.textContent='Preview';play.addEventListener('click',()=>{select({libraryId:reel.id,name:title.textContent,duration:reel.duration,preview:`${base}/library/${reel.id}/preview`});togglePreview();el('Preview').scrollIntoView({block:'nearest'});el('Play').focus({preventScroll:true})});
   const download=document.createElement('button');download.type='button';download.textContent='Download WAV';download.addEventListener('click',async()=>{download.disabled=true;try{const response=await fetch(`${base}/library/${reel.id}/wav`,{cache:'no-store'});if(!response.ok)throw Error('Download failed');const blob=await response.blob();if(identity!==user()||disposed)return;downloadBlob(blob,reel.filename)}catch(error){message(error.message)}finally{download.disabled=false}});
   const rename=document.createElement('button');rename.type='button';rename.textContent='Rename';
   const remove=document.createElement('button');remove.type='button';remove.textContent='Delete';
   const upload=document.createElement('button');upload.type='button';upload.textContent='Upload to FTP';
   const form=document.createElement('form');form.className='instareel-rename';form.hidden=true;
   const input=document.createElement('input');input.value=reel.name;input.maxLength=64;input.setAttribute('aria-label','New reel name');
   const save=document.createElement('button');save.type='submit';save.textContent='Save name';
   const cancel=document.createElement('button');cancel.type='button';cancel.textContent='Cancel';cancel.onclick=()=>{form.hidden=true};form.append(input,save,cancel);
   let acting=false;
   const run=async action=>{if(acting||disposed||identity!==user())return;acting=true;for(const b of row.querySelectorAll('button,input'))b.disabled=true;try{await action()}catch(error){if(identity===user()&&!disposed)message(error.message)}finally{acting=false;for(const b of row.querySelectorAll('button,input'))b.disabled=false}};
   const mutate=(action,payload)=>json(`${base}/library/${reel.id}/${action}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:libraryRequest.signal});
   rename.onclick=()=>{form.hidden=false;input.focus()};
   form.onsubmit=event=>{event.preventDefault();run(async()=>{const data=await mutate('rename',{name:input.value});if(disposed||identity!==user())return;if(current?.libraryId===reel.id){current.name=data.reel.name;el('PreviewTitle').textContent=current.name}await library();message(`Renamed to ${data.reel.name}.`)})};
   remove.onclick=()=>{if(!confirm(`Delete “${reel.name}” from INSTAREEL? Uploaded FTP copies are kept.`))return;run(async()=>{await mutate('delete',{});if(disposed||identity!==user())return;if(current?.libraryId===reel.id||current?.jobId===reel.id){cancelPlayer();current=null;el('Preview').hidden=true;sync()}await library();message('Reel deleted. Uploaded FTP copies are unchanged.')})};
   upload.onclick=()=>run(async()=>{
    if(!root.mygrainFtp?.pickFolder)throw Error('FTP browser is not ready. Reload MYGRAIN and try again.');
    const folder=await root.mygrainFtp.pickFolder({title:'INSTAREEL · Choose private FTP folder',signal:libraryRequest.signal});if(disposed||identity!==user())return;if(folder===null){message('FTP upload cancelled.');return}
    message('Uploading reel to private FTP…');
    const response=await fetch(`${base}/library/${reel.id}/wav`,{cache:'no-store',signal:libraryRequest.signal});if(!response.ok)throw Error('Reel download failed. Refresh the INSTAREEL browser.');
    if(Number(response.headers.get('Content-Length'))>24*1048576)throw Error('Reel exceeds the upload memory limit.');
    const blob=await response.blob();if(blob.size>24*1048576)throw Error('Reel exceeds the upload memory limit.');if(disposed||identity!==user())return;
    const path=[folder,reel.filename].filter(Boolean).join('/');await json(`/mygrain/api/ftp/upload?${new URLSearchParams({path})}`,{method:'POST',body:blob,headers:{'Content-Type':'application/octet-stream'},signal:libraryRequest.signal});
    if(!disposed&&identity===user())message(`Uploaded ${reel.filename} to private FTP /${identity}/${folder}.`);
   });
   const master=document.createElement('button');master.type='button';master.textContent='Master Reel';master.onclick=()=>{stopSource();root.mygrainMastering?.openReel({libraryId:reel.id,name:reel.name});};
   row.append(title,play,download,master,rename,remove,upload,form);list.append(row);
  }
 }catch(error){if(identity===user())list.textContent=`Could not load reels: ${error.message}`}
}
el('Library').addEventListener('toggle',()=>{if(el('Library').open)library()});el('Refresh').addEventListener('click',library);
function dispose(){progressClock.dispose();disposed=true;libraryRequest.abort();const pending=job;abortTask();cancelPlayer();current=null;job=null;el('Preview').hidden=true;el('LibraryList').replaceChildren();message('Sign in again to use INSTAREEL.');if(pending&&['queued','running'].includes(pending.state))json(`${base}/${pending.id}/cancel`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}).catch(()=>{})}
root.addEventListener('mygrain-account-lock',dispose);root.addEventListener('mygrain-account-changed',dispose);
root.addEventListener('mygrain-ai-update',sync);root.addEventListener('mygrain-history-update',sync);
root.mygrainInstareel=Object.freeze({get busy(){return busy},get capturing(){return capturing},get player(){return player},get job(){return job?{id:job.id,state:job.state}:null}});
length();sync();library();
})(window);
